# Întoarce conținutul unui singur bloc de pe My page, cerut de JavaScript când utilizatorul
# deschide blocul. Conținutul e cel din Redmine (MyHelper#render_block_content), neschimbat.
class StsMyBlocksController < ApplicationController
  self.main_menu = false
  before_action :require_login

  helper :my
  helper :issues
  helper :users
  helper :custom_fields
  helper :queries
  helper :activities

  def show
    @user = User.current
    block = params[:block].to_s
    # doar blocurile pe care utilizatorul le are pe pagina lui
    unless @user.pref.my_page_layout.values.flatten.include?(block)
      head :not_found
      return
    end

    render partial: 'sts_customizari/my_block', locals: {block: block, user: @user}, layout: false
  end
end
