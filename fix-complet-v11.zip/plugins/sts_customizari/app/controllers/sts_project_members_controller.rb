# Lista de membri de pe Overview-ul unui proiect, cerută de JavaScript la click
# (vezi app/views/projects/_members_box.html.erb). Conținutul e cel din Redmine.
class StsProjectMembersController < ApplicationController
  def show
    @project = Project.find(params[:id])
    unless @project.visible?
      render_403
      return
    end

    @principals_by_role = @project.principals_by_role
    render partial: 'projects/members_box', layout: false
  rescue ActiveRecord::RecordNotFound
    render_404
  end
end
