module StsCustomizari
  # My page: la deschiderea paginii, fiecare bloc apare doar cu titlul (fără interogări în bază).
  # Datele se aduc când utilizatorul deschide blocul (StsMyBlocksController + sts_customizari.js).
  # Blocurile lăsate deschise sunt ținute minte în browser și se încarcă singure, după ce pagina apare.
  # La adăugarea unui bloc sau la schimbarea setărilor lui, Redmine îl afișează complet, ca înainte.
  module MyPageLazy
    def render_block(block, user)
      return super unless controller_name == 'my' && %w(page index).include?(action_name)
      return nil unless Redmine::MyPage.find_block(block)

      handle = content_tag('span', sprite_icon('reorder', ''), :class => 'icon-only icon-sort-handle sort-handle', :title => l(:button_move))
      close = link_to(sprite_icon('close', l(:button_delete)),
                      {:action => "remove_block", :block => block},
                      :remote => true, :method => 'post',
                      :class => "icon-only icon-close", :title => l(:button_delete))
      collapse = link_to(sprite_icon('angle-up', l(:sts_mypage_collapse)), '#',
                         :class => 'icon-only sts-block-collapse', :title => l(:sts_mypage_collapse),
                         :style => 'display:none')
      title = content_tag('h3',
                          link_to(sprite_icon('angle-right', sts_block_title(block, user)), '#',
                                  :class => 'icon sts-block-load', :title => l(:sts_mypage_expand)),
                          :class => 'sts-block-title')
      content = content_tag('div', collapse + handle + close, :class => 'contextual') +
                title + content_tag('div', '', :class => 'sts-block-body')

      content_tag('div', content, :class => 'mypage-box sts-lazy-block', :id => "block-#{block}",
                  :data => {:url => sts_my_block_path(:block => block),
                            :loading => l(:sts_mypage_loading), :error => l(:sts_mypage_error)})
    end

    def sts_block_title(block, user)
      if block.start_with?('issuequery')
        query_id = user.pref.my_page_settings(block)[:query_id]
        query = IssueQuery.visible.find_by(:id => query_id) if query_id.present?
        return query.name if query
      end
      label = Redmine::MyPage.find_block(block)[:label]
      label.is_a?(Symbol) ? l(label) : label.to_s
    end
  end
end
