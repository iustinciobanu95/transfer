module StsCustomizari
  # Pagina Overview a unui proiect (projects#show). În Redmine 7 face 4 interogări pe issue-urile
  # proiectului și ale tuturor subproiectelor: deschise pe tracker, totale pe tracker, ore estimate,
  # timp lucrat. La proiectele-grupare (ex. „DMS - STS”) asta înseamnă aproape tot tabelul,
  # de 4 ori: ~13 s.
  # Aici: deschise + totale + ore estimate dintr-o singură interogare, iar rezultatul (cu timpul
  # lucrat) se păstrează 10 minute pentru perechea (proiect, utilizator). Ce se afișează e la fel;
  # numerele pot fi în urmă cu cel mult 10 minute.
  module ProjectOverviewPatch
    TTL = 10.minutes

    def show
      return super if params[:jump].present? || !request.format.html?

      # membrii se încarcă la cerere (app/views/projects/_members_box.html.erb); aici doar numărul
      @principals_by_role = {}
      @sts_members_count = @project.memberships.active.count
      @subprojects = @project.leaf? ? [] : @project.children.visible.to_a
      @news = @project.news.limit(5).includes(:author, :project).reorder("#{News.table_name}.created_on DESC").to_a
      with_subprojects = Setting.display_subprojects_issues?
      @trackers = @project.rolled_up_trackers(with_subprojects).visible

      view_time = User.current.allowed_to_view_all_time_entries?(@project)
      stats = StsCustomizari::ProjectOverviewPatch.stats(@project, User.current, with_subprojects, view_time)

      @open_issues_by_tracker = {}
      @total_issues_by_tracker = {}
      @trackers.each do |tracker|
        @open_issues_by_tracker[tracker] = stats[:open][tracker.id] if stats[:open][tracker.id]
        @total_issues_by_tracker[tracker] = stats[:total][tracker.id] if stats[:total][tracker.id]
      end

      if view_time
        @total_hours = stats[:hours]
        @total_estimated_hours = stats[:estimated]
      end

      @key = User.current.atom_key
      render :show
    end

    def self.stats(project, user, with_subprojects, view_time)
      key = ['sts_project_overview', project.id, user.id, with_subprojects, view_time]
      Rails.cache.fetch(key, expires_in: TTL) do
        cond = project.project_condition(with_subprojects)
        rows = Issue.visible(user).where(cond).joins(:status).
          group("#{Issue.table_name}.tracker_id", "#{IssueStatus.table_name}.is_closed").
          pluck(Arel.sql("#{Issue.table_name}.tracker_id"),
                Arel.sql("#{IssueStatus.table_name}.is_closed"),
                Arel.sql("COUNT(*)"),
                Arel.sql("SUM(#{Issue.table_name}.estimated_hours)"))

        open = Hash.new(0)
        total = Hash.new(0)
        estimated = 0.0
        rows.each do |tracker_id, is_closed, count, est|
          total[tracker_id] += count.to_i
          open[tracker_id] += count.to_i unless [true, 1, '1', 't'].include?(is_closed)
          estimated += est.to_f
        end

        result = {:open => open.to_h, :total => total.to_h, :estimated => estimated}
        result[:hours] = TimeEntry.visible(user).where(cond).sum(:hours).to_f if view_time
        result
      end
    end
  end
end
