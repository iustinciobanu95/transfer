module StsCustomizari
  # Inserează în layout ce era scris direct în layouts/base.html.erb în Redmine 3.4.2.
  class Hooks < Redmine::Hook::ViewListener
    def view_layouts_base_html_head(context={})
      tags = []
      tags << stylesheet_link_tag('sts_customizari', plugin: 'sts_customizari')
      if User.current.logged?
        # Doar pentru utilizatori logați: configurația folosită de JS-ul STS.
        config = StsCustomizari::Hooks.js_config.merge(loadingGif: image_path('loading.gif'), groupsLabel: l(:label_group_plural))
        tags << javascript_tag("window.STS = #{ERB::Util.json_escape(config.to_json)};")
      end
      tags << javascript_include_tag('sts_customizari', plugin: 'sts_customizari')
      safe_join(tags, "\n")
    end

    render_on :view_layouts_base_body_bottom, partial: 'sts_customizari/body_bottom'
    render_on :view_layouts_base_content, partial: 'sts_customizari/content_bottom'

    def self.js_config
      settings = Setting.plugin_sts_customizari || {}
      {
        apiKey: settings['api_key'].presence || ENV['STS_API_KEY'].to_s,
        portalAuth: settings['portal_auth'].presence || ENV['STS_PORTAL_AUTH'].to_s
      }
    end
  end
end
