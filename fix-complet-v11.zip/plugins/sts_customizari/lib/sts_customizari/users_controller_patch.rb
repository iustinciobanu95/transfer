module StsCustomizari
  # UsersController#show din Redmine 7 numără issue-urile utilizatorului cu 4 interogări
  # pe toată tabela issues (~1,1 milioane), la fiecare afișare, inclusiv pentru API.
  #   - API (/users/:id.json): numărătorile nu apar în răspuns, deci nu se mai calculează.
  #   - Pagina HTML (/users/:id): 2 interogări în loc de 4 (deschise/închise grupate),
  #     iar rezultatul se păstrează 10 minute pentru perechea (utilizator afișat, utilizator logat).
  module UsersControllerPatch
    COUNTS_TTL = 10.minutes

    def show
      unless @user.visible?
        render_404
        return
      end

      # show projects based on current user visibility
      @memberships = @user.memberships.preload(:roles, :project).where(Project.visible_condition(User.current)).to_a

      if api_request?
        respond_to do |format|
          format.api
        end
        return
      end

      @issue_counts = StsCustomizari::UsersControllerPatch.issue_counts(@user, User.current)

      respond_to do |format|
        format.html do
          events = Redmine::Activity::Fetcher.new(User.current, :author => @user).events(nil, nil, :limit => 10)
          @events_by_day = events.group_by {|event| User.current.time_to_date(event.event_datetime)}
          render :layout => 'base'
        end
      end
    end

    def self.issue_counts(user, viewer)
      Rails.cache.fetch(['sts_user_issue_counts', user.id, viewer.id], expires_in: COUNTS_TTL) do
        {
          :assigned => split_counts(Issue.visible(viewer).assigned_to(user)),
          :reported => split_counts(Issue.visible(viewer).where(:author_id => user.id))
        }
      end
    end

    # O singură interogare: numărul de issue-uri grupat după status deschis / închis.
    def self.split_counts(scope)
      grouped = scope.joins(:status).group("#{IssueStatus.table_name}.is_closed").count
      closed = 0
      open = 0
      grouped.each do |is_closed, count|
        if [true, 1, '1', 't'].include?(is_closed)
          closed += count
        else
          open += count
        end
      end
      {:total => open + closed, :open => open}
    end
  end
end
