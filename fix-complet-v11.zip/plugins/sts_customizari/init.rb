require 'redmine'

# Personalizările făcute direct în core-ul Redmine 3.4.2 (STS), mutate într-un plugin
# ca să nu se mai piardă la upgrade. Vezi README.md din acest folder.
Redmine::Plugin.register :sts_customizari do
  name 'STS – personalizări'
  author 'STS'
  description 'Personalizările din Redmine 3.4.2 (vizibilitate issue-uri, JS, CSS, layout, texte), portate pentru Redmine 7'
  version '1.0.0'
  requires_redmine version_or_higher: '7.0.0'

  settings default: {
    'api_key' => '',
    'portal_auth' => ''
  }, partial: 'settings/sts_customizari'
end

# Redmine 7 rulează init.rb într-un callback to_prepare, deci patch-urile se aplică direct.
# Referirea constantelor încarcă fișierele din lib/ prin Zeitwerk.
StsCustomizari::Patches.apply
StsCustomizari::Hooks.instance
