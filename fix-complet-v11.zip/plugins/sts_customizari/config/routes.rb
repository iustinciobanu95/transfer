# STS: blocurile de pe My page se încarcă la cerere (vezi StsCustomizari::MyPageLazy)
get 'my/sts_block', to: 'sts_my_blocks#show', as: 'sts_my_block'
# STS: lista de membri de pe Overview-ul proiectului, la cerere
get 'projects/:id/sts_members', to: 'sts_project_members#show', as: 'sts_project_members'
