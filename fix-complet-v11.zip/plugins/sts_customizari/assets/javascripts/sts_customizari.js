/*
 * STS – JavaScript personalizat, mutat din public/javascripts/application.js (Redmine 3.4.2)
 * în pluginul sts_customizari pentru Redmine 7.
 *
 * Cheia API și autentificarea pentru portal NU mai sunt scrise în acest fișier:
 * vin din window.STS, pe care pluginul îl generează doar pentru utilizatorii logați
 * (Administrare → Pluginuri → STS – personalizări → Configurare).
 */
var STS = window.STS || { apiKey: '', portalAuth: '', loadingGif: '', groupsLabel: 'Groups' };

// STS 7.0: apelurile Alfresco pleacă doar dacă issue-ul are document (câmpul CV 24/34)
function stsAlfrescoNodeOk(origin, nodeId) {
	return !!origin && !!nodeId && nodeId !== 'undefined' && nodeId !== 'null';
}

function updateIssueFrom(url, el) {


	$.ajax({
		type: "GET",
		async: false,
		headers: {
			"Content-Type": "application/json",
			"X-Redmine-API-Key": STS.apiKey,
			"X-Redmine-Switch-User": $('#loggedas .user').text()
		},
		url: "/issues/" + window.location.href.split('/issues/')[1] + ".json"
	}).done(function (data) {
		if (data.issue.tracker != undefined) {
			//---------------------- DACA este 6 sau 15 si il schimbam in 8, done ratio devine 100% ------------------
			if (
				(data.issue.tracker.id == 6) ||  // Rezolutie
				(data.issue.tracker.id == 15)    // Document intern
			) {
				if (document.getElementById('issue_status_id').value == 8) {  // Daca e CLOSE
					document.getElementById('issue_done_ratio').value = 100;
				} else {
					//document.getElementById('issue_done_ratio').value = 0;
				}
			}

			//---------------------- DACA este 49 (Solicitare aprobare) si il aprobam/anulam, asignee devine userul <<me>>  ------------------			
			/*if(
				( data.issue.tracker.id == 49 ) // Solicitare aprobare
			) {
				if( 
					$('#issue_status_id').val() == 24 ||  // Daca e Aprobat
					$('#issue_status_id').val() == 26 ||  // Daca e Aprobat cu observatii
					$('#issue_status_id').val() == 27     // Daca e Anulat
				) {  
					$('#issue_assigned_to_id option:eq(1)').attr('selected','selected');  // asignee << me >>
				} 
			}*/

		}




	});// AJAX
	/*
	if( document.getElementById('issue_tracker_id') != undefined ) {
		if(
			( document.getElementById('issue_tracker_id').value == 6) ||
			( document.getElementById('issue_tracker_id').value == 15) 
		) {
			if(document.getElementById('issue_status_id').value == 8) {
				document.getElementById('issue_done_ratio').value = 100;
			} else {
				//document.getElementById('issue_done_ratio').value = 0;
			}
		}
	} */




	$('#all_attributes input, #all_attributes textarea, #all_attributes select').each(function () {
		$(this).data('valuebeforeupdate', $(this).val());
	});
	if (el) {
		$("#form_update_triggered_by").val($(el).attr('id'));
	}
	return $.ajax({
		url: url,
		type: 'post',
		data: $('#issue-form').serialize()
	}).done(function () {
		//---------------------- DACA este 49 (Solicitare aprobare) si il aprobam/anulam, asignee devine userul <<me>>  ------------------			
		if (
			(window.location.href.indexOf('issues') != -1) &&
			($('#content h2').text().indexOf('Solicitare aprobare #') != -1)
		) {
			if (
				$('#issue_status_id').val() == 24 ||  // Daca e Aprobat
				$('#issue_status_id').val() == 26 ||  // Daca e Aprobat cu observatii
				$('#issue_status_id').val() == 27     // Daca e Anulat
			) {
				$('#issue_assigned_to_id option:eq(1)').attr('selected', 'selected');  // asignee << me >>
				$('#issue_assigned_to_id').hide();
			} else {
				$('#issue_assigned_to_id').show();
			}
		}
	});






} // function updateIssueFrom(url, el)

$(document).ready(function () {
	// STS: codul de mai jos face apeluri API cu cheia STS. Fără utilizator logat sau fără cheie,
	// apelurile primesc 401 și browserul blochează pagina cu fereastra de autentificare Basic.
	if (!window.STS || !window.STS.apiKey || $('#loggedas .user').length === 0) {
		return;
	}


	//------------ CLEAR local storage on login -----------
	if(
		window.location.href.indexOf('/login') != -1
	) {
		localStorage.clear();
	}






	//--------------- ADD current issue parameters in localStorage ----------------------
	if (
		window.location.href.indexOf('issues/') != -1 &&
		window.location.href.indexOf('issues/new') == -1 &&
		window.location.href.indexOf('issues/gantt') == -1
	) {
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,children,journals,relations"
		}).done(function (data) {

			console.log("current issue: " + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]);
			console.log(data);

			localStorage.setItem('issue_' + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0], JSON.stringify(data));
			localStorage.setItem('currentIssue', JSON.stringify(data));			

			if (data.issue != undefined) {
				localStorage.setItem('currentIssue_id', data.issue.id);
				if (data.issue.assigned_to != undefined) localStorage.setItem('currentIssue_assigned_to_id', data.issue.assigned_to.id);
				if (data.issue.project != undefined) localStorage.setItem('currentIssue_project_id', data.issue.project.id);
			}

			var currentIssue_trackerId = data.issue.tracker.id;
			var currentIssue_statusId = data.issue.status.id;
			var currentIssue_customFields = data.issue.custom_fields;




			//----------- GET ALFRESCO NODE and save to localStorage ---------
			// STS 7.0: ștergem nodul issue-ului anterior, ca să nu se modifice documentul altui issue
			localStorage.removeItem('alfresco_url');
			localStorage.removeItem('alfresco_origin');
			localStorage.removeItem('alfresco_nodeId');
			$.each(data.issue.custom_fields || [], function (eachIndex) {
				if ((data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && data.issue.custom_fields[eachIndex].value != "") {
					//------- alfresco get document name ---------
					var url = data.issue.custom_fields[eachIndex].value;
					var origin = url.split('stsnet.ro/')[0] + 'stsnet.ro/';
					origin = origin.replace('http://', 'https://');
					var nodeId = url.split('SpacesStore/')[1];
					//xxxxxxxxxx
					// console.log(url);
					localStorage.setItem('alfresco_url', url);
					// console.log(origin);
					localStorage.setItem('alfresco_origin', origin);
					// console.log(nodeId);
					if (nodeId) localStorage.setItem('alfresco_nodeId', nodeId.split(/[?#&]/)[0]);
				}
			});




			/*------------------- Document electronic "De semnat" "De transmis" select change -----------------------------------*/
			if( $('#issue_custom_field_values_145').length > 0 ) {
				//$('#issue_custom_field_values_145').attr('disabled','disabled');
				if( $('#loggedas .user').text() == 'admin' ) {
					$('#issue_custom_field_values_145').parent().show();
				} else {
					$('#issue_custom_field_values_145').parent().hide();
				}
				
				if( 
					//$('#issue_parent_issue_id').val() == '' &&
					data.issue.parent == undefined &&
					$('#issue_custom_field_values_140').val().toLowerCase() == 'nu' &&
					$('#issue_custom_field_values_142').val().toLowerCase() == 'nu'
					) {
						$('#issue_custom_field_values_145').val('Da');
					} else {
						$('#issue_custom_field_values_145').val('Nu');
					}


				$('#issue_custom_field_values_140,#issue_custom_field_values_142,#issue_parent_issue_id').on('change', function(){
					if( 
						//$('#issue_parent_issue_id').val() == '' &&
						data.issue.parent == undefined &&
						$('#issue_custom_field_values_140').val().toLowerCase() == 'nu' &&
						$('#issue_custom_field_values_142').val().toLowerCase() == 'nu'
					) {
						$('#issue_custom_field_values_145').val('Da');
					} else {
						$('#issue_custom_field_values_145').val('Nu');
					}
				});
			}
			/*=================== END Document electronic "De semnat" "De transmis" select change  ===============================*/







			//for( i=0;i<=currentIssue_customFields.length-1;i++ ) {
			//if( currentIssue_customFields[i].id != 49 ) {

			/*
		if( 
			(currentIssue_trackerId == 15 || currentIssue_trackerId == 48 || currentIssue_trackerId == 5) //&&
		//   ( currentIssue_statusId == 1 || currentIssue_statusId == 4 )
		) {
			//----------------------------- Urmatorul issue button -----------------------------
			$.ajax({
				type:"GET",
				async:false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()},		
				url:"/projects/cos_lucrary/issues.json?query_id=53&limit=100"
			}).done(function(data){
				if( data.issues.length > 0 ) {
					
					for(i=0;i<=data.issues.length-1;i++) {
						if( 
							data.issues[i].id == window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] &&
							i < data.issues.length-1
						) {
							console.log('issue id='+data.issues[i].id+' si i='+i);
							$('#buttonNextIssue').attr('href','/issues/' + data.issues[i+1].id);
							$('#buttonNextIssue').show();
							break;
						} else {
							$('#buttonNextIssue').attr('href','/issues/' + data.issues[0].id);
							$('#buttonNextIssue').show();
						}
					} 
				
					
				}
			});
		
		} // if afisare urmatorul buton
		*/

			//} // if custom fields CV - Rezolutie = 49
			//}




			//---------------------------- END URMATORUL buton solicitare aprobare -------------------------------
			if (
				(currentIssue_trackerId == 49)
			) {
				//----------------------------- Urmatorul issue button -----------------------------
				/*
				$.ajax({
					type:"GET",
					async:false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()},		
					url:"/projects/cos_lucrary/issues.json?query_id=205&limit=100"
				}).done(function(data){
					if( data.issues.length > 0 ) {
					    
						for(i=0;i<=data.issues.length-1;i++) {
							if( 
								data.issues[i].id == window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] &&
								i < data.issues.length-1
							) {
								console.log('issue id='+data.issues[i].id+' si i='+i);
								$('#buttonNextIssue').attr('href','/issues/' + data.issues[i+1].id);
								$('#buttonNextIssue').show();
								break;
							} else {
								$('#buttonNextIssue').attr('href','/issues/' + data.issues[0].id);
								$('#buttonNextIssue').show();
							}
						} 
				    
					    
					}
				});
				*/

			} // if afisare urmatorul buton
			//================================= END URMATORUL buton solicitare aprobare =================================


			//------------ ADAUGA WATCHERII DE PE PARINTE ------------------ 
			if (data.issue.parent != undefined) {
				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
				}).done(function (data_parent) {
					console.log("--- Issue parinte: ---");
					console.log(data_parent);

					var watchers_to_add = 0;
					var current_watchers = [];
					$('.user.active').each(function (e) {
						current_watchers.push($(this).attr('href').split('/users/')[1]);
					});

					var watchers_json = "utf8=✓&project_id=" + data.issue.project.id + "&object_id[]=" + data.issue.id + "&object_type=issue&user_search=";
					for (i = 0; i <= data_parent.issue.watchers.length - 1; i++) {
						if (!$.inArray(current_watchers, data_parent.issue.watchers[i].id)) {
							watchers_json = watchers_json + "&watcher[user_ids][]=" + data_parent.issue.watchers[i].id;
							watchers_to_add = watchers_to_add + 1;
						}
					} // copy watchers

					console.log(watchers_to_add);

					if (watchers_to_add > 0) {
						//--- ADD watchers to child task ---
						$.ajax({
							type: "POST",
							async: false,
							headers: {
								"Content-Type": "application/x-www-form-urlencoded",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/watchers",
							dataType: "text/javascript; charset=utf-8",
							data: watchers_json
						}).done(function (data_child) {
							console.log("--- Watcherii de pe parinte au fost adaugati ---");
						});
					}// watchers_to_add > 0

				});
			} // adaugam watcherii de pe parinte		

		});


		//---------------- Admin / Me notes class ----------------------
		$('#history .journal').each(function () {
			//console.log( $(this).find('.user').attr('href') );
			if (
				( $(this).find('.user').attr('href') != undefined && $(this).find('.user').attr('href').split('/users/')[1] == 1 )
				||
				( $(this).find('.user').attr('href') != undefined && $(this).find('.user').attr('href').split('/users/')[1] == $('#loggedas').find('.user').attr('href').split('/users/')[1] )
			) {
				$(this).addClass('history_notes_mine');
			}
		});

	} // AJAX on issue LOAD



	//----- RNCD remove other dropdown options for asignee ----
	if( 
		window.location.href.indexOf('/projects/rncd/issues/new') != -1 &&
		(
			$('#issue_parent_issue_id').val() == undefined ||
			$('#issue_parent_issue_id').val() == ''
		)
	) {	
		$('#issue_assigned_to_id option').each(function(){
			if( $(this).val() != 2987 ) {
				$(this).remove();
			}
		});
	}



	if (window.location.href.indexOf('projects') != -1) {
		$("li.root:contains('DMS - STS')").hide();
	}






	// Functie Adauga Watcher
	/*function add_watchers(issue_id,watcher_array){
		var watchers_add = "utf8=✓&object_id[]=" + issue_id + "&object_type=issue&user_search=";

		for(k=0;k<=watcher_array.length-1;k++) {
			watchers_add = watchers_add + "&watcher[user_ids][]=" + watcher_array[k];
		}

		$.ajax({
			type: "POST",
			headers: {
				"Content-Type": "application/x-www-form-urlencoded",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/watchers",
			dataType: "text/javascript; charset=utf-8",
			data: watchers_add
		}).done(function (data) {
			console.log(data);
		});

		console.log('au fost adaugati urmatorii watcheri pe issue_id: ' +issue_id);
		console.log(watcher_array);
		console.log('---');
	}*/


	//-------------------------------- ALFRESCO NEW WATCHER ------------------------------------------
	$(document).on('submit', '#new-watcher-form', function () {
		var watchersJSON = [];
		$('#users_for_watcher input:checked').each(function () {
			watchersJSON.push($(this).val());
			//console.log($(this).val());
			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/users/" + $(this).val() + ".json"
			}).done(function (data) {
				console.log(data.user.login);
				var new_watcher = data.user.login;


				// --- alfresco api ---
				// var origin = "https://secretariat.stsnet.ro/";
				var origin = localStorage.getItem('alfresco_origin');
				// var nodeId = "40d5f9bf-d7b9-4952-8899-af3dd731717c";
				var nodeId = localStorage.getItem('alfresco_nodeId');
				var query = "?include=permissions";
				var i;

				if (stsAlfrescoNodeOk(origin, nodeId)) $.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"Authorization": STS.portalAuth
					},
					url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
				}).done(function (data, statusText, xhr) {
					console.log(data);
					console.log(data.entry.permissions.locallySet);
					var locallySetPermissions = data.entry.permissions.locallySet;

					var add_permission = {
						"permissions":
						{
							"isInheritanceEnabled": data.entry.permissions.isInheritanceEnabled,
							"locallySet":
								[
									//{ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" }
								]
						}
					}
					// add existing permissions
					if (locallySetPermissions != undefined) {
						for (i = 0; i <= locallySetPermissions.length - 1; i++) {
							add_permission["permissions"]["locallySet"].push(locallySetPermissions[i]);
						}
					}
					// add new permissions
					if( JSON.stringify(add_permission).indexOf(new_watcher) == -1 ) {
						add_permission["permissions"]["locallySet"].push({ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" })
					}	

					//console.log(add_permission);


					$.ajax({
						type: "PUT",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"Authorization": STS.portalAuth
						},
						data: JSON.stringify(add_permission),
						url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
					}).done(function (data, statusText, xhr) {
						console.log(data);
					});

				}); // alfresco api


			}); // get user 
		}); // each

		/*
		if(
			window.location.href.indexOf('issues') != -1 && $('#content h2').text().indexOf('Rezolutie #') != -1
		) {
			$.ajax({
				type: "GET",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json"
			}).done(function (data) {
				//console.log(data);
				
				if( data.issue.tracker.id != 5 ){
					$.ajax({
						type: "GET",
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + data.issue.parent.id + ".json"
					}).done(function (data2) {
						//console.log(data2);
						
						if( data2.issue.tracker.id != 5 ){
							$.ajax({
								type: "GET",
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": 'admin'
								},
								url: "/issues/" + data2.issue.parent.id + ".json?include=children,relations,journals"
							}).done(function (data3) {
								console.log(data3);
								
								if( data3.issue.tracker.id != 5 ){
									console.log('Nu e cerere de servicii');
								} else {
									console.log('Este cerere de servicii');
															
									for(i=0;i<=data3.issue.children.length-1;i++) {
										//console.log('adaugam watchers pentru='+data3.issue.children[i].id);
										// if( data3.issue.children[i].children != undefined ) {
										// 	console.log(data3.issue.children[i].id + ' are copiii:');
										// 	for(j=0;j<=data3.issue.children[i].children.lenght-1;j++) {
										// 		console.log(data3.issue.children[i].children[j]);
										// 	}
										// }
										// add watchers							
										add_watchers(data3.issue.children[i].id,watchersJSON);
									}
									
								}
								
							});
						}						
					});
				}
							
			});
		} // if Rezolutie punem watcherii pe toti copiii cererii de serviciu
		*/
	});
	//=========================== END ALFRESCO NEW WATCHER ============================================





	//-------------------------------- ALFRESCO NEW WATCHER GROUP ------------------------------------------
	$(document).on('submit', '#new-watcher-group-form', function () {
		$('#groups_for_watcher input:checked').each(function () {
			var watchersJSON = [];
			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/groups/" + $(this).val() + ".json?include=users"  // group STS - MD - Cabinet luam toti userii si ii punem watcheri default
			}).done(function (data) {
				console.log(data);
				$.each(data.group.users, function (eachIndex) {
					watchersJSON.push(data.group.users[eachIndex].id);
				});
				console.log(watchersJSON);
				localStorage.setItem('watchersJSON',JSON.stringify(watchersJSON));
			});
			//console.log($(this).val());
			
			var new_watchers = [];
			for (i = 0; i <= watchersJSON.length - 1; i++) {

				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/users/" + watchersJSON[i] + ".json"
				}).done(function (data) {
					console.log(data.user.login);
					var new_watcher = data.user.login;
					new_watchers.push(new_watcher);			
				}); // get user id for each watcher
			} // for each watcher from group



			// --- alfresco api ---
			// var origin = "https://secretariat.stsnet.ro/";
			var origin = localStorage.getItem('alfresco_origin');
			// var nodeId = "40d5f9bf-d7b9-4952-8899-af3dd731717c";
			var nodeId = localStorage.getItem('alfresco_nodeId');
			var query = "?include=permissions";
			var i;

			if (stsAlfrescoNodeOk(origin, nodeId)) $.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"Authorization": STS.portalAuth
				},
				url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
			}).done(function (data, statusText, xhr) {
				console.log(data);
				console.log(data.entry.permissions.locallySet);
				var locallySetPermissions = data.entry.permissions.locallySet;

				var add_permission = {
					"permissions":
					{
						"isInheritanceEnabled": data.entry.permissions.isInheritanceEnabled,
						"locallySet":
							[
								//{ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" }
							]
					}
				}
				// add existing permissions
				if (locallySetPermissions != undefined) {
					for (i = 0; i <= locallySetPermissions.length - 1; i++) {
						add_permission["permissions"]["locallySet"].push(locallySetPermissions[i]);
					}
				}
				// add new permissions
				for (i = 0; i <= new_watchers.length - 1; i++) {
					if( JSON.stringify(add_permission).indexOf(new_watchers[i]) == -1 ) {
						add_permission["permissions"]["locallySet"].push({ "authorityId": new_watchers[i], "name": "Consumer", "accessStatus": "ALLOWED" })
					}							
				}				
				
				// console.log(add_permission);

				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"Authorization": STS.portalAuth
					},
					data: JSON.stringify(add_permission),
					url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
				}).done(function (data, statusText, xhr) {
					console.log(data);
				});

			}); // alfresco api


		}); // each checked watcher group from modal

		/*
		if(
			window.location.href.indexOf('issues') != -1 && $('#content h2').text().indexOf('Rezolutie #') != -1
		) {
			$.ajax({
				type: "GET",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json"
			}).done(function (data) {
				//console.log(data);
				
				if( data.issue.tracker.id != 5 ){
					$.ajax({
						type: "GET",
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + data.issue.parent.id + ".json"
					}).done(function (data2) {
						//console.log(data2);
						
						if( data2.issue.tracker.id != 5 ){
							$.ajax({
								type: "GET",
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": 'admin'
								},
								url: "/issues/" + data2.issue.parent.id + ".json?include=children,relations,journals"
							}).done(function (data3) {
								console.log(data3);
								
								if( data3.issue.tracker.id != 5 ){
									console.log('Nu e cerere de servicii');
								} else {
									console.log('Este cerere de servicii');
															
									for(i=0;i<=data3.issue.children.length-1;i++) {
										//console.log('adaugam watchers pentru='+data3.issue.children[i].id);
										// if( data3.issue.children[i].children != undefined ) {
										// 	console.log(data3.issue.children[i].id + ' are copiii:');
										// 	for(j=0;j<=data3.issue.children[i].children.lenght-1;j++) {
										// 		console.log(data3.issue.children[i].children[j]);
										// 	}
										// }
										// add watchers							
										add_watchers(data3.issue.children[i].id,JSON.parse(localStorage.getItem('watchersJSON')));
									}
									
								}
								
							});
						}						
					});
				}
							
			});
		} // if Rezolutie punem watcherii pe toti copiii cererii de serviciu
		*/
	}); // on watcher group form submit
	//=========================== END ALFRESCO NEW WATCHER GROUP ============================================




	//-------------------------------- ALFRESCO DELETE WATCHER ------------------------------------------
	$('#watchers').on('click', '.delete', function () {
		var watcher_id = $(this).attr('href').split('watchers/')[1];
		console.log(watcher_id);

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/users/" + watcher_id + ".json"
		}).done(function (data) {
			console.log(data.user.login);
			var delete_watcher = data.user.login;


			// --- alfresco api ---
			// var origin = "https://secretariat.stsnet.ro/";
			var origin = localStorage.getItem('alfresco_origin');
			// var nodeId = "40d5f9bf-d7b9-4952-8899-af3dd731717c";
			var nodeId = localStorage.getItem('alfresco_nodeId');
			var query = "?include=permissions";
			var i;

			if (stsAlfrescoNodeOk(origin, nodeId)) $.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"Authorization": STS.portalAuth
				},
				url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
			}).done(function (data, statusText, xhr) {
				console.log('delete watcher = ' + delete_watcher);
				console.log(data);
				console.log(data.entry.permissions.locallySet);
				var locallySetPermissions = data.entry.permissions.locallySet;

				if (locallySetPermissions != undefined) {
					for (i = 0; i <= locallySetPermissions.length - 1; i++) {
						if (locallySetPermissions[i]['authorityId'] == delete_watcher) {
							locallySetPermissions.splice(i, 1);

							var new_permission = {
								"permissions":
								{
									"isInheritanceEnabled": data.entry.permissions.isInheritanceEnabled,
									"locallySet": locallySetPermissions
								}
							}
							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"Authorization": STS.portalAuth
								},
								data: JSON.stringify(new_permission),
								url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
							}).done(function (data, statusText, xhr) {
								console.log(data);
							});
						}
					}
				}


			}); // alfresco api

		}); // get user login


	}); // watcher delete
	//=========================== END ALFRESCO DELETE WATCHER ============================================



	
	
	//--------------------------------- JQUERY EXPORT CSV ----------------------------------------------------
	(function ($) {
		"use strict";
		const optionsDefaults = {
			/* action='download' options */
			filename: "table.csv",

			/* action='output' options */
			appendTo: "body",

			/* general options */
			separator: ",",
			newline: "\n",
			quoteFields: true,
			trimContent: true,
			excludeColumns: "",
			excludeRows: ""
		};

		let options = {};

		function quote(text) {
			return "\"" + text.replace(/"/g, "\"\"") + "\"";
		}

		// taken from http://stackoverflow.com/questions/3665115/create-a-file-in-memory-for-user-to-download-not-through-server
		function download(filename, text) {
			const element = document.createElement("a");
			element.setAttribute("href", "data:text/csv;charset=utf-8,\ufeff" + encodeURIComponent(text));
			element.setAttribute("download", filename);

			element.style.display = "none";
			document.body.appendChild(element);

			element.click();

			document.body.removeChild(element);
		}

		function convert(table) {
			let output = "";

			const rows = table.find("tr").not(options.excludeRows);

			const numCols = rows.first().find("td,th").filter(":visible").not(options.excludeColumns).length;

			rows.each(function (ignore, elem) {
				$(elem).find("td,th").filter(":visible").not(options.excludeColumns)
					.each(function (i, col) {
						const column = $(col);

						// Strip whitespaces
						const content = options.trimContent
							? $.trim(column.text())
							: column.text();

						output += options.quoteFields
							? quote(content)
							: content;
						if (i !== numCols - 1) {
							output += options.separator;
						} else {
							output += options.newline;
						}
					});
			});

			return output;
		}

		$.fn.table2csv = function (action, opt) {
			if (typeof action === "object") {
				opt = action;
				action = "download";
			} else if (action === undefined) {
				action = "download";
			}

			// type checking
			if (typeof action !== "string") {
				throw new Error("\"action\" argument must be a string");
			}
			if (opt !== undefined && typeof opt !== "object") {
				throw new Error("\"options\" argument must be an object");
			}

			options = $.extend({}, optionsDefaults, opt);

			const table = this.filter("table"); // TODO use $.each

			if (table.length <= 0) {
				throw new Error("table2csv must be called on a <table> element");
			}

			if (table.length > 1) {
				throw new Error("converting multiple table elements at once is not supported yet");
			}

			let csv = convert(table);

			switch (action) {
			case "download":
				download(options.filename, csv);
				break;
			case "output":
				$(options.appendTo).append($("<pre>").text(csv));
				break;
			case "return":
				return csv;
			default:
				throw new Error("\"action\" argument must be one of the supported action strings");
			}

			return this;
		};

	}(jQuery));
	//================================ END JQUER EXPORT CSV ==================================================


	
	
	
	
	//------------------------------ TABEL PARENT TASK DATES ---------------------------------------------
	if( $('#content h2').text().indexOf('Activitate #') != -1 ) {
		$('#buttonChildrenDateTable').show();
	}

	$('#buttonChildrenDateTable').on('click', function(){
		$('body').append("<div id='loading_screen' class='modal_message_overlay'><div class='modal_message'><img src='" + STS.loadingGif + "'/> Va rugam asteptati, colectam datele...</div></div>");
		var i,j;
		var table_json = [];
		var counter = 0;
		$.ajax({
			type: "GET",
			//async: false,
			headers: {
			"Content-Type": "application/json",
			"X-Redmine-API-Key": STS.apiKey,
			"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=children"
		}).done(function (data) {
			var tabel_csv = 
			"<table class='with_borders' id='tabel_csv'>" +
				"<tr>" +
					"<th style='width:20%'>Parent subject</th>" +
					"<th style='width:20%'>Child subject</th>" +
					"<th style='width:30%'>Parent description</th>" +
					"<th style='width:15%'>Start Date</th>" +
					"<th style='width:15%'>Due Date</th>" +
				"</tr>";
			for(i=0;i<=data.issue.children.length-1;i++) {
				$.ajax({
					type: "GET",
					async: false,
					headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data.issue.children[i]['id'] + ".json?include=children"
				}).done(function (data_1) {
					table_json.push(
						{
							"id": data.issue.children[i]['id'],
							"subject": data_1.issue.subject,
							"description": data_1.issue.description,
							"start_date": data_1.issue.start_date,
							"due_date": data_1.issue.due_date,
							"children": []
						}
					);
					tabel_csv = tabel_csv +
					"<tr class='row_gray'>" +
						"<td>[" + data.issue.children[i]['id'] + "] " + data_1.issue.subject + "</td>" +
						"<td></td>" +
						"<td>" + data_1.issue.description + "</td>" +
						"<td>" + data_1.issue.start_date + "</td>" +
						"<td>" + data_1.issue.due_date + "</td>" +
					"</tr>";
				});
				
				if( data.issue.children[i]['children'] != undefined ) {
					for(j=0;j<=data.issue.children[i]['children'].length-1;j++) {						
						$.ajax({
							type: "GET",
							async: false,
							headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
							},
							url: "/issues/" + data.issue.children[i]['children'][j].id + ".json?include=children"
						}).done(function (data_2) {
							table_json[i]['children'].push(
								{
									"id": data_2.issue.id,
									"subject": data_2.issue.subject,
									"start_date": data_2.issue.start_date,
									"due_date": data_2.issue.due_date
								}
							);
							tabel_csv = tabel_csv +
							"<tr class='child_row' data-parentid='"+data.issue.children[i]['id']+" data-counter='"+counter+"'>" +
								"<td></td>" +
								"<td>[" + data_2.issue.id + "] " + data_2.issue.subject + "</td>" +
								"<td></td>" +								
								"<td>" + data_2.issue.start_date + "</td>" +
								"<td>" + data_2.issue.due_date + "</td>" +
							"</tr>";							
						});
					} // for j - child 2
					counter++;
				} // if has children
			} // for i - child 1
			console.log(table_json);
			tabel_csv = tabel_csv + "</table>";
			$('#newPOPUP_container_buttonChildrenDateTable').html('');
			$('#newPOPUP_container_buttonChildrenDateTable').append("<h3>Issue ID: " + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + "</h3>");
			$('#newPOPUP_container_buttonChildrenDateTable').append("<a style='display:table;margin-bottom:10px' href='javascript:void(0)' id='export_csv'>Export CSV</a>");
			$('#newPOPUP_container_buttonChildrenDateTable').append("<hr syle='margin-bottom:10px'>");
			$('#newPOPUP_container_buttonChildrenDateTable').append(tabel_csv);
			
			// sort table by start date
			function sortTable() {
				var table,rows,switching,x,y,shouldSwitch;
				table = document.getElementById('tabel_csv');
				switching = true;
				while(switching) {
					switching = false;
					rows = table.rows;
					for(i=1;i<rows.length-1;i++) {
						shouldSwitch = false;
						x = rows[i].getElementsByTagName('TD')[3].innerHTML;
						y = rows[i+1].getElementsByTagName('TD')[3].innerHTML;
						if( Date.parse(x) > Date.parse(y) ) {
							shouldSwitch = true;
							break;
						}
					}
					if( shouldSwitch ) {
						rows[i].parentNode.insertBefore( rows[i+1], rows[i] );
						switching = true;
					}
				}
			} // sortTable()
			
			sortTable();
			
			// export table to csv
			$('#newPOPUP_container_buttonChildrenDateTable').on('click', '#export_csv', function(){
				//$('#tabel_csv').table2csv();
				$('#tabel_csv').table2csv('download',{'filename': window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + '_sumar'});
			});
			$('#newPOPUP_overlay_buttonChildrenDateTable').show();
			$('#loading_screen').remove();
		});
	}); // #buttonChildrenDateTable click
	
	$('#newPOPUP_close_buttonChildrenDateTable').on('click', function(){
		$('#newPOPUP_overlay_buttonChildrenDateTable').hide();
	});
	//============================= END TABEL PARENT TASK DATES ===========================================






	//---------------------- GENEREAZA RAPORT CHILDREN RELATIONS ISSUE ------------------------------------------------
	//if( $('#loggedas .user').text() == 'admin' || $('#loggedas .user').text() == 'manuela.sarateanu' || $('#loggedas .user').text() == 'diblus.daniela'  || $('#loggedas .user').text() == 'radu.pereteanu' ) {
	//$('#buttonChildrenRelatedReport').show();
	//}	

	if ( /*localStorage.getItem('currentIssue_project_id') == 822*/ 1) {
		$('#buttonChildrenRelatedReport').show();
	}

	if (localStorage.getItem('currentIssue_project_id') == 935) {
		$('#buttonChildrenRelatedReport').hide();
	}

	$('#newPOPUP_close_genereazaRaportChildrenRelations').on('click', function () {
		$('#newPOPUP_overlay_genereazaRaportChildrenRelations').hide();
	});


	$('#buttonChildrenRelatedReport').on('click', function () {

		var x = 0;

		$('#newPOPUP_container_genereazaRaportChildrenRelations').html('');

		$.ajax({
			type: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=children,relations,journals"
		}).done(function (data) {
			console.log(data);

			var childLevel = 1;

			//$('#newPOPUP_container_genereazaRaportChildrenRelations').text(JSON.stringify(data));

			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<h3>[" + data.issue.id + "] - [" + data.issue.tracker.name + "] - " + data.issue.subject + "</h3>");
			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<h3>Status: " + data.issue.status.name + "</h3>");

			function reportAppendChild(index, child_id, child_type, trackerID, subtaskRelated) {

				if (trackerID == 49 && child_id != data.issue.id) { // daca e Solicitare aprobare (49)					
					var child =
						"<fieldset style='margin: 20px 0px' class='fieldsetIssue' id='fieldsetIssue_" + child_id + "_" + x + "'>" +
						"<legend>" + parseInt(index + 1) + ". [<a target='_blank' href='/issues/" + child_id + "'>" + child_id + "</a>] " + " - [<span class='reportChild_tracker_" + child_id + "_" + x + "'></span>] - " + "<span class='reportChild_subject_" + child_id + "_" + x + "'> </span></legend>" +
						"<div><strong>Status</strong>: <span class='reportChild_status_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Data creat</strong>: <span class='reportChild_dateCreated_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Data modificat</strong>: <span class='reportChild_dateChangeStatus_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Data sch status</strong>: <span class='reportChild_dateOpenAprobatAnulat_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Asignat</strong>: <span class='reportChild_asignee_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Procent</strong>: <span class='reportChild_percentage_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Document spre aprobare</strong>: <span class='reportChild_linkCV_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Cerere de servicii</strong>: <span class='reportChild_linkCVRelated_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Notes</strong>: <span class='reportChild_notes_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Subtask-uri</strong>: <span class='reportChild_children_" + child_id + "_" + x + "'> </span></div>" +
						"</fieldset>";
				} else {
					var child =
						"<fieldset style='margin: 20px 0px' class='fieldsetIssue' id='fieldsetIssue_" + child_id + "_" + x + "'>" +
						"<legend>" + parseInt(index + 1) + ". [<a target='_blank' href='/issues/" + child_id + "'>" + child_id + "</a>] " + " - [<span class='reportChild_tracker_" + child_id + "_" + x + "'></span>] - " + "<span class='reportChild_subject_" + child_id + "_" + x + "'> </span></legend>" +
						"<div><strong>Status</strong>: <span class='reportChild_status_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Data creat</strong>: <span class='reportChild_dateCreated_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Data modificat</strong>: <span class='reportChild_dateChangeStatus_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Data sch status</strong>: <span class='reportChild_dateOpenAprobatAnulat_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Asignat</strong>: <span class='reportChild_asignee_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Procent</strong>: <span class='reportChild_percentage_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Link CV</strong>: <span class='reportChild_linkCV_" + child_id + "_" + x + "'> </span></div>" +

						"<div><strong>Notes</strong>: <span class='reportChild_notes_" + child_id + "_" + x + "'> </span></div>" +
						"<div><strong>Subtask-uri</strong>: <span class='reportChild_children_" + child_id + "_" + x + "'> </span></div>" +
						"</fieldset>";
				}


				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + child_id + ".json?include=children,relations,journals"
				}).done(function (data) {

					$('.reportChild_subject_' + child_id + "_" + x).text(data.issue.subject);
					$('.reportChild_subject_' + child_id + "_" + x).text(data.issue.subject);
					$('.reportChild_tracker_' + child_id + "_" + x).text(data.issue.tracker.name);
					$('.reportChild_status_' + child_id + "_" + x).text(data.issue.status.name);
					$('.reportChild_dateCreated_' + child_id + "_" + x).text(data.issue.created_on.replace('T', ' ').replace('Z', ' '));
					$('.reportChild_dateChangeStatus_' + child_id + "_" + x).text(data.issue.updated_on.replace('T', ' ').replace('Z', ' '));
					if (data.issue.assigned_to != undefined) {
						$('.reportChild_asignee_' + child_id + "_" + x).text(data.issue.assigned_to.name);
					}
					$('.reportChild_percentage_' + child_id + "_" + x).text(data.issue.done_ratio + "%");

					//-------------- Solicitare aprobare document relationat CV Link -------------
					if (data.issue.relations != undefined) {
						$.each(data.issue.relations, function (eachIndex) {
							$.ajax({
								type: "GET",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": 'admin'
								},
								url: "/issues/" + data.issue.relations[eachIndex].issue_to_id + ".json"
							}).done(function (data) {
								//var relatedCounter = 1;
								$.each(data.issue.custom_fields, function (eachIndex) {
									if ((data.issue.custom_fields[eachIndex].id == 24 /*|| data.issue.custom_fields[eachIndex].id == 34*/) && data.issue.custom_fields[eachIndex].value != "") {
										$('.reportChild_linkCVRelated_' + child_id + "_" + x).append("<div style='margin-left:40px'> - <a target='_blank' href='" + data.issue.custom_fields[eachIndex].value + "'>Cerere de servicii " /*+ relatedCounter*/ + "</a></div>");
									}
								});
							});
						});
					}

					//-------------- Solicitare aprobare calculam durata Open>Aprobat -------------
					var date1 = "";
					var date2 = "";
					$.each(data.issue.journals, function (eachIndex) {
						$.each(data.issue.journals[eachIndex].details, function (eachIndex1) {
							if (data.issue.journals[eachIndex].details[eachIndex1].name == 'status_id') {
								if (data.issue.journals[eachIndex].details[eachIndex1].new_value == '1') {  // cand devine OPEN (1)
									$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:20px'>- Data cand a devenit Open: " + data.issue.journals[eachIndex].created_on.replace('T', ' ').replace('Z', '') + "</div>");
									date1 = new Date(data.issue.journals[eachIndex].created_on);
								}

								if ( // cand devine Aprobat (24)
									data.issue.journals[eachIndex].details[eachIndex1].new_value == '24'
								) {
									$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:20px'>- Data cand a devenit Aprobat: " + data.issue.journals[eachIndex].created_on.replace('T', ' ').replace('Z', '') + "</div>");
									date2 = new Date(data.issue.journals[eachIndex].created_on);
								}
								if ( // Aprobat cu obs (26)
									data.issue.journals[eachIndex].details[eachIndex1].new_value == '26'
								) {
									$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:20px'>- Data cand a devenit Aprobat cu observatii: " + data.issue.journals[eachIndex].created_on.replace('T', ' ').replace('Z', '') + "</div>");
									date2 = new Date(data.issue.journals[eachIndex].created_on);
								}
								if ( // cand devine Aprobat (24), Aprobat cu obs (26), Anulat (27)							
									data.issue.journals[eachIndex].details[eachIndex1].new_value == '27'
								) {
									$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:20px'>- Data cand a devenit Anulat: " + data.issue.journals[eachIndex].created_on.replace('T', ' ').replace('Z', '') + "</div>");
									date2 = new Date(data.issue.journals[eachIndex].created_on);
								}
							}
						});
					});
					if (date1 != "" && date2 != "") {
						var msec = date2 - date1;
						var mins = Math.floor(msec / 60000);
						var hrs = Math.floor(mins / 60);
						var days = Math.floor(hrs / 24);
						var yrs = Math.floor(days / 365);
						mins = mins % 60;
						hrs = hrs % 24;
						/*if(  
							$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).indexOf("<div style='margin-left:40px;font-style:italic'>(Durata: " + days + " zile, " + hrs + " ore, " + mins + " minute" + ")</div>") == -1
						) {*/
						$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:40px;font-style:italic'>(Durata: " + days + " zile, " + hrs + " ore, " + mins + " minute" + ")</div>");
						//}	
					}
					if ((date1 == "" || date1 == undefined) && date2 != "") {

						date1 = new Date(data.issue.created_on);
						var msec = date2 - date1;
						var mins = Math.floor(msec / 60000);
						var hrs = Math.floor(mins / 60);
						var days = Math.floor(hrs / 24);
						var yrs = Math.floor(days / 365);
						mins = mins % 60;
						hrs = hrs % 24;
						$('.reportChild_dateOpenAprobatAnulat_' + child_id + "_" + x).append("<div style='margin-left:40px;font-style:italic'>(Durata: " + days + " zile, " + hrs + " ore, " + mins + " minute" + ")</div>");
					}

					//-------------- CV Link -------------
					$.each(data.issue.custom_fields, function (eachIndex) {
						if ((data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && data.issue.custom_fields[eachIndex].value != "") {
							$('.reportChild_linkCV_' + child_id + "_" + x).html("<a target='_blank' href='" + data.issue.custom_fields[eachIndex].value + "'>Click aici</a>");
						}
					});

					//-------------- Notes -------------
					noteIndex = 0;
					$.each(data.issue.journals, function (eachIndex) {
						if (data.issue.journals[eachIndex].notes != "") {
							var note_user = data.issue.journals[eachIndex].user.name;
							var note_date = data.issue.journals[eachIndex].created_on.replace('T', ' ').replace('Z', ' ');
							var note_text = data.issue.journals[eachIndex].notes;
							$('.reportChild_notes_' + child_id + "_" + x).append(
								"<div style='margin-left:20px'>" + parseInt(noteIndex + 1) + ". " + note_user + " [" + note_date + "]<br>" + note_text + "</div>"
							);
							noteIndex = noteIndex + 1;
						}
					});


					if (subtaskRelated == 'subtask') {
						if (data.issue.children != undefined) {
							childLevel = childLevel + 1;
							$.each(data.issue.children, function (eachIndex) {
								var child_x_id = data.issue.children[eachIndex].id;
								$.ajax({
									type: "GET",
									async: false,
									headers: {
										"Content-Type": "application/json",
										"X-Redmine-API-Key": STS.apiKey,
										"X-Redmine-Switch-User": 'admin'
									},
									url: "/issues/" + child_x_id + ".json?include=children,relations,journals"
								}).done(function (data) {
									if (data.issue.tracker.id == 49) { // daca e Solicitare aprobare (49)																		
										var child_x =
											"<fieldset style='margin: 20px 0px' class='fieldsetIssue' id='fieldsetIssue_" + child_x_id + "_" + x + "'>" +
											"<legend>" /*+ parseInt(index+1) + "."*/ + parseInt(eachIndex + 1) + ". [<a target='_blank' href='/issues/" + child_x_id + "'>" + child_x_id + "</a>] " + " - [<span class='reportChild_tracker_" + child_x_id + "_" + x + "'></span>] - " + "<span class='reportChild_subject_" + child_x_id + "_" + x + "'> </span></legend>" +
											"<div><strong>Status</strong>: <span class='reportChild_status_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Data creat</strong>: <span class='reportChild_dateCreated_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Data modificat</strong>: <span class='reportChild_dateChangeStatus_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Data sch status</strong>: <span class='reportChild_dateOpenAprobatAnulat_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Asignat</strong>: <span class='reportChild_asignee_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Procent</strong>: <span class='reportChild_percentage_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Document spre aprobare</strong>: <span class='reportChild_linkCV_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Cerere de servicii</strong>: <span class='reportChild_linkCVRelated_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Notes</strong>: <span class='reportChild_notes_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Subtask-uri</strong>: <span class='reportChild_children_" + child_x_id + "_" + x + "'> </span></div>" +
											"</fieldset>";
									} else {
										var child_x =
											"<fieldset style='margin: 20px 0px' class='fieldsetIssue' id='fieldsetIssue_" + child_x_id + "_" + x + "'>" +
											"<legend>" /*+ parseInt(index+1) + "."*/ + parseInt(eachIndex + 1) + ". [<a target='_blank' href='/issues/" + child_x_id + "'>" + child_x_id + "</a>] " + " - [<span class='reportChild_tracker_" + child_x_id + "_" + x + "'></span>] - " + "<span class='reportChild_subject_" + child_x_id + "_" + x + "'> </span></legend>" +
											"<div><strong>Status</strong>: <span class='reportChild_status_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Data creat</strong>: <span class='reportChild_dateCreated_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Data modificat</strong>: <span class='reportChild_dateChangeStatus_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Data sch status</strong>: <span class='reportChild_dateOpenAprobatAnulat_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Asignat</strong>: <span class='reportChild_asignee_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Procent</strong>: <span class='reportChild_percentage_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Link CV</strong>: <span class='reportChild_linkCV_" + child_x_id + "_" + x + "'> </span></div>" +

											"<div><strong>Notes</strong>: <span class='reportChild_notes_" + child_x_id + "_" + x + "'> </span></div>" +
											"<div><strong>Subtask-uri</strong>: <span class='reportChild_children_" + child_x_id + "_" + x + "'> </span></div>" +
											"</fieldset>";
									}


									reportAppendChild(eachIndex, child_x_id, 2, data.issue.tracker.id, 'subtask');
									$('.reportChild_children_' + child_id + "_" + x).append(child_x);


								});


							});
						} // if children
					} // if subtaskRelated


				});

				if (child_type == 1) {
					$('#newPOPUP_container_genereazaRaportChildrenRelations').append(child);
				}
				if (child_type == 2) {
					$('.reportChild_children_' + child_id + "_" + x).append(child);
				}
			} // function reportAppendChild()



















			//--------------- SUBTASKS ------------------------------------------------------------------------------------------
			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<hr><br>");
			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<h3>Subtask-uri [<span id='reportSubtaskCount'>0</span>]</h3>");
			if (data.issue.children != undefined) {
				for (i = 0; i <= data.issue.children.length - 1; i++) {
					reportAppendChild(i, data.issue.children[i].id, 1, data.issue.children[i].tracker.id, 'subtask');
				} // for pentru subtask-uri
				$('#reportSubtaskCount').text(data.issue.children.length);
			}







			//--------------- RELATED ISSUES ------------------------------------------------------------------------------------------
			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<br>");
			$("#newPOPUP_container_genereazaRaportChildrenRelations").append("<h3>Related issues [<span id='reportRelatedCount'>0</span>]</h3>");
			if (data.issue.relations != undefined) {
				$('#reportRelatedCount').text(data.issue.relations.length);
				for (i = 0; i <= data.issue.relations.length - 1; i++) {
					if (data.issue.relations[i].issue_id == data.issue.id) {
						var issueRelationsID = data.issue.relations[i].issue_to_id;
					} else {
						var issueRelationsID = data.issue.relations[i].issue_id;
					}
					var currentIssueID = data.issue.id;

					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + issueRelationsID + ".json?include=children,relations,journals"
					}).done(function (dataChild) {
						if (currentIssueID != issueRelationsID) {
							//console.log(issueRelationsID);
							reportAppendChild(i, issueRelationsID, 1, dataChild.issue.tracker.id, 'related');
						}
						//reportAppendChild( i, issueRelationsID, 1, dataChild.issue.tracker.id, 'related' );				
					});

					/*if(data.issue.id != issueRelationsID) {
						//console.log(issueRelationsID);
						reportAppendChild( i, issueRelationsID, 1, 20, 'related' );
					}*/

				} // for pentru related issues
			}

		}); // ajax get issue for reporting


		//-----ar trebui show dupa ce se termina ajax request
		$('#newPOPUP_overlay_genereazaRaportChildrenRelations').show();
	}); // buttonChildrenRelatedReport click
	//===================== END GENEREAZA RAPORT CHILDREN RELATIONS ISSUE =====================================













	//---------------------- SAVE Logged USER id and name -------------------------------------
	/*$.ajax({
		type:"GET",
		async:false,
		headers: {
			"Content-Type": "application/json",
			"X-Redmine-API-Key": STS.apiKey,
			"X-Redmine-Switch-User": $('#loggedas .user').text()},		
		url:"/users/current.json"
	}).done(function(data){
		//console.log(data.user.id);
		//console.log(data.user.firstname + ' ' + data.user.lastname);
		localStorage.setItem('logged_user_id',data.user.id);
		localStorage.setItem('logged_user_name',data.user.firstname + ' ' + data.user.lastname);
	});*/




	//--------------------- ADD LAST UPDATED FOR on subtask mouseover -------------------------
	$('.list.issues.odd-even tr').on('mouseover', function () {
		if ($(this).has('td.lastUpdatedMouseover').length == 0 && $(this).attr('class') != undefined) {
			if ($(this).attr('class').split('issue-')[1] != undefined) {
				var mouseoverIssueId = $(this).attr('class').split('issue-')[1].split(' ')[0];
				$(this).append("<td class='lastUpdatedMouseover' id='lastUpdatedMouseover_" + mouseoverIssueId + "'></td>");
				$.ajax({
					type: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + mouseoverIssueId + ".json?include=watchers"
				}).done(function (data) {
					//console.log(data.issue.journals);

					//-------------- ADD in asteptare to created/updated on ----------------
					var status_in_asteptare;
					$.each(data.issue.custom_fields, function (index) {
						if (data.issue.custom_fields[index].id == 98 && data.issue.custom_fields[index].value != undefined && data.issue.custom_fields[index].value != "") {
							status_in_asteptare = data.issue.custom_fields[index].value;
						}
					});


					if (data.issue.journals != undefined) {
						for (i = 0; i <= data.issue.journals.length - 1; i++) {
							for (j = 0; j <= data.issue.journals[i].details.length - 1; j++) {
								if (data.issue.journals[i].details[j].name == "status_id") {
									//console.log(data.issue.journals[i].details[j]);
									var lastStatusChangeDate = data.issue.journals[i].created_on;
								}
							}
						}
						if (lastStatusChangeDate != undefined) {
							console.log(lastStatusChangeDate);
							var lastStatusChangeDate_hour = (parseInt(lastStatusChangeDate.split("T")[1].split("Z")[0].split(":")[0]) + 3) % 24;
							if (lastStatusChangeDate_hour.length < 2) {
								lastStatusChangeDate_hour = "0" + lastStatusChangeDate_hour;
							}
							var lastStatusChangeDate_new = lastStatusChangeDate.split("T")[0] + " | " + lastStatusChangeDate_hour + ":" + lastStatusChangeDate.split("T")[1].split("Z")[0].split(":")[1] + ":" + lastStatusChangeDate.split("T")[1].split("Z")[0].split(":")[2];
							console.log(status_in_asteptare);
							if (status_in_asteptare == undefined || status_in_asteptare == "" || status_in_asteptare == 0) {
								$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new);
							} else {
								$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new + " | In asteptare");
							}
						} else {
							var lastUpdatedDate = data.issue.updated_on;
							var lastUpdatedDate_hour = (parseInt(lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[0]) + 3) % 24;
							if (lastUpdatedDate_hour.length < 2) {
								lastUpdatedDate_hour = "0" + lastUpdatedDate_hour;
							}
							var lastStatusChangeDate_new = lastUpdatedDate.split("T")[0] + " | " + lastUpdatedDate_hour + ":" + lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[1] + ":" + lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[2];
							//$("#lastUpdatedMouseover_" + mouseoverIssueId).text(data.issue.updated_on.replace('T',' ').replace('Z',''));
							console.log(status_in_asteptare);
							if (status_in_asteptare == undefined || status_in_asteptare == "" || status_in_asteptare == 0) {
								$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new);
							} else {
								$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new + " | In asteptare");
							}
						}
					} else {
						var lastUpdatedDate = data.issue.updated_on;
						var lastUpdatedDate_hour = (parseInt(lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[0]) + 3) % 24;
						if (lastUpdatedDate_hour.length < 2) {
							lastUpdatedDate_hour = "0" + lastUpdatedDate_hour;
						}
						var lastStatusChangeDate_new = lastUpdatedDate.split("T")[0] + " | " + lastUpdatedDate_hour + ":" + lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[1] + ":" + lastUpdatedDate.split("T")[1].split("Z")[0].split(":")[2];
						//$("#lastUpdatedMouseover_" + mouseoverIssueId).text(data.issue.updated_on.replace('T',' ').replace('Z',''));
						console.log(status_in_asteptare);
						if (status_in_asteptare == undefined || status_in_asteptare == "" || status_in_asteptare == 0) {
							$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new);
						} else {
							$("#lastUpdatedMouseover_" + mouseoverIssueId).text(lastStatusChangeDate_new + " | In asteptare");
						}
					}
				});
			}
		}
	});
	/*
	$('.list.issues.odd-even tr').on('mouseout',function(){				
		$('tr.issue-' + $(this).attr('class').split('issue-')[1].split(' ')[0] + ' .lastUpdatedMouseover').remove();
	});
	*/




	//------------------ AUTO UPDATE CLOSE by PERCENT --------------
	setInterval(function () {
		if (document.getElementById('issue_done_ratio') != null) {

			//if(
			//	( document.getElementById('issue_tracker_id').value == 6) ||   // Rezolutie
			//	( document.getElementById('issue_tracker_id').value == 15) ||  // Document intern
			//	( document.getElementById('issue_tracker_id').value == 52) 	   // Repartitie	 		
			//) {	
			if ($._data($('#issue_done_ratio')[0], 'events') == undefined) {
				$('#issue_done_ratio').change(function () {
					if ($('#issue_done_ratio').val() == 100) {
						$('#issue_status_id').val(8);
					} else {
						$('#issue_status_id').val(1);
					}
					if (window.location.pathname.indexOf('/edit') != -1) {
						updateIssueFrom(window.location.pathname + '.js', $('#issue_status_id'));
					} else {
						updateIssueFrom(window.location.pathname + '/edit.js', $('#issue_status_id'));
					}
				});
			}
			//}  

		}

	}, 500);
	//============= END AUTO UPDATE CLOSE by PERCENT ===============




	//-------------------------- ADAUGARE REZOLUTIE DIN REPARTITIE si ADAUGARE REZOLUTIE DIN DOCUMENT ELECTRONIC -----------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Repartitie #') != -1 || $('#content h2').text().indexOf('Document electronic #') != -1)
	) {

		$('#buttonNewRezIfRepart').show();
	} // if repartitie , show button for new rezolutie	

	function getWatchersForNewRezolutie2() {
		//----------------- get watchers via api --------------
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {


			console.log(data.issue.watchers.length + ' watchers GET successfully');
			//console.log(data.issue.watchers.length);			

			var directii_json = {
				"CM": 222,
				"CPP": 513,
				"DAP": 221,
				"DCAOSR": 217,
				"DCDSSI": 218,
				"DCPD": 211,
				"DCRB": 223,
				"DCRE": 229,
				"DEFC": 219,
				"DESA": 215,
				"DESR": 216,
				"DJSG": 230,
				"DJTS ALBA": 228,
				"DJTS ARAD": 471,
				"DJTS ARGES": 472,
				"DJTS BACAU": 473,
				"DJTS BIHOR": 474,
				"DJTS BISTRITA-NASAUD": 475,
				"DJTS BOTOSANI": 476,
				"DJTS BRAILA": 478,
				"DJTS BRASOV": 477,
				"DJTS BUZAU": 481,
				"DJTS CALARASI": 483,
				"DJTS CARAS-SEVERIN": 482,
				"DJTS CLUJ": 484,
				"DJTS CONSTANTA": 485,
				"DJTS COVASNA": 486,
				"DJTS DAMBOVITA": 487,
				"DJTS DOLJ": 488,
				"DJTS GALATI": 489,
				"DJTS GIURGIU": 490,
				"DJTS GORJ": 511,
				"DJTS HARGHITA": 491,
				"DJTS HUNEDOARA": 492,
				"DJTS IALOMITA": 493,
				"DJTS IASI": 494,
				"DJTS MARAMURES": 495,
				"DJTS MEHEDINTI": 496,
				"DJTS MURES": 497,
				"DJTS NEAMT": 498,
				"DJTS OLT": 499,
				"DJTS PRAHOVA": 500,
				"DJTS SALAJ": 502,
				"DJTS SATU MARE": 501,
				"DJTS SIBIU": 504,
				"DJTS SUCEAVA": 505,
				"DJTS TELEORMAN": 507,
				"DJTS TIMIS": 503,
				"DJTS TULCEA": 506,
				"DJTS VALCEA": 509,
				"DJTS VASLUI": 508,
				"DJTS VRANCEA": 510,
				"DL": 220,
				"DMP": 226,
				"DMRU": 231,
				"DOES": 225,
				"DOMO": 224,
				"DSCSTI": 234,
				"DSI": 232,
				"DTI": 210,
				"SIAPI": 235,
				"SICCD": 233
			}


			var customFields = data.issue.custom_fields;
			for (i = 0; i <= customFields.length - 1; i++) {
				delete customFields[i].name;
			}

			//------------------ LOCKED USERS don't propagate watchers --------------
			/*
			$.ajax({
				type:"GET",
				async:false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'},		
				url:"/users.json?status=3&limit=100"
			}).done(function(data){
				console.log(data);
				var lockedUsers=data;
			});
			*/

			/*---------------------- WATCHER LOCKED -------------------------*/
			var users_locked = [];
			var j = 0;
			for (i = 0; i <= $('.watchers li').length - 1; i++) {
				if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
					users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
				}
				if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
					users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
				}
			}


			//var watchersJSON = ["163","243","339","438","610"];
			var watchersJSON = [];
			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/groups/" + "1353" + ".json?include=users"  // group STS - MD - Cabinet luam toti userii si ii punem watcheri default
			}).done(function (data) {
				$.each(data.group.users, function (eachIndex) {
					watchersJSON.push(data.group.users[eachIndex].id);
				});
			});




			for (i = 0; i <= data.issue.watchers.length - 1; i++) {
				if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
					watchersJSON.push((data.issue.watchers[i].id).toString());
				} else {
					console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
				}
			}

			console.log(watchersJSON);

			/*--------- REMOVE WATCHERS DUPLICATES ---------*/
			var unique_watchersJSON = [];

			$.each(watchersJSON, function (i, el) {
				if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
			});
			watchersJSON = unique_watchersJSON
			console.log(watchersJSON);
			/*======= END REMOVE WATCHERS DUPLICATES ========*/


			var parentTask = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];

			var project_id;
			var assigned_to = $('.assigned-to .value').text().split(' - Conducere')[0];

			project_id = directii_json[$('.assigned-to .value').text().split(' - Conducere')[0]];


			if( $('#content h2').text().indexOf('Document electronic #') != -1 ) {
				var newRezolutieIssue =
				{
					"issue":
					{
						"project_id": data.issue.project.id,//project_id
						//"author_id": data.issue.author.id,//author_id 
						"tracker_id": 6,
						"status_id": 4,
						"priority_id": 2,
						"subject": "Rezolutie:",
						//"description": "Descriere de test POST ISSUE",
						//"category_id": XXX,
						"fixed_version_id": data.issue.fixed_version,
						//"assigned_to_id": data.issue.assigned_to.id,
						"parent_issue_id": window.location.href.split('/issues/')[1].split('?')[0].split('#')[0],
						//"custom_fields": customFields,
						//"watcher_user_ids": watchersJSON,
						//"is_private": XXX,
						//"estimated_hours": XXX
					}
				}
			} else {
				var newRezolutieIssue =
				{
					"issue":
					{
						"project_id": data.issue.project.id,//project_id
						//"author_id": data.issue.author.id,//author_id 
						"tracker_id": 6,
						"status_id": 4,
						"priority_id": 2,
						"subject": "Rezolutie:",
						//"description": "Descriere de test POST ISSUE",
						//"category_id": XXX,
						"fixed_version_id": data.issue.fixed_version,
						//"assigned_to_id": data.issue.assigned_to.id,
						"parent_issue_id": window.location.href.split('/issues/')[1].split('?')[0].split('#')[0],
						//"custom_fields": customFields,
						"watcher_user_ids": watchersJSON,
						//"is_private": XXX,
						//"estimated_hours": XXX
					}
				}
			}

			$.ajax({
				type: "POST",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				},
				url: "/issues.json",
				data: JSON.stringify(newRezolutieIssue)
			}).done(function (data) {

				//--- parent devine ASSIGNED ---
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json",
					data: JSON.stringify({ "issue": { "status_id": "5" } }) // parent devine ASSIGNED
				}).done(function (data2) {
					console.log(data2);
				});

				setTimeout(function () {
					//alert("Rezolutia "+data.issue.id+" a fost creata cu succes!");	
					$('#content').prepend("<div class='flash notice' id='flash_notice'>Rezolutia " + data.issue.id + " a fost creata cu succes! \n \n Link: <a target='_blank' href='" + window.location.origin + "/issues/" + data.issue.id + "'>" + window.location.origin + "/issues/" + data.issue.id + "</a></div>");
					console.log("Rezolutia " + data.issue.id + " a fost creata cu succes!");
					window.open(window.location.origin + "/issues/" + data.issue.id);
					window.location.reload();
				}, 500);


				$.ajax({
					type: "PUT",
					//async:false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + data.issue.id + ".json",
					data: JSON.stringify({ "issue": { "project_id": project_id } })
				}).done(function (data) {
				}); // done PUT update to new project





			}); // done POST create new issue

		}); // done GET parent issue parameters


	} // function getWatchersForNewRezolutie2()


	$("#buttonNewRezIfRepart").on('click', function () {
		console.log('Click button Adauga rezolutie');

		getWatchersForNewRezolutie2();
	});

	//============================= END ADAUGARE REZOLUTIE DIN REPARTITIE si ADAUGARE REZOLUTIE DIN DOCUMENT ELECTRONIC ===============================








	//-------------------------- ADAUGARE ACORDARE PERMISIUNE DIN REGLEMENTARI -----------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Reglementari #') != -1)
	) {

		$('#button_adaugaPermisiuneReglementare').show();
	} // if repartitie , show button for new rezolutie	

	function adaugaPermisiuneReglementare() {
		//----------------- get watchers via api --------------
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {


			//console.log(data.issue.watchers.length + ' watchers GET successfully');
			//console.log(data.issue.watchers.length);			

			var directii_json = {
				"CM": 222,
				"CPP": 513,
				"DAP": 221,
				"DCAOSR": 217,
				"DCDSSI": 218,
				"DCPD": 211,
				"DCRB": 223,
				"DCRE": 229,
				"DEFC": 219,
				"DESA": 215,
				"DESR": 216,
				"DJSG": 230,
				"DJTS ALBA": 228,
				"DJTS ARAD": 471,
				"DJTS ARGES": 472,
				"DJTS BACAU": 473,
				"DJTS BIHOR": 474,
				"DJTS BISTRITA-NASAUD": 475,
				"DJTS BOTOSANI": 476,
				"DJTS BRAILA": 478,
				"DJTS BRASOV": 477,
				"DJTS BUZAU": 481,
				"DJTS CALARASI": 483,
				"DJTS CARAS-SEVERIN": 482,
				"DJTS CLUJ": 484,
				"DJTS CONSTANTA": 485,
				"DJTS COVASNA": 486,
				"DJTS DAMBOVITA": 487,
				"DJTS DOLJ": 488,
				"DJTS GALATI": 489,
				"DJTS GIURGIU": 490,
				"DJTS GORJ": 511,
				"DJTS HARGHITA": 491,
				"DJTS HUNEDOARA": 492,
				"DJTS IALOMITA": 493,
				"DJTS IASI": 494,
				"DJTS MARAMURES": 495,
				"DJTS MEHEDINTI": 496,
				"DJTS MURES": 497,
				"DJTS NEAMT": 498,
				"DJTS OLT": 499,
				"DJTS PRAHOVA": 500,
				"DJTS SALAJ": 502,
				"DJTS SATU MARE": 501,
				"DJTS SIBIU": 504,
				"DJTS SUCEAVA": 505,
				"DJTS TELEORMAN": 507,
				"DJTS TIMIS": 503,
				"DJTS TULCEA": 506,
				"DJTS VALCEA": 509,
				"DJTS VASLUI": 508,
				"DJTS VRANCEA": 510,
				"DL": 220,
				"DMP": 226,
				"DMRU": 231,
				"DOES": 225,
				"DOMO": 224,
				"DSCSTI": 234,
				"DSI": 232,
				"DTI": 210,
				"SIAPI": 235,
				"SICCD": 233
			}

			var grupuri_json = {
				"CM": 2630,
				"CPP": 2612,
				"DAP": 2629,
				"DCAOSR": 2625,
				"DCDSSI": 2626,
				"DCPD": 2622,
				"DCRB": 2618,
				"DCRE": 2617,
				"DEFC": 2627,
				"DESA": 2624,
				"DESR": 2623,
				"DJSG": 2610,
				"DJTS ALBA": 2570,
				"DJTS ARAD": 2571,
				"DJTS ARGES": 2572,
				"DJTS BACAU": 2573,
				"DJTS BIHOR": 2574,
				"DJTS BISTRITA-NASAUD": 2575,
				"DJTS BOTOSANI": 2576,
				"DJTS BRAILA": 2578,
				"DJTS BRASOV": 2577,
				"DJTS BUZAU": 2579,
				"DJTS CALARASI": 2581,
				"DJTS CARAS-SEVERIN": 2580,
				"DJTS CLUJ": 2582,
				"DJTS CONSTANTA": 2583,
				"DJTS COVASNA": 2584,
				"DJTS DAMBOVITA": 2585,
				"DJTS DOLJ": 2586,
				"DJTS GALATI": 2587,
				"DJTS GIURGIU": 2588,
				"DJTS GORJ": 2589,
				"DJTS HARGHITA": 2590,
				"DJTS HUNEDOARA": 2591,
				"DJTS IALOMITA": 2592,
				"DJTS IASI": 2593,
				"DJTS MARAMURES": 2594,
				"DJTS MEHEDINTI": 2595,
				"DJTS MURES": 2596,
				"DJTS NEAMT": 2597,
				"DJTS OLT": 2598,
				"DJTS PRAHOVA": 2599,
				"DJTS SALAJ": 2601,
				"DJTS SATU MARE": 2600,
				"DJTS SIBIU": 2602,
				"DJTS SUCEAVA": 2603,
				"DJTS TELEORMAN": 2604,
				"DJTS TIMIS": 2605,
				"DJTS TULCEA": 2606,
				"DJTS VALCEA": 2608,
				"DJTS VASLUI": 2607,
				"DJTS VRANCEA": 2609,
				"DL": 2628,
				"DMP": 2621,
				"DMRU": 2611,
				"DOES": 2620,
				"DOMO": 2619,
				"DSCSTI": 2614,
				"DSI": 2613,
				"DTI": 2569,
				"SIAPI": 2615,
				"SICCD": 2616
			}

			var project_id = directii_json[localStorage.getItem('logged_user_directie')];
			var asignee_group_id = grupuri_json[localStorage.getItem('logged_user_directie')];

			var newIssue =
			{
				"issue":
				{
					"project_id": data.issue.project.id,//project_id
					//"author_id": data.issue.author.id,//author_id 
					"tracker_id": 68, // Acordare permisiune
					"status_id": 4,
					"priority_id": 2,
					"subject": "Pentru: ",
					//"description": "Descriere de test POST ISSUE",
					//"category_id": XXX,
					"fixed_version_id": data.issue.fixed_version,
					"assigned_to_id": data.issue.assigned_to.id,
					"parent_issue_id": window.location.href.split('/issues/')[1].split('?')[0].split('#')[0],
					//"custom_fields": customFields,
					//"watcher_user_ids": watchersJSON,
					//"is_private": XXX,
					//"estimated_hours": XXX						
				}
			}

			$.ajax({
				type: "POST",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues.json",
				data: JSON.stringify(newIssue)
			}).done(function (data) {

				// move to project
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data.issue.id + ".json",
					data: JSON.stringify({ "issue": { "project_id": project_id, "notes": "Issue creat de catre " + localStorage.getItem('logged_user_name') } })
				}).done(function (data) {
				}); // done PUT update to new project

				// assign to directie - admin reglementari
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data.issue.id + ".json",
					data: JSON.stringify({ "issue": { "assigned_to_id": asignee_group_id } })
				}).done(function (data) {
				}); // done PUT update assigned to group

				setTimeout(function () {
					//alert("Acordare permisiune "+data.issue.id+" a fost creata cu succes!");	
					$('#content').prepend("<div class='flash notice' id='flash_notice'>Acordare permisiune " + data.issue.id + " a fost creata cu succes! \n \n Link: <a target='_blank' href='" + window.location.origin + "/issues/" + data.issue.id + "'>" + window.location.origin + "/issues/" + data.issue.id + "</a></div>");
					console.log("Acordare permisiune " + data.issue.id + " a fost creata cu succes!");
					window.open(window.location.origin + "/issues/" + data.issue.id);
					// window.location.reload();
				}, 200);

			}); // done POST create new issue

		}); // done GET parent issue parameters


	} // function adaugaPermisiuneReglementare()


	$("#button_adaugaPermisiuneReglementare").on('click', function () {
		console.log('Click button Adauga permisiune');

		adaugaPermisiuneReglementare();
	});

	//============================= END ADAUGARE ACORDARE PERMISIUNE DIN REGLEMENTARI ===============================








	
	//-------------------------- ADAUGARE RESPONSABILITATE DIN ACTIVITATE -----------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Activitate #') != -1)
	) {

		$('#buttonNewResponsabilitateIfActivitate').show();
	} // if repartitie , show button for new rezolutie	

	function adaugaResponsabilitateActivitate() {
		//----------------- get watchers via api --------------
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {


			//console.log(data.issue.watchers.length + ' watchers GET successfully');
			//console.log(data.issue.watchers.length);			

			var directii_json = {
				"CM": 222,
				"CPP": 513,
				"DAP": 221,
				"DCAOSR": 217,
				"DCDSSI": 218,
				"DCPD": 211,
				"DCRB": 223,
				"DCRE": 229,
				"DEFC": 219,
				"DESA": 215,
				"DESR": 216,
				"DJSG": 230,
				"DJTS ALBA": 228,
				"DJTS ARAD": 471,
				"DJTS ARGES": 472,
				"DJTS BACAU": 473,
				"DJTS BIHOR": 474,
				"DJTS BISTRITA-NASAUD": 475,
				"DJTS BOTOSANI": 476,
				"DJTS BRAILA": 478,
				"DJTS BRASOV": 477,
				"DJTS BUZAU": 481,
				"DJTS CALARASI": 483,
				"DJTS CARAS-SEVERIN": 482,
				"DJTS CLUJ": 484,
				"DJTS CONSTANTA": 485,
				"DJTS COVASNA": 486,
				"DJTS DAMBOVITA": 487,
				"DJTS DOLJ": 488,
				"DJTS GALATI": 489,
				"DJTS GIURGIU": 490,
				"DJTS GORJ": 511,
				"DJTS HARGHITA": 491,
				"DJTS HUNEDOARA": 492,
				"DJTS IALOMITA": 493,
				"DJTS IASI": 494,
				"DJTS MARAMURES": 495,
				"DJTS MEHEDINTI": 496,
				"DJTS MURES": 497,
				"DJTS NEAMT": 498,
				"DJTS OLT": 499,
				"DJTS PRAHOVA": 500,
				"DJTS SALAJ": 502,
				"DJTS SATU MARE": 501,
				"DJTS SIBIU": 504,
				"DJTS SUCEAVA": 505,
				"DJTS TELEORMAN": 507,
				"DJTS TIMIS": 503,
				"DJTS TULCEA": 506,
				"DJTS VALCEA": 509,
				"DJTS VASLUI": 508,
				"DJTS VRANCEA": 510,
				"DL": 220,
				"DMP": 226,
				"DMRU": 231,
				"DOES": 225,
				"DOMO": 224,
				"DSCSTI": 234,
				"DSI": 232,
				"DTI": 210,
				"SIAPI": 235,
				"SICCD": 233
			}

			var grupuri_json = {
				"CM": 2630,
				"CPP": 2612,
				"DAP": 2629,
				"DCAOSR": 2625,
				"DCDSSI": 2626,
				"DCPD": 2622,
				"DCRB": 2618,
				"DCRE": 2617,
				"DEFC": 2627,
				"DESA": 2624,
				"DESR": 2623,
				"DJSG": 2610,
				"DJTS ALBA": 2570,
				"DJTS ARAD": 2571,
				"DJTS ARGES": 2572,
				"DJTS BACAU": 2573,
				"DJTS BIHOR": 2574,
				"DJTS BISTRITA-NASAUD": 2575,
				"DJTS BOTOSANI": 2576,
				"DJTS BRAILA": 2578,
				"DJTS BRASOV": 2577,
				"DJTS BUZAU": 2579,
				"DJTS CALARASI": 2581,
				"DJTS CARAS-SEVERIN": 2580,
				"DJTS CLUJ": 2582,
				"DJTS CONSTANTA": 2583,
				"DJTS COVASNA": 2584,
				"DJTS DAMBOVITA": 2585,
				"DJTS DOLJ": 2586,
				"DJTS GALATI": 2587,
				"DJTS GIURGIU": 2588,
				"DJTS GORJ": 2589,
				"DJTS HARGHITA": 2590,
				"DJTS HUNEDOARA": 2591,
				"DJTS IALOMITA": 2592,
				"DJTS IASI": 2593,
				"DJTS MARAMURES": 2594,
				"DJTS MEHEDINTI": 2595,
				"DJTS MURES": 2596,
				"DJTS NEAMT": 2597,
				"DJTS OLT": 2598,
				"DJTS PRAHOVA": 2599,
				"DJTS SALAJ": 2601,
				"DJTS SATU MARE": 2600,
				"DJTS SIBIU": 2602,
				"DJTS SUCEAVA": 2603,
				"DJTS TELEORMAN": 2604,
				"DJTS TIMIS": 2605,
				"DJTS TULCEA": 2606,
				"DJTS VALCEA": 2608,
				"DJTS VASLUI": 2607,
				"DJTS VRANCEA": 2609,
				"DL": 2628,
				"DMP": 2621,
				"DMRU": 2611,
				"DOES": 2620,
				"DOMO": 2619,
				"DSCSTI": 2614,
				"DSI": 2613,
				"DTI": 2569,
				"SIAPI": 2615,
				"SICCD": 2616
			}

			var unitate_responsabila_json = {
				"DJSG":"539",
				"DOMO":"540",
				"DMRU":"541",
				"DMP":"549",
				"DCRB":"542",
				"DESR":"543",
				"DESA":"544",
				"DCPD":"545",
				"DSCSTI":"546",
				"DSI":"547",
				"DTI":"548",
				"DOES":"550",
				"SIAPI":"551",
				"SICCD":"608",
				"DCRE":"567",
				"DCDSSI":"553",
				"DCAOSR":"554",
				"CM":"610",
				"CPP":"556",
				"DL":"557",
				"DAP":"558",
				"DEFC":"561",
				"Alte UC dupa caz":"559",
				"Alte UT dupa caz":"560",
				"Alte unitati tehnice participante la proiect":"555",
				"Colectivul desemnat prin Ordinul de Zi nr.1 al directorului STS":"536",
				"Comisia de monitorizare":"552",
				"Conducerea STS":"537",
				"CTEI":"533",
				"UC":"531",
				"UCP":"534",
				"UCT":"535",
				"UCT implicate":"609",
				"UT":"532",
				"UT cu atributii de protectia comunicatiilor":"562",
				"UT implicate":"538",
				"UT prin compartimentele de specialitate":"563",
				"Reprezentanti STS":"564",
				"Structura de monitorizare":"565",
				"Structura de securitate a STS":"566",
				"DJTS AB":"568",
				"DJTS AG":"569",
				"DJTS AR":"570",
				"DJTS BC":"571",
				"DJTS BH":"572",
				"DJTS BN":"573",
				"DJTS BR":"574",
				"DJTS BT":"575",
				"DJTS BV":"576",
				"DJTS BZ":"577",
				"DJTS CJ":"578",
				"DJTS CL":"579",
				"DJTS CS":"580",
				"DJTS CT":"581",
				"DJTS CV":"582",
				"DJTS DB":"583",
				"DJTS DJ":"584",
				"DJTS GJ":"585",
				"DJTS GL":"586",
				"DJTS GR":"587",
				"DJTS HD":"588",
				"DJTS HR":"589",
				"DJTS IL":"590",
				"DJTS IS":"591",
				"DJTS MH":"592",
				"DJTS MM":"593",
				"DJTS MS":"594",
				"DJTS NT":"595",
				"DJTS OT":"596",
				"DJTS PH":"597",
				"DJTS SB":"598",
				"DJTS SJ":"599",
				"DJTS SM":"600",
				"DJTS SV":"601",
				"DJTS TL":"602",
				"DJTS TM":"603",
				"DJTS TR":"604",
				"DJTS VL":"605",
				"DJTS VN":"606",
				"DJTS VS":"607"
			}

			var project_id = directii_json[localStorage.getItem('logged_user_directie')];
			var asignee_group_id = grupuri_json[localStorage.getItem('logged_user_directie')];

			var customFields = [{
				'id': 139,
				'multiple': true,
				'name': 'Unitate Responsabila',
				'value': [unitate_responsabila_json[localStorage.getItem('logged_user_directie')]]
			}]

			var newIssue =
			{
				"issue":
				{
					"project_id": data.issue.project.id,//project_id
					//"author_id": data.issue.author.id,//author_id 
					"tracker_id": 73, // Responsabilitate
					"status_id": 4,
					"priority_id": 2,
					"subject": data.issue.subject,
					//"description": "Descriere de test POST ISSUE",
					//"category_id": XXX,
					"fixed_version_id": data.issue.fixed_version,
					//"assigned_to_id": data.issue.assigned_to.id,
					"parent_issue_id": window.location.href.split('/issues/')[1].split('?')[0].split('#')[0],
					"custom_fields": customFields,
					//"watcher_user_ids": watchersJSON,
					//"is_private": XXX,
					//"estimated_hours": XXX						
				}
			}

			$.ajax({
				type: "POST",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues.json",
				data: JSON.stringify(newIssue)
			}).done(function (data) {

				// move to project
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data.issue.id + ".json",
					data: JSON.stringify({ "issue": { "project_id": project_id, "notes": "Issue creat de catre " + localStorage.getItem('logged_user_name') } })
				}).done(function (data) {
				}); // done PUT update to new project

				// assign to directie - admin reglementari
				// $.ajax({
				// 	type: "PUT",
				// 	async: false,
				// 	headers: {
				// 		"Content-Type": "application/json",
				// 		"X-Redmine-API-Key": STS.apiKey,
				// 		"X-Redmine-Switch-User": 'admin'
				// 	},
				// 	url: "/issues/" + data.issue.id + ".json",
				// 	data: JSON.stringify({ "issue": { "assigned_to_id": asignee_group_id } })
				// }).done(function (data) {
				// }); // done PUT update assigned to group

				setTimeout(function () {
					$('#content').prepend("<div class='flash notice' id='flash_notice'>Responsabilitate #" + data.issue.id + " a fost creata cu succes! \n \n Link: <a target='_blank' href='" + window.location.origin + "/issues/" + data.issue.id + "'>" + window.location.origin + "/issues/" + data.issue.id + "</a></div>");
					console.log("Responsabilitate #" + data.issue.id + " a fost creata cu succes!");
					window.open(window.location.origin + "/issues/" + data.issue.id);
					// window.location.reload();
				}, 200);

			}); // done POST create new issue

		}); // done GET parent issue parameters


	} // function adaugaResponsabilitateActivitate()


	$("#buttonNewResponsabilitateIfActivitate").on('click', function () {
		console.log('Click button Adauga resposabilitate');

		adaugaResponsabilitateActivitate();
	});
	//============================= END ADAUGARE RESPONSABILITATE DIN ACTIVITATE ===============================









	//-------------------------- ADAUGARE RESPONSABILITATI DJTS DIN ACTIVITATE -----------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Activitate #') != -1) &&
		(
			$('#loggedas .user').text() == 'admin' ||
			$('#loggedas .user').text() == 'cristian.dogaru'
		)
	) {

		$('#buttonNewResponsabilitatiOJTSIfActivitate').show();
	} // if repartitie , show button for new rezolutie	


	function adaugaResponsabilitateJudete_loop(
				counter,
				judete_project_array,
				priority_id,
				subject,
				description,
				start_date,
				due_date,
				parent_issue_id,
				custom_fields
	){		

		project_id = judete_project_array[counter];

		var newIssue =
		{
			"issue":
			{
				"project_id": project_id,
				//"author_id": data.issue.author.id,//author_id 
				"tracker_id": 73, // Responsabilitate
				"status_id": 4,
				"priority_id": priority_id,
				"subject": subject,
				"description": description,
				"start_date": start_date,
				"due_date": due_date,
				//"category_id": XXX,
				// "fixed_version_id": data.issue.fixed_version,
				//"assigned_to_id": data.issue.assigned_to.id,
				"parent_issue_id": parent_issue_id,
				"custom_fields": custom_fields,
				//"watcher_user_ids": watchersJSON,
				//"is_private": XXX,
				//"estimated_hours": XXX
			}
		}

		

		$.ajax({
			type: "POST",
			//async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue)
		}).done(function (data1) {

			// move to project
			$.ajax({
				type: "PUT",
				//async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + data1.issue.id + ".json",
				data: JSON.stringify({ "issue": { "tracker_id": 73, "custom_fields": custom_fields, "notes": "Issue creat de catre " + localStorage.getItem('logged_user_name') } })
			}).done(function (data2) {
			}); // done PUT update to new project

			setTimeout(function () {
				$('#content').prepend("<div class='flash notice' id='flash_notice'>Responsabilitate #" + data1.issue.id + " a fost creata cu succes! \n \n Link: <a target='_blank' href='" + window.location.origin + "/issues/" + data1.issue.id + "'>" + window.location.origin + "/issues/" + data1.issue.id + "</a></div>");
				console.log("Responsabilitate #" + data1.issue.id + " a fost creata cu succes!");
				// window.open(window.location.origin + "/issues/" + data.issue.id);
				// window.location.reload();
			}, 10);

			if( counter < judete_project_array.length ) {
				counter++;
				adaugaResponsabilitateJudete_loop(
					counter,
					judete_project_array,
					priority_id,
					subject,
					description,
					start_date,
					due_date,
					parent_issue_id,
					custom_fields
				);
			}
			

		}); // done POST create new issue
	}

	function adaugaResponsabilitatiOJTSActivitate(new_subject, new_description, new_priority, new_start_date, new_due_date) {
		//----------------- get watchers via api --------------
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {


			//console.log(data.issue.watchers.length + ' watchers GET successfully');
			//console.log(data.issue.watchers.length);			

			var directii_json = {
				// "CM": 222,
				// "CPP": 513,
				// "DAP": 221,
				// "DCAOSR": 217,
				// "DCDSSI": 218,
				// "DCPD": 211,
				// "DCRB": 223,
				// "DCRE": 229,
				// "DEFC": 219,
				// "DESA": 215,
				// "DESR": 216,
				// "DJSG": 230,
				"DJTS ALBA": 228,
				"DJTS ARAD": 471,
				"DJTS ARGES": 472,
				"DJTS BACAU": 473,
				"DJTS BIHOR": 474,
				"DJTS BISTRITA-NASAUD": 475,
				"DJTS BOTOSANI": 476,
				"DJTS BRAILA": 478,
				"DJTS BRASOV": 477,
				"DJTS BUZAU": 481,
				"DJTS CALARASI": 483,
				"DJTS CARAS-SEVERIN": 482,
				"DJTS CLUJ": 484,
				"DJTS CONSTANTA": 485,
				"DJTS COVASNA": 486,
				"DJTS DAMBOVITA": 487,
				"DJTS DOLJ": 488,
				"DJTS GALATI": 489,
				"DJTS GIURGIU": 490,
				"DJTS GORJ": 511,
				"DJTS HARGHITA": 491,
				"DJTS HUNEDOARA": 492,
				"DJTS IALOMITA": 493,
				"DJTS IASI": 494,
				"DJTS MARAMURES": 495,
				"DJTS MEHEDINTI": 496,
				"DJTS MURES": 497,
				"DJTS NEAMT": 498,
				"DJTS OLT": 499,
				"DJTS PRAHOVA": 500,
				"DJTS SALAJ": 502,
				"DJTS SATU MARE": 501,
				"DJTS SIBIU": 504,
				"DJTS SUCEAVA": 505,
				"DJTS TELEORMAN": 507,
				"DJTS TIMIS": 503,
				"DJTS TULCEA": 506,
				"DJTS VALCEA": 509,
				"DJTS VASLUI": 508,
				"DJTS VRANCEA": 510,
				// "DL": 220,
				// "DMP": 226,
				// "DMRU": 231,
				// "DOES": 225,
				// "DOMO": 224,
				// "DSCSTI": 234,
				// "DSI": 232,
				// "DTI": 210,
				// "SIAPI": 235,
				// "SICCD": 233
			}

			var grupuri_json = {
				// "CM": 2630,
				// "CPP": 2612,
				// "DAP": 2629,
				// "DCAOSR": 2625,
				// "DCDSSI": 2626,
				// "DCPD": 2622,
				// "DCRB": 2618,
				// "DCRE": 2617,
				// "DEFC": 2627,
				// "DESA": 2624,
				// "DESR": 2623,
				// "DJSG": 2610,
				"DJTS ALBA": 2570,
				"DJTS ARAD": 2571,
				"DJTS ARGES": 2572,
				"DJTS BACAU": 2573,
				"DJTS BIHOR": 2574,
				"DJTS BISTRITA-NASAUD": 2575,
				"DJTS BOTOSANI": 2576,
				"DJTS BRAILA": 2578,
				"DJTS BRASOV": 2577,
				"DJTS BUZAU": 2579,
				"DJTS CALARASI": 2581,
				"DJTS CARAS-SEVERIN": 2580,
				"DJTS CLUJ": 2582,
				"DJTS CONSTANTA": 2583,
				"DJTS COVASNA": 2584,
				"DJTS DAMBOVITA": 2585,
				"DJTS DOLJ": 2586,
				"DJTS GALATI": 2587,
				"DJTS GIURGIU": 2588,
				"DJTS GORJ": 2589,
				"DJTS HARGHITA": 2590,
				"DJTS HUNEDOARA": 2591,
				"DJTS IALOMITA": 2592,
				"DJTS IASI": 2593,
				"DJTS MARAMURES": 2594,
				"DJTS MEHEDINTI": 2595,
				"DJTS MURES": 2596,
				"DJTS NEAMT": 2597,
				"DJTS OLT": 2598,
				"DJTS PRAHOVA": 2599,
				"DJTS SALAJ": 2601,
				"DJTS SATU MARE": 2600,
				"DJTS SIBIU": 2602,
				"DJTS SUCEAVA": 2603,
				"DJTS TELEORMAN": 2604,
				"DJTS TIMIS": 2605,
				"DJTS TULCEA": 2606,
				"DJTS VALCEA": 2608,
				"DJTS VASLUI": 2607,
				"DJTS VRANCEA": 2609,
				// "DL": 2628,
				// "DMP": 2621,
				// "DMRU": 2611,
				// "DOES": 2620,
				// "DOMO": 2619,
				// "DSCSTI": 2614,
				// "DSI": 2613,
				// "DTI": 2569,
				// "SIAPI": 2615,
				// "SICCD": 2616
			}

			var unitate_responsabila_json = {
				// "DJSG":"539",
				// "DOMO":"540",
				// "DMRU":"541",
				// "DMP":"549",
				// "DCRB":"542",
				// "DESR":"543",
				// "DESA":"544",
				// "DCPD":"545",
				// "DSCSTI":"546",
				// "DSI":"547",
				// "DTI":"548",
				// "DOES":"550",
				// "SIAPI":"551",
				// "SICCD":"608",
				// "DCRE":"567",
				// "DCDSSI":"553",
				// "DCAOSR":"554",
				// "CM":"610",
				// "CPP":"556",
				// "DL":"557",
				// "DAP":"558",
				// "DEFC":"561",
				// "Alte UC dupa caz":"559",
				// "Alte UT dupa caz":"560",
				// "Alte unitati tehnice participante la proiect":"555",
				// "Colectivul desemnat prin Ordinul de Zi nr.1 al directorului STS":"536",
				// "Comisia de monitorizare":"552",
				// "Conducerea STS":"537",
				// "CTEI":"533",
				// "UC":"531",
				// "UCP":"534",
				// "UCT":"535",
				// "UCT implicate":"609",
				// "UT":"532",
				// "UT cu atributii de protectia comunicatiilor":"562",
				// "UT implicate":"538",
				// "UT prin compartimentele de specialitate":"563",
				// "Reprezentanti STS":"564",
				// "Structura de monitorizare":"565",
				// "Structura de securitate a STS":"566",
				"DJTS AB":"568",
				"DJTS AG":"569",
				"DJTS AR":"570",
				"DJTS BC":"571",
				"DJTS BH":"572",
				"DJTS BN":"573",
				"DJTS BR":"574",
				"DJTS BT":"575",
				"DJTS BV":"576",
				"DJTS BZ":"577",
				"DJTS CJ":"578",
				"DJTS CL":"579",
				"DJTS CS":"580",
				"DJTS CT":"581",
				"DJTS CV":"582",
				"DJTS DB":"583",
				"DJTS DJ":"584",
				"DJTS GJ":"585",
				"DJTS GL":"586",
				"DJTS GR":"587",
				"DJTS HD":"588",
				"DJTS HR":"589",
				"DJTS IL":"590",
				"DJTS IS":"591",
				"DJTS MH":"592",
				"DJTS MM":"593",
				"DJTS MS":"594",
				"DJTS NT":"595",
				"DJTS OT":"596",
				"DJTS PH":"597",
				"DJTS SB":"598",
				"DJTS SJ":"599",
				"DJTS SM":"600",
				"DJTS SV":"601",
				"DJTS TL":"602",
				"DJTS TM":"603",
				"DJTS TR":"604",
				"DJTS VL":"605",
				"DJTS VN":"606",
				"DJTS VS":"607"
			}


			// add all unitati responsabile
			var unitate_responsabila_array= [];
			for(i=0;i<=Object.keys(unitate_responsabila_json).length-1;i++) {
				unitate_responsabila_array.push( unitate_responsabila_json[Object.keys(unitate_responsabila_json)[i]] )
			}
			var customFields = [
				{
					'id': 139,
					'multiple': true,
					'name': 'Unitate Responsabila',
					'value': unitate_responsabila_array
				},
				{
					'id': 146,
					'multiple': true,
					'name': 'Proiect',
					'value': 'Alegeri 9 iunie 2024'
				}
			];


			// create parent responsabilitate @DOMO and add all DJTS as children
			var newIssue =
			{
				"issue":
				{
					"project_id": 224,
					//"author_id": data.issue.author.id,//author_id 
					"tracker_id": 73, // Responsabilitate
					"status_id": 4,
					"priority_id": new_priority,
					"subject": new_subject,
					"description": new_description,
					"start_date": new_start_date,
					"due_date": new_due_date,
					//"category_id": XXX,
					"fixed_version_id": data.issue.fixed_version,
					//"assigned_to_id": data.issue.assigned_to.id,
					"parent_issue_id": window.location.href.split('/issues/')[1].split('?')[0].split('#')[0],
					"custom_fields": customFields,
					//"watcher_user_ids": watchersJSON,
					//"is_private": XXX,
					//"estimated_hours": XXX
				}
			}
			$.ajax({
				type: "POST",
				//async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues.json",
				data: JSON.stringify(newIssue)
			}).done(function (data_domo) {
				// move to project
				$.ajax({
					type: "PUT",
					//async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data_domo.issue.id + ".json",
					data: JSON.stringify({ "issue": { "tracker_id": 73,/*"project_id": project_id,*/ "custom_fields": customFields, "notes": "Issue creat de catre " + localStorage.getItem('logged_user_name') } })
				}).done(function (data2) {
				}); // done PUT update to new project


				// create responsabilitati pentru DJTS:
				var project_id, asignee_group_id, judete_project_array = [];
				for(i=0;i<=Object.keys(directii_json).length-1;i++) {
					project_id = directii_json[Object.keys(directii_json)[i]];
					asignee_group_id = grupuri_json[Object.keys(directii_json)[i]];
					judete_project_array.push(project_id);
				} // for all DJTS
				
				
				adaugaResponsabilitateJudete_loop(
					0,
					judete_project_array,
					new_priority,
					new_subject,
					new_description,
					new_start_date,
					new_due_date,
					data_domo.issue.id,
					customFields
				);


			}); // end create DOMO responsabilitate



			
		}); // done GET parent issue parameters
		$('#modal_resp_ojts').remove();

	} // function adaugaResponsabilitatiOJTSActivitate(subject, description, priority, start_date, due_date)


	

	$("#buttonNewResponsabilitatiOJTSIfActivitate").on('click', function () {
		console.log('Click button Adauga resposabilitati OJTS');

		var popup_responsabilitati = 
		"<div class='modal_message_overlay' id='modal_resp_ojts''>"+
			"<div class='modal_message'>"+
			"<div class='modal_close' id='close_modal_resp_ojts'>x</div>"+
				"<div class='popup_responsabilitati_ojts'>"+
					"<label>Subject</label>"+
					"<input type='text' id='resp_subiect'><br>"+ 
					
					"<label>Description</label>"+
					"<textarea rows='7' id='resp_descriere' style='display:block!important'></textarea><br>"+

					"<label>Start date</label>"+
					"<input type='date' id='resp_start_date'><br>"+ 
					
					"<label>Due date</label>"+
					"<input type='date' id='resp_due_date'><br>"+ 

					"<label>Priority</label>"+
					"<select id='resp_priority'>"+
						"<option value='1'>mica</option>"+
						"<option selected='selected' value='2'>normala</option>"+
						"<option value='3'>mare</option>"+
						"<option value='4'>foarte mare</option>"+
						"<option value='30'>Important</option>"+
					"</select><br>"+

					"<button id='resp_create_ojts'>Adauga responsabilitati DJTS</button>"+
				"</div>"+
			"</div>"+
		"</div>";
		$('body').append(popup_responsabilitati);
	});

	$("body").on('click', '#resp_create_ojts', function () {
		adaugaResponsabilitatiOJTSActivitate($('#resp_subiect').val(), $('#resp_descriere').val(), $('#resp_priority').val(), $('#resp_start_date').val(), $('#resp_due_date').val())
	});
	$("body").on('click', '#close_modal_resp_ojts', function () {
		$('#modal_resp_ojts').remove();
	});
	//============================= END ADAUGARE RESPONSABILITATI DJTS DIN ACTIVITATE ===============================
















	//------------------------- TRANSFER CERERE SERVICII ---------------------------------------
	//--- JSON extend function ---
	function extend(dest, src) {
		for (var key in src) {
			dest[key] = src[key];
		}
		return dest;
	}

	//--- TRANSFER ---
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Transfer #') != -1)
	) {

		$.ajax({
			type: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0] + ".json?include=watchers"
		}).done(function (data_1) {
			console.log('data_1:');
			console.log(data_1);
			console.log('-------------------------');
			//---- get PARENT info (doc iesire) for related (cerere) ----
			$.ajax({
				type: "GET",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + data_1.issue.parent.id + ".json?include=watchers,relations"
			}).done(function (data_2) {
				console.log('data_2:');
				console.log(data_2);
				console.log('-------------------------');
				//--- check if PARENT Document iesire has related cerere servicii ---
				if (data_2.issue.relations != undefined) {
					$.ajax({
						type: "GET",
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + data_2.issue.relations[0].issue_to_id + ".json?include=watchers,relations"
					}).done(function (data_3) {
						console.log('data_3:');
						console.log(data_3);
						console.log('-------------------------');

						var watchers_transfer = "utf8=✓&project_id=" + data_1.issue.project.id + "&object_id[]=" + data_1.issue.id + "&object_type=issue&user_search=";
						var watchers_doc_iesire = "utf8=✓&project_id=" + data_2.issue.project.id + "&object_id[]=" + data_2.issue.id + "&object_type=issue&user_search=";

						var watchers_json = "";
						for (i = 0; i <= data_3.issue.watchers.length - 1; i++) {
							watchers_json = watchers_json + "&watcher[user_ids][]=" + data_3.issue.watchers[i].id;
						} // copy watchers						

						watchers_transfer = watchers_transfer + watchers_json;
						watchers_doc_iesire = watchers_doc_iesire + watchers_json;

						//--- ADD watchers Transfer ---
						$.ajax({
							type: "POST",
							headers: {
								"Content-Type": "application/x-www-form-urlencoded",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/watchers",
							dataType: "text/javascript; charset=utf-8",
							data: watchers_transfer
						}).done(function (data_4) {
							console.log(data_4);
						});
						//--- ADD watchers Document de iesire ---
						$.ajax({
							type: "POST",
							headers: {
								"Content-Type": "application/x-www-form-urlencoded",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/watchers",
							dataType: "text/javascript; charset=utf-8",
							data: watchers_doc_iesire
						}).done(function (data_5) {
							console.log(data_5);
						});
						console.log('watchers added');
					});


					//--- ADD RELATED ISSUE (CERERE SERVICII PRIMA ONLY) FROM PARENT ---				
					$.ajax({
						type: "POST",
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + data_1.issue.id + "/relations?relation[relation_type]=relates&relation[issue_to_id]=" + data_2.issue.relations[0].issue_to_id + "&relation[delay]=&commit=Add"
					}).done(function (data) {
					});
				} //--- if related ---				


			});
		}); // GET current issue

	} // if Transfer


	//--- Document de iesire ---
	if (
		(window.location.href.indexOf('issues') != -1) &&
		($('#content h2').text().indexOf('Transfer #') != -1)
	) {
		//--- data Document de iesire ---
		$.ajax({
			type: "GET",
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0] + ".json?include=watchers"
		}).done(function (data_1) {
			if (data_1.issue.relations != undefined) {
				//--- ADD Watchers from Cerere to Doc de iesire
				$.ajax({
					type: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + data_1.issue.relations[0].issue_to_id + ".json?include=watchers,relations"
				}).done(function (data_2) {
					var watchers_doc_iesire = "utf8=✓&project_id=" + data_1.issue.project.id + "&object_id[]=" + data_1.issue.id + "&object_type=issue&user_search=";

					//--- ADD watchers pe Document de iesire de pe Cererea de servicii ---
					for (i = 0; i <= data_2.issue.watchers.length - 1; i++) {
						watchers_json = watchers_json + "&watcher[user_ids][]=" + data_2.issue.watchers[i].id;
					} // add watchers one by one
					//--- ADD watchers Document de iesire ---
					$.ajax({
						type: "POST",
						headers: {
							"Content-Type": "application/x-www-form-urlencoded",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/watchers",
						dataType: "text/javascript; charset=utf-8",
						data: watchers_doc_iesire
					}).done(function (data_4) {
						console.log(data_4);
					});



				});

			}// if cerere related
		});
	} // if Document de iesire
	//======================== END TRANSFER CERERE SERVICII ====================================
















	//------------ ADAUGARE watchers in noua Rezolutie din Repartitie ------	
	if (window.location.href.indexOf('&watchers=') != -1) {

		//WATCHERII din STS - MD - Cabinet "163,243,339,438,610"; >>>>> ii luam din grup acum

		var watchers_url_to_add = "";

		// ACESTI WATCHERS sunt tot timpul "163,243,339,438,610" >>>>> ii luam din grup acum

		for (i = 0; i <= window.location.href.split('&watchers=')[1].split(',').length - 1; i++) {
			watchers_url_to_add = watchers_url_to_add + "&watcher[user_ids][]=" + window.location.href.split('&watchers=')[1].split(',')[i];
		}

		//watchers_url_to_add = watchers_url_to_add + "&watcher[user_ids][]=163&watcher[user_ids][]=243&watcher[user_ids][]=339&watcher[user_ids][]=438&watcher[user_ids][]=610";

		//-------- AJAX add the watchers -------
		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/watchers/append?project_id=" + window.location.href.split('issue[project_id]=')[1].split('&watchers')[0] + "&user_search=" + watchers_url_to_add
		}).done(function (data) {
			//console.log(data);				
		}); // done function


	}
	//========================= END ADAUGARE REZOLUTIE DIN REPARTITIE ================================






	//-------------------------------- DACA APROBA CU CLICK DREAPTA COPII APROBATI ---------------------------------
	//------- AICI PARENT open mutat - inainte de sumbit -------

	function aprobareClickDreapta(issueID) {
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			}, // 'admin'
			url: "/issues/" + issueID + ".json?include=watchers,children,relations"
		}).done(function (data) {
			//---------------------- VERIFICAM PARINTELE - COPII APROBATI --------------------
			if (data.issue.parent != undefined) {
				$.ajax({
					type: "GET",
					//async:false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, // $('#loggedas .user').text()	
					url: "/issues/" + data.issue.parent.id + ".json?include=children"
				}).done(function (data) {
					//console.log(data);

					if (data.issue.children.length > 0) {
						var i = 0;
						localStorage.setItem('solicitareAprobare_CopiiAprobati', 0);

						console.log('Avem copii: ' + data.issue.children.length);

						function checkSolicitareAprobLoop() {
							if (i <= data.issue.children.length - 1) {
								$.ajax({
									type: "GET",
									//async:false,
									headers: {
										"Content-Type": "application/json",
										"X-Redmine-API-Key": STS.apiKey,
										"X-Redmine-Switch-User": 'admin'
									}, // $('#loggedas .user').text()
									url: "/issues/" + data.issue.children[i].id + ".json"
								}).done(function (data) {
									//console.log(data);
									if (data.issue.status.id == 24) {  //daca acest copil e Aprobat
										localStorage.setItem('solicitareAprobare_CopiiAprobati', parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')) + 1);
									}
									checkSolicitareAprobLoop();
								});
								i++;
							}

							console.log('Copii aprobati: ' + parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')));

							if (data.issue.children.length == parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati'))) { // daca avem toti copiii aprobati									
								console.log('SUNT toti copiii sunt aprobati: ' + data.issue.children.length);

								$.ajax({
									type: "GET",
									async: false,
									headers: {
										"Content-Type": "application/json",
										"X-Redmine-API-Key": STS.apiKey,
										"X-Redmine-Switch-User": 'admin'
									}, // $('#loggedas .user').text()
									url: "/issues/" + issueID + ".json?include=watchers"
								}).done(function (data) {

									//------------ verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN --------
									$.ajax({
										type: "GET",
										async: false,
										headers: {
											"Content-Type": "application/json",
											"X-Redmine-API-Key": STS.apiKey,
											"X-Redmine-Switch-User": 'admin'
										}, // $('#loggedas .user').text()
										url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
									}).done(function (data) {
										if (data.issue.tracker.id == 49 || data.issue.tracker.id == 74 ) { // daca e solicitare aprobare parintele SAU tranzit		
											if (data.issue.status.id != 24 && data.issue.status.id != 26 && data.issue.status.id != 27) { // daca nu e aprobat/anulat
												$.ajax({
													type: "PUT",
													async: false,
													headers: {
														"Content-Type": "application/json",
														"X-Redmine-API-Key": STS.apiKey,
														"X-Redmine-Switch-User": 'admin'
													}, //------PROBLEMA OPEN APROBARE change admin si punem numele: {"issue":{"notes": noteToAdd }}
													url: "/issues/" + data.issue.id + ".json",
													data: JSON.stringify({ "issue": { "status_id": "1" } }) // il facem OPEN daca are toti copiii aprobati
												}).done(function (data) {
													console.log(data);
												}); // ajax il facem OPEN
											}
										} // ---- verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN 
									});




								}); // ajax get

							}


						}
						checkSolicitareAprobLoop();


					} // daca are copii parintele
				}); //---------------------- ajax done VERIFICAM PARINTELE - COPII APROBATI --------------------
			}
		});	//-------------- FINAL verificare aprobat -----------------
	}

	$('#content').on('click', '#context-menu a', function (e) {
		if ((decodeURIComponent($(this).attr('href'))).split('[status_id]=')[1] == 24) {
			e.preventDefault();
			$(this).attr('id', 'clickDreaptaID');
			var updateIDs = [];
			$('.context-menu-selection').each(function (index, elem) {
				console.log(elem.id.split('issue-')[1]);
				updateIDs.push(elem.id.split('issue-')[1]);
			});
			console.log(updateIDs);
			console.log("Id status selectat=" + (decodeURIComponent($(this).attr('href'))).split('[status_id]=')[1]); // daca e 24 = Aprobat


			console.log('a dat click pe aprobat : 24');
			for (ids = 0; ids <= updateIDs.length - 1; ids++) {
				aprobareClickDreapta(parseInt(updateIDs[ids]));
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					}, //------PROBLEMA OPEN APROBARE change admin si punem numele: {"issue":{"notes": noteToAdd }} ||| aici am pus user-ul sa apara ca a aprobat el task-ul cu click dreapta
					url: "/issues/" + updateIDs[ids] + ".json",
					data: JSON.stringify({ "issue": { "status_id": "24" } }) // il facem OPEN daca are toti copiii aprobati
				}).done(function (data) {
					console.log(data);
				}); // ajax aprobam ce a aprobat cu click dreapta
			}



			$(document).ajaxComplete(function () {
				setTimeout(function () {

					window.location.reload();

				}, 100);
			})

			return false;
		} // daca a dat click pe Aprobat
	});
	//============================== END DACA APROBA CU CLICK DREAPTA COPII APROBATI ===============================















	//-------------------- REGLEMENTARI DOCUMENTE ---------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		(
			$('#content h2').text().indexOf('Reglementari #') != -1
		)
	) {
		//console.log('START REGLEMENTARI IFRAME STERGGGGGGG');
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			}, // 'admin'
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,children,relations"
		}).done(function (data) {
			console.log(data);
			$("<div id='afisareDocumenteContainer'><h3>Reglementari</h3 id='afisareDocumenteLink_1_container'></div>").insertAfter('div.issue');
			var documente_array = [];
			$.each(data.issue.custom_fields, function (eachIndex) {
				if (
					(data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && 
					data.issue.custom_fields[eachIndex].value != "" &&
					$.inArray(data.issue.custom_fields[eachIndex].value,documente_array) == -1
				) {
					documente_array.push(data.issue.custom_fields[eachIndex].value);
					//------- alfresco get document name ---------
					var url = data.issue.custom_fields[eachIndex].value;
					var origin = url.split('stsnet.ro/')[0] + 'stsnet.ro/';
					origin = origin.replace('http://', 'https://');
					var nodeId = url.split('SpacesStore/')[1];

					//--- IF secretariat.stsnet.ro ---
					if (origin.indexOf('alf-dms') == -1) {
						$.ajax({
							type: "GET",
							headers: {
								"Content-Type": "application/json",
								"Authorization": STS.portalAuth
							},
							url: origin + "alfresco/s/ootbee/admin/active-sessions/users"
						}).done(function (data) {
							var loggedIn = 0;
							for (i = 0; i <= data.users.length - 1; i++) {
								if (
									data.users[i].userName == $('#loggedas .user').text() ||
									($('#loggedas .user').text() == 'admin' && data.users[i].userName == 'redmine')
								) {
									//console.log('---- pt cv link principal ----');
									//console.log(data.users[i].userName);
									loggedIn = 1;
									$.ajax({
										type: "GET",
										headers: {
											"Content-Type": "application/json",
											"Authorization": STS.portalAuth
										},
										url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
									}).done(function (data, statusText, xhr) {
										if (xhr.status == 200) {
											var docName = encodeURIComponent(data.entry.name);
											var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
											if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1 || 1) {
												$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
											} else {
												$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
											}
										} else {
											$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
										}
									}).fail(function () {
										$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
									});
								}
							}
							if (loggedIn == 0) {
								$('#afisareDocumenteContainer').append("<div class='accordion_title'><a id='afisareDocumenteLink_1' href='" + origin + "' target='_blank'>(poate fi vizualizat doar daca sunteti autentificat in Alfresco)</a></div>");
							}
						});
					} else {
						//--- IF alf-dms.stsnet.ro ---
						$.ajax({
							type: "GET",
							headers: {
								"Content-Type": "application/json",
								"Authorization": STS.portalAuth
							},
							url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
						}).done(function (data, statusText, xhr) {
							if (xhr.status == 200) {
								var docName = encodeURIComponent(data.entry.name);
								var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
								if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1 || 1) {
									$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
								} else {
									$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
								}
							} else {
								$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
							}
						}).fail(function () {
							$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
						});
					}

					return false;

				} else { // daca avem link CV 
					$('#afisareDocumenteLink_1_container').hide();
				}
			});


			//--- ADD iframe REGLEMENTARI ---
			if (data.issue.relations != undefined) {
				$("<div id='afisareDocumenteRelatedContainer'><h3 id='afisareDocumenteLink_2_container'>Reglementari relationate</h3></div>").insertAfter('#afisareDocumenteContainer');
				$.each(data.issue.relations, function (index, value) {
					//console.log(data.issue.relations[index].issue_to_id);

					if (data.issue.id == data.issue.relations[index].issue_id) {
						var related_id = data.issue.relations[index].issue_to_id;
					} else {
						var related_id = data.issue.relations[index].issue_id;
					}

					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + related_id + ".json"
					}).done(function (data) {
						var documente_array = [];
						$.each(data.issue.custom_fields, function (eachIndex) {
							if (
								(data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && 
								data.issue.custom_fields[eachIndex].value != "" &&
								$.inArray(data.issue.custom_fields[eachIndex].value,documente_array) == -1
							) {
								documente_array.push(data.issue.custom_fields[eachIndex].value);
								//------- alfresco get document name ---------
								var url = data.issue.custom_fields[eachIndex].value;
								var origin = url.split('stsnet.ro/')[0] + 'stsnet.ro/';
								origin = origin.replace('http://', 'https://');
								var nodeId = url.split('SpacesStore/')[1];

								if (origin.indexOf('alf-dms') == -1) {
									$.ajax({
										type: "GET",
										headers: {
											"Content-Type": "application/json",
											"Authorization": STS.portalAuth
										},
										url: origin + "alfresco/s/ootbee/admin/active-sessions/users"
									}).done(function (data) {
										//console.log(data.users);
										var loggedIn = 0;
										for (i = 0; i <= data.users.length - 1; i++) {
											if (
												data.users[i].userName == $('#loggedas .user').text() ||
												($('#loggedas .user').text() == 'admin' && data.users[i].userName == 'redmine')
											) {
												//console.log('---- pt cv link principal RELATED ----');
												//console.log(data.users[i].userName);
												loggedIn = 1;

												$.ajax({
													type: "GET",
													async: false,
													headers: {
														"Content-Type": "application/json",
														"Authorization": STS.portalAuth
													},
													url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
												}).done(function (data, statusText, xhr) {
													if (xhr.status == 200) {
														var docName = encodeURIComponent(data.entry.name);
														var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
														if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1 || 1) {
															$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
														} else {
															$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
														}
													} else {
														$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
													}
												}).fail(function () {
													$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
												});

											}
										}

										if (loggedIn == 0) {
											$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'><a id='afisareDocumenteLink_1' href='" + origin + "' target='_blank'>(poate fi vizualizat doar daca sunteti autentificat in Alfresco)</a></div>");
										}

									});
								} else { // if alf-dms
									$.ajax({
										type: "GET",
										async: false,
										headers: {
											"Content-Type": "application/json",
											"Authorization": STS.portalAuth
										},
										url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
									}).done(function (data, statusText, xhr) {
										if (xhr.status == 200) {
											var docName = encodeURIComponent(data.entry.name);
											var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
											if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1 || 1) {
												$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
											} else {
												$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
											}
										} else {
											$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
										}
									}).fail(function () {
										$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
									});
								}

								return false;


							} // daca avem link CV
						});
					});

				});	// for each related			

			} else { // daca avem related		 		
				$('#afisareDocumenteLink_2_container').hide();
			}

		});// get issue info reglementari


	} // if REGLEMENTARI issue




























	if ( /*localStorage.getItem('currentIssue_project_id') == 822*/ 1) {
		//--------------------------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------
		//------------ IF  solicitare aprobare sau doc intern, afisam documentele din alfresco in iframe ---------
		if (
			(window.location.href.indexOf('issues') != -1) &&
			(
				$('#content h2').text().indexOf('Solicitare aprobare #') != -1 ||
				$('#content h2').text().indexOf('Document intern #') != -1 ||
				$('#content h2').text().indexOf('Repartitie #') != -1 ||
				$('#content h2').text().indexOf('Rezolutie #') != -1 ||
				$('#content h2').text().indexOf('Document electronic #') != -1
			)
		) {

			//------------------------ BUTON APROBA SOLICITARE APROBARE NOU --------------------
			if ($('#content h2').text().indexOf('Solicitare aprobare #') != -1) {
				$('#buttonIfSolAprobare_aproba').show();
			}
			$('#buttonIfSolAprobare_aproba').on('click', function () {
				var issue_id_approve = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + issue_id_approve + ".json",
					data: JSON.stringify({ "issue": { "status_id": "24" } })
				}).done(function (data) {
					console.log(data);
				});

				aprobareClickDreapta(issue_id_approve);

				$(document).bind('ajaxStop', function () {
					setTimeout(function () {
						window.location.reload();
					}, 100);
				});
			});




			$.ajax({
				type: "GET",
				//async:false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				}, // 'admin'
				url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,children,relations"
			}).done(function (data) {
				//console.log(data);


				//--------------- Adaugam iframe cu link cv task -----------------
				$("<div id='afisareDocumenteContainer'><h3>Documentul pentru care se solicita aprobarea</h3 id='afisareDocumenteLink_1_container'></div>").insertAfter('div.issue');
				var documente_array = [];
				$.each(data.issue.custom_fields, function (eachIndex) {
					if (
						(data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && 
						data.issue.custom_fields[eachIndex].value != "" &&
						$.inArray(data.issue.custom_fields[eachIndex].value,documente_array) == -1
					) {
						documente_array.push(data.issue.custom_fields[eachIndex].value);
						//------- alfresco get document name ---------
						var url = data.issue.custom_fields[eachIndex].value;
						var origin = url.split('stsnet.ro/')[0] + 'stsnet.ro/';
						origin = origin.replace('http://', 'https://');
						var nodeId = url.split('SpacesStore/')[1];

						if (origin.indexOf('alf-dms') == -1) {
							$.ajax({
								type: "GET",
								headers: {
									"Content-Type": "application/json",
									"Authorization": STS.portalAuth
								},
								url: origin + "alfresco/s/ootbee/admin/active-sessions/users"
							}).done(function (data) {
								var loggedIn = 0;
								for (i = 0; i <= data.users.length - 1; i++) {
									if (
										data.users[i].userName == $('#loggedas .user').text() ||
										($('#loggedas .user').text() == 'admin' && data.users[i].userName == 'redmine')
									) {
										//console.log('---- pt cv link principal ----');
										//console.log(data.users[i].userName);
										loggedIn = 1;
										$.ajax({
											type: "GET",
											headers: {
												"Content-Type": "application/json",
												"Authorization": STS.portalAuth
											},
											url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
										}).done(function (data, statusText, xhr) {
											if (xhr.status == 200) {
												var docName = encodeURIComponent(data.entry.name);
												var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
												if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1) {
													$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
												} else {
													$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
												}
											} else {
												$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
											}
										}).fail(function () {
											$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
										});
									}
								}
								if (loggedIn == 0) {
									$('#afisareDocumenteContainer').append("<div class='accordion_title'><a id='afisareDocumenteLink_1' href='" + origin + "' target='_blank'>(poate fi vizualizat doar daca sunteti autentificat in Alfresco)</a></div>");
								}
							});
						} else { // if alf-dms							
							$.ajax({
								type: "GET",
								headers: {
									"Content-Type": "application/json",
									"Authorization": STS.portalAuth
								},
								url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
							}).done(function (data, statusText, xhr) {
								if (xhr.status == 200) {
									var docName = encodeURIComponent(data.entry.name);
									var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
									if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1) {
										$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
									} else {
										$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
									}
								} else {
									$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
								}
							}).fail(function () {
								$('#afisareDocumenteContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
							});
						}




						return false;

					} else { // daca avem link CV 
						$('#afisareDocumenteLink_1_container').hide();
					}
				});

				//--------- adaugam iframe cv link pentru related issues ----------
				if (data.issue.relations != undefined) {
					$("<div id='afisareDocumenteRelatedContainer'><h3 id='afisareDocumenteLink_2_container'>Cererea/cererile beneficiarului/beneficiarilor</h3></div>").insertAfter('#afisareDocumenteContainer');
					$.each(data.issue.relations, function (index, value) {
						//console.log(data.issue.relations[index].issue_to_id);

						if (data.issue.id == data.issue.relations[index].issue_id) {
							var related_id = data.issue.relations[index].issue_to_id;
						} else {
							var related_id = data.issue.relations[index].issue_id;
						}

						$.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/issues/" + related_id + ".json"
						}).done(function (data) {
							var documente_array = [];
							$.each(data.issue.custom_fields, function (eachIndex) {
								if (
									(data.issue.custom_fields[eachIndex].id == 24 || data.issue.custom_fields[eachIndex].id == 34) && 
									data.issue.custom_fields[eachIndex].value != "" &&
									$.inArray(data.issue.custom_fields[eachIndex].value,documente_array) == -1
								) {
									documente_array.push(data.issue.custom_fields[eachIndex].value);
									//------- alfresco get document name ---------
									var url = data.issue.custom_fields[eachIndex].value;
									var origin = url.split('stsnet.ro/')[0] + 'stsnet.ro/';
									origin = origin.replace('http://', 'https://');
									var nodeId = url.split('SpacesStore/')[1];

									if (origin.indexOf('alf-dms') == -1) {
										$.ajax({
											type: "GET",
											headers: {
												"Content-Type": "application/json",
												"Authorization": STS.portalAuth
											},
											url: origin + "alfresco/s/ootbee/admin/active-sessions/users"
										}).done(function (data) {
											//console.log(data.users);
											var loggedIn = 0;
											for (i = 0; i <= data.users.length - 1; i++) {
												if (
													data.users[i].userName == $('#loggedas .user').text() ||
													($('#loggedas .user').text() == 'admin' && data.users[i].userName == 'redmine')
												) {
													//console.log('---- pt cv link principal RELATED ----');
													//console.log(data.users[i].userName);
													loggedIn = 1;

													$.ajax({
														type: "GET",
														async: false,
														headers: {
															"Content-Type": "application/json",
															"Authorization": STS.portalAuth
														},
														url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
													}).done(function (data, statusText, xhr) {
														if (xhr.status == 200) {
															var docName = encodeURIComponent(data.entry.name);
															var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
															if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1) {
																$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
															} else {
																$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
															}
														} else {
															$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
														}
													}).fail(function () {
														$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
													});

												}
											}

											if (loggedIn == 0) {
												$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'><a id='afisareDocumenteLink_1' href='" + origin + "' target='_blank'>(poate fi vizualizat doar daca sunteti autentificat in Alfresco)</a></div>");
											}

										});
									} else { // if alf-dms
										$.ajax({
											type: "GET",
											async: false,
											headers: {
												"Content-Type": "application/json",
												"Authorization": STS.portalAuth
											},
											url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId
										}).done(function (data, statusText, xhr) {
											if (xhr.status == 200) {
												var docName = encodeURIComponent(data.entry.name);
												var iframeUrl_actual = origin + "share/proxy/alfresco/slingshot/node/content/workspace/SpacesStore/" + nodeId + "/" + docName;
												if (docName.indexOf(".pdf") != -1 || docName.indexOf(".PDF") != -1) {
													$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + " ] : <a href='" + iframeUrl_actual + "' target='_blank'>" + data.entry.name + "</a><span class='accordion_plus'>+</span><span class='accordion_minus'>-</span></div><div class='accordion_body'><iframe frameborder='0' style='width:100%;min-height:500px;margin:0' src='' data-url='" + iframeUrl_actual + "' data-fullurl='" + url + "'></iframe></div></div>");
												} else {
													$('#afisareDocumenteContainer').append("<div class='accordion'><div class='accordion_title'>[ " + (data.entry.properties['cm:description'] != '' ? data.entry.properties['cm:description'] : data.entry.properties['reglementari:TitlulContinut']) + "-" + data.entry.name + " ]</div><div class='accordion_body' style='padding:10px'>Documentul nu este pdf</div></div>");
												}
											} else {
												$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
											}
										}).fail(function () {
											$('#afisareDocumenteRelatedContainer').append("<div class='accordion_title'>Este nevoie sa va autentificati in Alfresco. <a href='" + origin + "' target='_blank'>Click aici</a> pentru a va autentifica si reincarcati aceasta pagina ulterior.</div>");
										});
									}

									return false;


								} // daca avem link CV
							});
						});

					});	// for each related			

				} else { // daca avem related		 		
					$('#afisareDocumenteLink_2_container').hide();
				}
				//============= END Adaugam iframe cu link cv task si link cv related issues ===============














				//------------------- ASCUNDEM EDIT DACA E ISSUE de tip CLOSED ----------------------
				$.ajax({
					type: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, // $('#loggedas .user').text()
					url: "/issue_statuses.json"
				}).done(function (data) {
					var i;
					var issueStatusClosed = [];
					for (i = 0; i <= data.issue_statuses.length - 1; i++) {
						if (data.issue_statuses[i].is_closed == true && data.issue_statuses[i].id != 26) {
							issueStatusClosed.push(data.issue_statuses[i].id);
						}
					}

					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						}, // $('#loggedas .user').text()	
						url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
					}).done(function (data) {
						if (issueStatusClosed.indexOf(data.issue.status.id) != -1) {
							if (localStorage.getItem('currentIssue_project_id') == 822) {
								$('.icon.icon-edit').hide();
							}

							if ($('#loggedas .user').text() == "admin") {
								$('.icon.icon-edit').show();
							}
						}
					});


				});
				//======================= END ASCUNDEM EDIT DACA E ISSUE de tip CLOSED ========================










				if (
					data.issue.status.id == 24 && // daca e Aprobat
					(data.issue.assigned_to.id != 324 && data.issue.assigned_to.id != 325 && data.issue.assigned_to.id != 326)
				) {
					console.log('E solicitare aprobare, unitate centrala sau teritoriala');
					//---------------------- VERIFICAM PARINTELE - COPII APROBATI --------------------

					$.ajax({
						type: "GET",
						//async:false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						}, // $('#loggedas .user').text()	
						url: "/issues/" + data.issue.parent.id + ".json?include=children"
					}).done(function (data) {
						//console.log(data);

						if (data.issue.children.length > 0) {
							var i = 0;
							localStorage.setItem('solicitareAprobare_CopiiAprobati', 0);

							console.log('Avem copii: ' + data.issue.children.length);

							function checkSolicitareAprobLoop() {
								if (i <= data.issue.children.length - 1) {
									$.ajax({
										type: "GET",
										//async:false,
										headers: {
											"Content-Type": "application/json",
											"X-Redmine-API-Key": STS.apiKey,
											"X-Redmine-Switch-User": 'admin'
										}, // $('#loggedas .user').text()
										url: "/issues/" + data.issue.children[i].id + ".json"
									}).done(function (data) {
										//console.log(data);
										if (data.issue.status.id == 24) {  //daca acest copil e Aprobat
											localStorage.setItem('solicitareAprobare_CopiiAprobati', parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')) + 1);
										}
										checkSolicitareAprobLoop();
									});
									i++;
								}

								console.log('Copii aprobati: ' + parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')));

								if (data.issue.children.length == parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati'))) { // daca avem toti copiii aprobati									
									console.log('SUNT toti copiii sunt aprobati: ' + data.issue.children.length);

									$.ajax({
										type: "GET",
										async: false,
										headers: {
											"Content-Type": "application/json",
											"X-Redmine-API-Key": STS.apiKey,
											"X-Redmine-Switch-User": 'admin'
										}, // $('#loggedas .user').text()
										url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
									}).done(function (data) {

										//------------ verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN --------
										$.ajax({
											type: "GET",
											async: false,
											headers: {
												"Content-Type": "application/json",
												"X-Redmine-API-Key": STS.apiKey,
												"X-Redmine-Switch-User": 'admin'
											}, // $('#loggedas .user').text()
											url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
										}).done(function (data) {
											if (data.issue.tracker.id == 49) { // daca e solicitare aprobare parintele													
												if (data.issue.status.id != 24 && data.issue.status.id != 26 && data.issue.status.id != 27) { // daca nu e aprobat/anulat
													$.ajax({
														type: "PUT",
														async: false,
														headers: {
															"Content-Type": "application/json",
															"X-Redmine-API-Key": STS.apiKey,
															"X-Redmine-Switch-User": 'admin'
														}, //------PROBLEMA OPEN APROBARE change admin si punem numele: {"issue":{"notes": noteToAdd }}
														url: "/issues/" + data.issue.id + ".json",
														data: JSON.stringify({ "issue": { "status_id": "1" } }) // il facem OPEN daca are toti copiii aprobati
													}).done(function (data) {
														console.log(data);
													}); // ajax il facem OPEN
												}
											} // ---- verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN 
										});




									}); // ajax get

								}


							}
							checkSolicitareAprobLoop();


						} // daca are copii parintele
					}); //---------------------- ajax done VERIFICAM PARINTELE - COPII APROBATI --------------------






				} // daca nu e conducere si e APROBAT






				//------------------ DACA se aproba SG - verificare , facem subunitatile OPEN ---------------
				if (
					data.issue.status.id == 24 && // daca e Aprobat
					(data.issue.assigned_to.id == 1269) // daca e asignad SG - verificare
				) {
					/*
					$.ajax({
						type:"GET",
						async:false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": $('#loggedas .user').text()},		
						url:"/issues/" + data.issue.parent.id + ".json?include=children"
					}).done(function(data){
						console.log(data.issue.children);
					});
					*/

					// trebuie sa cautam celalalt copil de tip SG - tiparire, si sa facem copiii lui de tip unitati OPEN.


				} // IF aprobat si asignat SG - Verificare



			}); // get issue info


		}
	} // if( localStorage.getItem('currentIssue_project_id') == 822 ) {


	if ( /*localStorage.getItem('currentIssue_project_id') == 822*/ 1) {

		//--------------------------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------
		//------------------------------ ADAUGA SOLICITARI APROBARE ACHIZITII -----------------------------------------
		if (
			(window.location.href.indexOf('issues') != -1) &&
			($('#content h2').text().indexOf('Cerere de achizitii #') != -1)
		) {
			$('#buttonNewRezIfRepart').show();
		}
		if (
			(window.location.href.indexOf('issues') != -1) &&
			(($('#content h2').text().indexOf('Nota Raport #') != -1) || ($('#content h2').text().indexOf('Comanda #') != -1))
		) {
			$('#buttonNewSolAprobIf_cerere_achizitii').show();
			$('#buttonNewRezIfRepart').show();
		}
		var createdSolicitareAprobare = [];
		localStorage.setItem('createdSolicitareAprobare', JSON.stringify(createdSolicitareAprobare));

		$('#buttonNewSolAprobIf_cerere_achizitii').on('click', function () {
			$('#newPOPUP_overlay_adaugaSolAprobIf_cerere_achizitii').show();
		});

		$('#newPOPUP_close_adaugaSolAprobIf_cerere_achizitii').on('click', function () {
			$('#newPOPUP_overlay_adaugaSolAprobIf_cerere_achizitii').hide();
		});

		$('#newPOPUP_alege_adaugaSolAprobIf_cerere_achizitii').on('click', function () {
			var unitatiAprobareAlese = [];

			if ($('#newPOPUP_overlay_adaugaSolAprobIf_cerere_achizitii .newPOPUP_row input:checkbox:checked').length > 0) {

				$('#newPOPUP_overlay_adaugaSolAprobIf_cerere_achizitii .newPOPUP_row input:checkbox:checked').each(function (index) {
					unitatiAprobareAlese[index] = {
						"intro": $(this).attr('data-intro'),
						"id": $(this).attr('data-id'),
					}
				});

				console.log(unitatiAprobareAlese);

				newSolicitariAprobare2(JSON.stringify(unitatiAprobareAlese));
			} // if checked > 0
		}); // on click ALEGE







		//--------------------------------------------------------------------------------------------------------
		//--------------------------------------------------------------------------------------------------------
		//------------------------------ ADAUGA SOLICITARI APROBARE BUN -----------------------------------------
		if (
			(window.location.href.indexOf('issues') != -1) &&
			(
				($('#content h2').text().indexOf('Document de iesire #') != -1) ||
				($('#content h2').text().indexOf('Document intern #') != -1) ||
				($('#content h2').text().indexOf('Proiecte Instalare Echipamente #') != -1)
			)
		) {
			//$('#buttonNewSolAprobIfDocAprobCond').show();

			if (
				(window.location.href.indexOf('issues') != -1) && ($('#content h2').text().indexOf('Proiecte Instalare Echipamente #') != -1)
			) {

			} else {
				$('#buttonNewSolAprobIfDocAprobCond_addVerificare').show();
			}

			$('#buttonNewSolAprobIfDocAprobCond_addVerificare').on('click', function () {
				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,relations"
				}).done(function (data) {

					if (data.issue.status.id == 8) {
						alert("Nu se poate crea subtask de tip 'Solicitare aprobare' daca '" + $('h2').text() + "' este Closed/Inchis");
					} else {

						if (data.issue.status.id == 4) { // daca parintele este New, il facem Open 
							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": 'admin'
								},	// $('#loggedas .user').text()
								url: "/issues/" + data.issue.id + ".json",
								data: JSON.stringify({ "issue": { "status_id": "1" } })
							}).done(function (data) {
								console.log(data);
								console.log('Statusul pentru: ' + data.issue.id + " a fost schimbat in 1(open)");
							});
						}

						var relationsJSON = [];
						if (data.issue.relations != undefined) {
							for (i = 0; i <= data.issue.relations.length - 1; i++) {
								if (data.issue.relations[i].relation_type == "relates") {
									relationsJSON.push((data.issue.relations[i].issue_to_id).toString());
								}
							}
						}
						localStorage.setItem('currentIssueRelations', JSON.stringify(relationsJSON));



						/*---------------------- WATCHER LOCKED -------------------------*/
						var users_locked = [];
						var j = 0;
						for (i = 0; i <= $('.watchers li').length - 1; i++) {
							if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
								users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
								j++;
								console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
							}
							if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
								users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
								j++;
								console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
							}
						}


						var watchersJSON = [];
						for (i = 0; i <= data.issue.watchers.length - 1; i++) {
							//watchersJSON.push( (data.issue.watchers[i].id).toString() );
							if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
								watchersJSON.push((data.issue.watchers[i].id).toString());
							} else {
								console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
							}
						}

						/*--------- REMOVE WATCHERS DUPLICATES ---------*/
						var unique_watchersJSON = [];

						$.each(watchersJSON, function (i, el) {
							if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
						});
						watchersJSON = unique_watchersJSON
						console.log(watchersJSON);
						/*======= END REMOVE WATCHERS DUPLICATES ========*/

						localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));






						if (data.issue.subject != undefined) {
							localStorage.setItem('solicitareAprobare_parentSubject', data.issue.subject);
						} else { alert('Task-ul parinte nu are subiect'); }
						if (data.issue.project != undefined) {
							localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
						} else { alert('Task-ul parinte nu are project id'); }
						if (data.issue.assigned_to != undefined) {
							localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
						} else { alert('Task-ul parinte nu are asignat'); }
						if (data.issue.id != undefined) {
							localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
						}
						/*localStorage.setItem('solicitareAprobare_parentSubject',data.issue.subject);
						localStorage.setItem('solicitareAprobare_parentProjectId',data.issue.project.id);
						localStorage.setItem('solicitareAprobare_parentAssignedId',data.issue.assigned_to.id);
						localStorage.setItem('solicitareAprobare_parentIssueId',data.issue.id);*/


						setTimeout(function () {
							newSolicitareSubtask(
								"Rog verificare documente: ",
								"1269",
								data.issue.project.id,
								data.issue.assigned_to.id,
								data.issue.id,
								"1" // OPEN=1 NEW=4
							);

							$(document).bind('ajaxStop', function () {
								setTimeout(function () {
									window.location.reload();
								}, 100);
							});

						}, 300);
					} // daca parintele nu e Closed/Inchis


				});	// ajax done function		
			}); // ADD SG verificare documente




			//--------------------------- Consilieri juridici ----------------------------------
			if ( // trebuie sa il vada doar DOES si sa fie document de iesire
				($('.assigned-to .value').text().indexOf('DOES - Conducere') != -1) && ($('#content h2').text().indexOf('Document de iesire #') != -1)
			) {
				$('#buttonNewSolAprobIfDocAprobCond_addVerificare_consilieri').show();
			}

			$('#buttonNewSolAprobIfDocAprobCond_addVerificare_consilieri').on('click', function () {
				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,relations"
				}).done(function (data) {

					if (data.issue.status.id == 8) {
						alert("Nu se poate crea subtask de tip 'Solicitare aprobare' daca '" + $('h2').text() + "' este Closed/Inchis");
					} else {

						if (data.issue.status.id == 5) { // daca parintele este Assigned, il facem Open 
							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": $('#loggedas .user').text()
								},
								url: "/issues/" + data.issue.id + ".json",
								data: JSON.stringify({ "issue": { "status_id": "1" } })
							}).done(function (data) {
								console.log(data);
								console.log('Statusul pentru: ' + data.issue.id + " a fost schimbat in 1(open)");
							});
						}

						var relationsJSON = [];
						if (data.issue.relations != undefined) {
							for (i = 0; i <= data.issue.relations.length - 1; i++) {
								if (data.issue.relations[i].relation_type == "relates") {
									relationsJSON.push((data.issue.relations[i].issue_to_id).toString());
								}
							}
						}
						localStorage.setItem('currentIssueRelations', JSON.stringify(relationsJSON));


						/*---------------------- WATCHER LOCKED -------------------------*/
						var users_locked = [];
						var j = 0;
						for (i = 0; i <= $('.watchers li').length - 1; i++) {
							if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
								users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
								j++;
								console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
							}
							if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
								users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
								j++;
								console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
							}
						}

						var watchersJSON = [];
						for (i = 0; i <= data.issue.watchers.length - 1; i++) {
							//watchersJSON.push( (data.issue.watchers[i].id).toString() );
							if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
								watchersJSON.push((data.issue.watchers[i].id).toString());
							} else {
								console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
							}
						}

						/*--------- REMOVE WATCHERS DUPLICATES ---------*/
						var unique_watchersJSON = [];

						$.each(watchersJSON, function (i, el) {
							if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
						});
						watchersJSON = unique_watchersJSON
						console.log(watchersJSON);
						/*======= END REMOVE WATCHERS DUPLICATES ========*/

						localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));


						if (data.issue.subject != undefined) {
							localStorage.setItem('solicitareAprobare_parentSubject', data.issue.subject);
						} else { alert('Task-ul parinte nu are subiect'); }
						if (data.issue.project != undefined) {
							localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
						} else { alert('Task-ul parinte nu are project id'); }
						if (data.issue.assigned_to != undefined) {
							localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
						} else { alert('Task-ul parinte nu are asignat'); }
						if (data.issue.id != undefined) {
							localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
						}
						/*localStorage.setItem('solicitareAprobare_parentSubject',data.issue.subject);
						localStorage.setItem('solicitareAprobare_parentProjectId',data.issue.project.id);
						localStorage.setItem('solicitareAprobare_parentAssignedId',data.issue.assigned_to.id);
						localStorage.setItem('solicitareAprobare_parentIssueId',data.issue.id);*/


						setTimeout(function () {
							newSolicitareSubtask_consJuridici(
								"Rog aviz juridic: ",
								"1753",
								data.issue.project.id,
								data.issue.assigned_to.id,
								data.issue.id,
								"1" // OPEN=1 NEW=4
							);

							$(document).bind('ajaxStop', function () {
								setTimeout(function () {
									window.location.reload();
								}, 100);
							});

						}, 300);
					} // daca parintele nu e Closed/Inchis


				});	// ajax done function		
			}); // ADD SG verificare documente
			//======================== END CONSILIERI JURIDICI =================================








			var createdSolicitareAprobare = [];
			localStorage.setItem('createdSolicitareAprobare', JSON.stringify(createdSolicitareAprobare));

			$('#buttonNewSolAprobIfDocAprobCond').on('click', function () {
				$('#newPOPUP_overlay_solicitareAprobare').show();
			});

			$('#newPOPUP_close_solicitareAprobare').on('click', function () {
				$('#newPOPUP_overlay_solicitareAprobare').hide();
				//uncheck all the boxes;
			});

			$('#newPOPUP_cauta_solicitareAprobare').on('keyup', function () {
				if ($('#newPOPUP_cauta_solicitareAprobare').val() == '') {
					$('.newPOPUP_row').show();
				} else {
					$('.newPOPUP_row').each(function () {
						if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_solicitareAprobare').val().toLowerCase()) == -1) {
							$(this).hide();
						} else {
							$(this).show();
						}
					});
				}
			});

			$('#solicitareAprobareDirector_checkbox').on('click', function () {
				if (this.checked) {
					$('#solicitareAprobare_SG_row').show();
				} else {
					$('#solicitareAprobare_SG_row').hide();
				}
			});

			/*$('.solicitareAprobareSG_checkbox').on('click',function(){
				if(this.checked) {
					$('.solicitareAprobareSG_checkbox').prop('checked',true);
				} else {
					$('.solicitareAprobareSG_checkbox').prop('checked',false);
				}
			});*/


			$('#newPOPUP_alege_solicitareAprobare').on('click', function () {
				var unitatiAprobareAlese = [];

				if ($('#newPOPUP_overlay_solicitareAprobare .newPOPUP_row input:checkbox:checked').length > 0) {

					$('#newPOPUP_overlay_solicitareAprobare .newPOPUP_row input:checkbox:checked').each(function (index) {
						unitatiAprobareAlese[index] = {
							"intro": $(this).attr('data-intro'),
							"id": $(this).attr('data-id'),
						}
					});

					console.log(unitatiAprobareAlese);

					newSolicitariAprobare2(JSON.stringify(unitatiAprobareAlese));
				} // if checked > 0
			}); // on click ALEGE


		} // if	Document intern || Document de iesire
	} // if( localStorage.getItem('currentIssue_project_id') == 822 ) {



	//------------------------------- function newSolicitareSubtask -------------------------------------------------------
	function newSolicitareSubtask(issueIntro, assignedToUpdate, parentProjectId, parentAssignedId, parentIssueId, statusID) {

		/*------ Adaugam watcherii de conducere STS - vizualizare -------*/
		//var conducereWatchers = ['91','639','638','637','640','54','88','90','972'];		
		var conducereWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + "1432" + ".json?include=users"  // group STS - Vizualizare
		}).done(function (data) {
			//console.log(data.group.users);
			var conducereWatchers = [];
			$.each(data.group.users, function (index, value) {
				conducereWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('conducereWatchers', JSON.stringify(conducereWatchers, null, 2));
		}); // get watchers from CONDUCERE group
		/*======= END Adaugam watcherii de conducere STS - vizualizare ======*/



		/*------ Adaugam watcherii de pe issue assigned to -------*/
		var assignedToIdWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + localStorage.getItem('currentIssue_assigned_to_id') + ".json?include=users"
		}).done(function (data) {
			//console.log(data.group.users);
			var assignedToIdWatchers = [];
			$.each(data.group.users, function (index, value) {
				assignedToIdWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('assignedToIdWatchers', JSON.stringify(assignedToIdWatchers, null, 2));
		});
		/*======= END Adaugam watcherii de pe issue assigned to ======*/

		var currentIssueWatchers = JSON.parse(localStorage.getItem('currentIssueWatchers'));
		var conducereWatchers = JSON.parse(localStorage.getItem('conducereWatchers'));
		var assignedToIdWatchers = JSON.parse(localStorage.getItem('assignedToIdWatchers'));

		var allWatchersToAdd_0 = $.merge(currentIssueWatchers, conducereWatchers);
		if (assignedToIdWatchers == undefined) {
			assignedToIdWatchers = [];
		}
		var allWatchersToAdd = $.merge(allWatchersToAdd_0, assignedToIdWatchers);



		var newIssue =
		{
			"issue":
			{
				"project_id": parentProjectId,//project_id
				"tracker_id": 49, // solicitare aprobare
				"status_id": statusID, // NEW sau OPEN
				"priority_id": 2, // normala
				"subject": issueIntro + localStorage.getItem('solicitareAprobare_parentSubject'),
				"assigned_to_id": parentAssignedId,
				"parent_issue_id": parentIssueId, //window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]
				"watcher_user_ids": allWatchersToAdd //JSON.parse(localStorage.getItem('currentIssueWatchers'))
				//"related_issue_ids": localStorage.getItem('currentIssueRelations')
			}
		}



		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue)
		}).done(function (data) {
			console.log("newSolicitareSubtask() - POST new subtask issue");
			console.log(data);

			$('#content').prepend("<div class='flash notice' id='flash_notice'>Issue <a target='_blank' href='/issues/" + data.issue.id + "'>" + data.issue.id + "</a> a fost creat cu succes!</div>");

			var createdSolicitareAprobare = JSON.parse(localStorage.getItem('createdSolicitareAprobare'));
			createdSolicitareAprobare.push(data.issue.id);
			localStorage.setItem('createdSolicitareAprobare', JSON.stringify(createdSolicitareAprobare));

			if (
				assignedToUpdate == 1477 ||
				assignedToUpdate == 1354 ||
				assignedToUpdate == 324 ||
				assignedToUpdate == 325 ||
				assignedToUpdate == 326
			) {
				localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
				localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
				localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
			}


			var i = 0;

			//---------------------- ADD RELATIONS - RELATED ISSUES - to new solicitare aprobare -----------------------------
			function addRelationsLoop() {
				if (localStorage.getItem('currentIssueRelations') != undefined) {
					if (i <= JSON.parse(localStorage.getItem('currentIssueRelations')).length - 1) {
						$.ajax({
							type: "POST",
							//async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							}, // 12345 aici trebuie admin pentru add relations $('#loggedas .user').text()
							url: "/issues/" + data.issue.id + "/relations?relation[relation_type]=relates&relation[issue_to_id]=" + JSON.parse(localStorage.getItem('currentIssueRelations'))[i] + "&relation[delay]=&commit=Add"
						}).done(function (data) {
							//console.log(data);
							addRelationsLoop();
						});
						i++;
					}
				}
			}
			addRelationsLoop();



			$.ajax({
				type: "PUT",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				},
				url: "/issues/" + data.issue.id + ".json",
				data: JSON.stringify({ "issue": { "project_id": "822", "assigned_to_id": assignedToUpdate } })
			}).done(function (data) {
				console.log("PUT update la project_id CONDUCERE 822 si " + assignedToUpdate);
				console.log(data);
			});

		});


	} // function newSolicitareSubtask()







	//------------------------------- function newSolicitareSubtask_consJuridici -------------------------------------------------------
	function newSolicitareSubtask_consJuridici(issueIntro, assignedToUpdate, parentProjectId, parentAssignedId, parentIssueId, statusID) {

		/*------ Adaugam watcherii de conducere STS - vizualizare -------*/
		//var conducereWatchers = ['91','639','638','637','640','54','88','90','972'];		
		var conducereWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + "1432" + ".json?include=users"  // group STS - Vizualizare
		}).done(function (data) {
			//console.log(data.group.users);
			var conducereWatchers = [];
			$.each(data.group.users, function (index, value) {
				conducereWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('conducereWatchers', JSON.stringify(conducereWatchers, null, 2));
		}); // get watchers from CONDUCERE group
		/*======= END Adaugam watcherii de conducere STS - vizualizare ======*/



		/*------ Adaugam watcherii de pe issue assigned to -------*/
		var assignedToIdWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + localStorage.getItem('currentIssue_assigned_to_id') + ".json?include=users"
		}).done(function (data) {
			//console.log(data.group.users);
			var assignedToIdWatchers = [];
			$.each(data.group.users, function (index, value) {
				assignedToIdWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('assignedToIdWatchers', JSON.stringify(assignedToIdWatchers, null, 2));
		});
		/*======= END Adaugam watcherii de pe issue assigned to ======*/

		var currentIssueWatchers = JSON.parse(localStorage.getItem('currentIssueWatchers'));
		var conducereWatchers = JSON.parse(localStorage.getItem('conducereWatchers'));
		var assignedToIdWatchers = JSON.parse(localStorage.getItem('assignedToIdWatchers'));

		var allWatchersToAdd_0 = $.merge(currentIssueWatchers, conducereWatchers);
		if (assignedToIdWatchers == undefined) {
			assignedToIdWatchers = [];
		}
		var allWatchersToAdd = $.merge(allWatchersToAdd_0, assignedToIdWatchers);



		var newIssue =
		{
			"issue":
			{
				"project_id": parentProjectId,//project_id
				"tracker_id": 49, // solicitare aprobare
				"status_id": statusID, // NEW sau OPEN
				"priority_id": 2, // normala
				"subject": issueIntro + localStorage.getItem('solicitareAprobare_parentSubject'),
				"assigned_to_id": parentAssignedId,
				"parent_issue_id": parentIssueId, //window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]
				"watcher_user_ids": allWatchersToAdd //JSON.parse(localStorage.getItem('currentIssueWatchers'))
				//"related_issue_ids": localStorage.getItem('currentIssueRelations')
			}
		}



		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue)
		}).done(function (data) {
			console.log("POST new subtask issue");
			console.log(data);

			$('#content').prepend("<div class='flash notice' id='flash_notice'>Issue <a target='_blank' href='/issues/" + data.issue.id + "'>" + data.issue.id + "</a> a fost creat cu succes!</div>");

			var createdSolicitareAprobare = JSON.parse(localStorage.getItem('createdSolicitareAprobare'));
			createdSolicitareAprobare.push(data.issue.id);
			localStorage.setItem('createdSolicitareAprobare', JSON.stringify(createdSolicitareAprobare));

			if (
				assignedToUpdate == 1477 ||
				assignedToUpdate == 1354 ||
				assignedToUpdate == 324 ||
				assignedToUpdate == 325 ||
				assignedToUpdate == 326
			) {
				localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
				localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
				localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
			}


			var i = 0;

			//---------------------- ADD RELATIONS - RELATED ISSUES - to new solicitare aprobare -----------------------------
			function addRelationsLoop() {
				if (localStorage.getItem('currentIssueRelations') != undefined) {
					if (i <= JSON.parse(localStorage.getItem('currentIssueRelations')).length - 1) {
						$.ajax({
							type: "POST",
							//async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							}, // 12345 aici trebuie admin pentru add relations $('#loggedas .user').text()
							url: "/issues/" + data.issue.id + "/relations?relation[relation_type]=relates&relation[issue_to_id]=" + JSON.parse(localStorage.getItem('currentIssueRelations'))[i] + "&relation[delay]=&commit=Add"
						}).done(function (data) {
							//console.log(data);
							addRelationsLoop();
						});
						i++;
					}
				}
			}
			addRelationsLoop();


			//-------------------- adaugam in proiect DJSG 856 ----------------------
			/*
			$.ajax({
				type:"PUT",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'}, // $('#loggedas .user').text()
				url:"/issues/"+data.issue.id+".json",
				data: JSON.stringify({"issue":{"project_id":"856"}})  //AICI trebuie ID de DJSG 856
			}).done(function(data){				
				console.log("PUT update la project_id DJSG");
				console.log(data);	
			}); 
			*/
			//-------------------- adaugam asignee Consilieri Juridici DOES ----------------------
			$.ajax({
				type: "PUT",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				}, // $('#loggedas .user').text()
				url: "/issues/" + data.issue.id + ".json",
				data: JSON.stringify({ "issue": { "assigned_to_id": assignedToUpdate } })  //AICI trebuie ID de DJSG 856
			}).done(function (data) {
				console.log("PUT update asignee: " + assignedToUpdate);
				console.log(data);
			});

		});


	} // function newSolicitareSubtask_consJuridici()


	//------------------------------- function newSolicitareSubtask_cerereAchizitii -------------------------------------------------------
	function newSolicitareSubtask_cerereAchizitii(issueIntro, assignedToUpdate, parentProjectId, parentAssignedId, parentIssueId, statusID) {

		/*------ Adaugam watcherii de conducere STS - vizualizare -------*/
		//var conducereWatchers = ['91','639','638','637','640','54','88','90','972'];		
		var conducereWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + "1432" + ".json?include=users"  // group STS - Vizualizare
		}).done(function (data) {
			//console.log(data.group.users);
			var conducereWatchers = [];
			$.each(data.group.users, function (index, value) {
				conducereWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('conducereWatchers', JSON.stringify(conducereWatchers, null, 2));
		}); // get watchers from CONDUCERE group
		/*======= END Adaugam watcherii de conducere STS - vizualizare ======*/



		/*------ Adaugam watcherii de pe issue assigned to -------*/
		var assignedToIdWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + localStorage.getItem('currentIssue_assigned_to_id') + ".json?include=users"
		}).done(function (data) {
			//console.log(data.group.users);
			var assignedToIdWatchers = [];
			$.each(data.group.users, function (index, value) {
				assignedToIdWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('assignedToIdWatchers', JSON.stringify(assignedToIdWatchers, null, 2));
		});
		/*======= END Adaugam watcherii de pe issue assigned to ======*/

		var currentIssueWatchers = JSON.parse(localStorage.getItem('currentIssueWatchers'));
		var conducereWatchers = JSON.parse(localStorage.getItem('conducereWatchers'));
		var assignedToIdWatchers = JSON.parse(localStorage.getItem('assignedToIdWatchers'));

		var allWatchersToAdd_0 = $.merge(currentIssueWatchers, conducereWatchers);
		if (assignedToIdWatchers == undefined) {
			assignedToIdWatchers = [];
		}
		var allWatchersToAdd = $.merge(allWatchersToAdd_0, assignedToIdWatchers);



		var newIssue =
		{
			"issue":
			{
				"project_id": parentProjectId,//project_id
				"tracker_id": 49, // solicitare aprobare
				"status_id": statusID, // NEW sau OPEN
				"priority_id": 2, // normala
				"subject": issueIntro + localStorage.getItem('solicitareAprobare_parentSubject'),
				"assigned_to_id": parentAssignedId,
				"parent_issue_id": parentIssueId, //window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]
				"watcher_user_ids": allWatchersToAdd //JSON.parse(localStorage.getItem('currentIssueWatchers'))
				//"related_issue_ids": localStorage.getItem('currentIssueRelations')
			}
		}



		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue)
		}).done(function (data) {
			console.log("POST new subtask issue");
			console.log(data);

			$('#content').prepend("<div class='flash notice' id='flash_notice'>Issue <a target='_blank' href='/issues/" + data.issue.id + "'>" + data.issue.id + "</a> a fost creat cu succes!</div>");

			var createdSolicitareAprobare = JSON.parse(localStorage.getItem('createdSolicitareAprobare'));
			createdSolicitareAprobare.push(data.issue.id);
			localStorage.setItem('createdSolicitareAprobare', JSON.stringify(createdSolicitareAprobare));

			if (
				assignedToUpdate == 1477 ||
				assignedToUpdate == 1354 ||
				assignedToUpdate == 324 ||
				assignedToUpdate == 325 ||
				assignedToUpdate == 326
			) {
				localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
				localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
				localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
			}


			var i = 0;

			//---------------------- ADD RELATIONS - RELATED ISSUES - to new solicitare aprobare -----------------------------
			function addRelationsLoop() {
				if (localStorage.getItem('currentIssueRelations') != undefined) {
					if (i <= JSON.parse(localStorage.getItem('currentIssueRelations')).length - 1) {
						$.ajax({
							type: "POST",
							//async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							}, // 12345 aici trebuie admin pentru add relations $('#loggedas .user').text()
							url: "/issues/" + data.issue.id + "/relations?relation[relation_type]=relates&relation[issue_to_id]=" + JSON.parse(localStorage.getItem('currentIssueRelations'))[i] + "&relation[delay]=&commit=Add"
						}).done(function (data) {
							//console.log(data);
							addRelationsLoop();
						});
						i++;
					}
				}
			}
			addRelationsLoop();



			$.ajax({
				type: "PUT",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				},
				url: "/issues/" + data.issue.id + ".json",
				data: JSON.stringify({ "issue": { "project_id": "822", "assigned_to_id": assignedToUpdate } })
			}).done(function (data) {
				console.log("PUT update la project_id CONDUCERE 822 si " + assignedToUpdate);
				console.log(data);
			});

		});


	} // function newSolicitareSubtask()








	function newSolicitariAprobare2(jsonStringAlese) {

		var unitatiAprobareAlese = JSON.parse(jsonStringAlese);


		//----------------------- ADAUGA Watcherii grupurilor alese din popup pe issue parinte --------------------
		var urlForWatchersToAdd = "/watchers.json?object_id=" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + "&watcher[user_ids][]=1432&object_type=issue";
		$.each(unitatiAprobareAlese, function (index, value) {
			urlForWatchersToAdd = urlForWatchersToAdd.concat("&watcher[user_ids][]=" + unitatiAprobareAlese[index].id);
		});

		console.log(urlForWatchersToAdd);
		console.log("---------------- ^^ -----------------");

		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			}, //$('#loggedas .user').text()
			url: urlForWatchersToAdd
		}).done(function (data) {
			console.log("newSolicitariAprobare2() - Watcher groups added successfully");
		});




		//----------------------- GET info despre issue parinte --------------------
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			}, //$('#loggedas .user').text()		
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,relations"
		}).done(function (data) {
			console.log("newSolicitariAprobare2() - GET info despre issue parinte");
			console.log(data);

			if (data.issue.status.id == 8) {
				alert("Nu se poate crea subtask de tip 'Solicitare aprobare' daca '" + $('h2').text() + "' este Closed/Inchis");
			} else {



				if (data.issue.status.id == 4) { // daca parintele este New, il facem Open 
					$.ajax({
						type: "PUT",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						}, //$('#loggedas .user').text()	
						url: "/issues/" + data.issue.id + ".json",
						data: JSON.stringify({ "issue": { "status_id": "1" } })
					}).done(function (data) {
						console.log(data);
						console.log('newSolicitariAprobare2() - Statusul pentru: ' + data.issue.id + " a fost schimbat in 1(open)");
					});
				}


				var relationsJSON = [];
				if (data.issue.relations != undefined) {
					for (i = 0; i <= data.issue.relations.length - 1; i++) {
						if (data.issue.relations[i].relation_type == "relates") {
							relationsJSON.push((data.issue.relations[i].issue_to_id).toString());
						}
					}
				}


				localStorage.setItem('currentIssueRelations', JSON.stringify(relationsJSON));


				/*---------------------- WATCHER LOCKED -------------------------*/
				var users_locked = [];
				var j = 0;
				for (i = 0; i <= $('.watchers li').length - 1; i++) {
					if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
						users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
						j++;
						console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
					}
					if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
						users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
						j++;
						console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
					}
				}

				var watchersJSON = [];
				for (i = 0; i <= data.issue.watchers.length - 1; i++) {
					//watchersJSON.push( (data.issue.watchers[i].id).toString() );
					if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
						watchersJSON.push((data.issue.watchers[i].id).toString());
					} else {
						console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
					}
				}

				/*--------- REMOVE WATCHERS DUPLICATES ---------*/
				var unique_watchersJSON = [];

				$.each(watchersJSON, function (i, el) {
					if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
				});
				watchersJSON = unique_watchersJSON
				console.log(watchersJSON);
				/*======= END REMOVE WATCHERS DUPLICATES ========*/

				localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));





				if (data.issue.subject != undefined) {
					localStorage.setItem('solicitareAprobare_parentSubject', data.issue.subject);
				} else { alert('Task-ul parinte nu are subiect'); }
				if (data.issue.project != undefined) {
					localStorage.setItem('solicitareAprobare_parentProjectId', data.issue.project.id);
				} else { alert('Task-ul parinte nu are project id'); }
				if (data.issue.assigned_to != undefined) {
					localStorage.setItem('solicitareAprobare_parentAssignedId', data.issue.assigned_to.id);
				} else { alert('Task-ul parinte nu are asignat'); }
				if (data.issue.id != undefined) {
					localStorage.setItem('solicitareAprobare_parentIssueId', data.issue.id);
				}
				/*localStorage.setItem('solicitareAprobare_parentSubject',data.issue.subject);
				localStorage.setItem('solicitareAprobare_parentProjectId',data.issue.project.id);
				localStorage.setItem('solicitareAprobare_parentAssignedId',data.issue.assigned_to.id);
				localStorage.setItem('solicitareAprobare_parentIssueId',data.issue.id);*/


				console.log(unitatiAprobareAlese);

				for (i = 0; i <= unitatiAprobareAlese.length - 1; i++) {
					if (
						unitatiAprobareAlese[i].id == "1477" ||
						unitatiAprobareAlese[i].id == "1354" ||
						unitatiAprobareAlese[i].id == "324" ||
						unitatiAprobareAlese[i].id == "325" ||
						unitatiAprobareAlese[i].id == "326"
					) {
						newSolicitareSubtask(
							unitatiAprobareAlese[i].intro,
							unitatiAprobareAlese[i].id,
							localStorage.getItem('solicitareAprobare_parentProjectId'),
							localStorage.getItem('solicitareAprobare_parentAssignedId'),
							localStorage.getItem('solicitareAprobare_parentIssueId'),
							"4" // OPEN=1 NEW=4
						);
					} else {
						if (unitatiAprobareAlese[i].id == "1269") {
							newSolicitareSubtask(
								unitatiAprobareAlese[i].intro,
								unitatiAprobareAlese[i].id,
								localStorage.getItem('solicitareAprobare_parentProjectId'),
								localStorage.getItem('solicitareAprobare_parentAssignedId'),
								data.issue.id,
								"4" // OPEN=1 NEW=4
							);
						} else {
							newSolicitareSubtask(
								unitatiAprobareAlese[i].intro,
								unitatiAprobareAlese[i].id,
								localStorage.getItem('solicitareAprobare_parentProjectId'),
								localStorage.getItem('solicitareAprobare_parentAssignedId'),
								localStorage.getItem('solicitareAprobare_parentIssueId'),
								"1" // OPEN=1 NEW=4
							);
						}
					}

					console.log('---------------');
					console.log(unitatiAprobareAlese[i].intro);
					console.log('newSolicitariAprobare2() - END ^');
				}

				$(document).bind('ajaxStop', function () {
					setTimeout(function () {
						var createdSolicitareAprobare = JSON.parse(localStorage.getItem('createdSolicitareAprobare'));
						console.log(createdSolicitareAprobare);

						window.location.reload(); //reloadsolicitareaprobare
					}, 500);
				});



			} // if parinte e Closed/Inchis	
		}); // ajax done function GET info parinte
	} //newSolicitariAprobare2()	











//------------------------- DOCUMENTE IN TRANZIT ----------------------------------------
if (
	(window.location.href.indexOf('issues') != -1) &&
	(
		$('#content h2').text().indexOf('Document intern #') != -1
	)
	&& ( $('#loggedas .user').text() == 'admin' || $('#loggedas .user').text() == 'radu.pereteanu' || $('#loggedas .user').text() == 'manuela.sarateanu' || $('#loggedas .user').text() == 'alexandra.luca')
) {
	$('#button_tranzit_if_doc_intern').show();

	$('#button_tranzit_if_doc_intern').on('click', function () {
		$('#newPOPUP_overlay_tranzit').show();
	});
	$('#newPOPUP_close_tranzit').on('click', function () {
		$('#newPOPUP_overlay_tranzit').hide();
	});


	// show SGG if STS - Director - Cabinet checked disabled readonly
	// $('#tranzitDirector_checkbox').on('click', function () {
	// 	if (this.checked) {
	// 		$('#tranzit_SG_row').show();
	// 	} else {
	// 		$('#tranzit_SG_row').hide();
	// 	}
	// });

	// cauta in modal tranzit
	$('#newPOPUP_cauta_tranzit').on('keyup', function () {
		if ($('#newPOPUP_cauta_tranzit').val() == '') {
			$('.newPOPUP_row').show();
		} else {
			$('.newPOPUP_row').each(function () {
				if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_tranzit').val().toLowerCase()) == -1) {
					$(this).hide();
				} else {
					$(this).show();
				}
			});
		}
	});


	// ADAUGA tranzit pentru unitati selectate
	$('#newPOPUP_alege_tranzit').on('click', function () {
		var unitatiAprobareAlese = [];
	
		if ($('#newPOPUP_overlay_tranzit .newPOPUP_row input:checkbox:checked').length > 0) {
	
			$('#newPOPUP_overlay_tranzit .newPOPUP_row input:checkbox:checked').each(function (index) {
				unitatiAprobareAlese[index] = {
					"intro": $(this).attr('data-intro'),
					"id": $(this).attr('data-id'),
				}
			});
	
			console.log(unitatiAprobareAlese);
	
			newTranzit(JSON.stringify(unitatiAprobareAlese));
		} // if checked > 0
	}); // on click ALEGE


	var createdTranzit = [];
	localStorage.setItem('createdTranzit', JSON.stringify(createdTranzit));







	function newTranzit(jsonStringAlese) {

		var unitatiAprobareAlese = JSON.parse(jsonStringAlese);
	
	
		//----------------------- ADAUGA Watcherii grupurilor alese din popup pe issue parinte --------------------
		var urlForWatchersToAdd = "/watchers.json?object_id=" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + "&watcher[user_ids][]=1432&object_type=issue";
		$.each(unitatiAprobareAlese, function (index, value) {
			urlForWatchersToAdd = urlForWatchersToAdd.concat("&watcher[user_ids][]=" + unitatiAprobareAlese[index].id);
		});
	
		console.log(urlForWatchersToAdd);
		console.log("---------------- ^^ -----------------");
	
		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			}, //$('#loggedas .user').text()
			url: urlForWatchersToAdd
		}).done(function (data) {
			console.log("newTranzit() - Watcher groups added successfully");
		});
	
	
	
	
		//----------------------- GET info despre issue parinte --------------------
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			}, //$('#loggedas .user').text()		
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,relations"
		}).done(function (data) {
			console.log("newTranzit() - GET info despre issue parinte");
			console.log(data);
	
			if (data.issue.status.id == 8) {
				alert("Nu se poate crea subtask de tip 'Tranzit' daca '" + $('h2').text() + "' este Closed/Inchis");
			} else {
	
	
	
				if (data.issue.status.id == 4) { // daca parintele este New, il facem Open 
					$.ajax({
						type: "PUT",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						}, //$('#loggedas .user').text()	
						url: "/issues/" + data.issue.id + ".json",
						data: JSON.stringify({ "issue": { "status_id": "1" } })
					}).done(function (data2) {
						console.log(data2);
						console.log('newTranzit() - Statusul pentru: ' + data2.issue.id + " a fost schimbat in 1(open)");
					});
				}
	
	
				var relationsJSON = [];
				if (data.issue.relations != undefined) {
					for (i = 0; i <= data.issue.relations.length - 1; i++) {
						if (data.issue.relations[i].relation_type == "relates") {
							relationsJSON.push((data.issue.relations[i].issue_to_id).toString());
						}
					}
				}
	
	
				localStorage.setItem('currentIssueRelations', JSON.stringify(relationsJSON));
	
	
				/*---------------------- WATCHER LOCKED -------------------------*/
				var users_locked = [];
				var j = 0;
				for (i = 0; i <= $('.watchers li').length - 1; i++) {
					if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
						users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
						j++;
						console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
					}
					if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
						users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
						j++;
						console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
					}
				}
	
				var watchersJSON = [];
				for (i = 0; i <= data.issue.watchers.length - 1; i++) {
					//watchersJSON.push( (data.issue.watchers[i].id).toString() );
					if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
						watchersJSON.push((data.issue.watchers[i].id).toString());
					} else {
						console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
					}
				}
	
				/*--------- REMOVE WATCHERS DUPLICATES ---------*/
				var unique_watchersJSON = [];
	
				$.each(watchersJSON, function (i, el) {
					if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
				});
				watchersJSON = unique_watchersJSON
				console.log(watchersJSON);
				/*======= END REMOVE WATCHERS DUPLICATES ========*/
	
				localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));
	
	
	
	
	
				if (data.issue.subject != undefined) {
					localStorage.setItem('tranzit_parentSubject', data.issue.subject);
				} else { alert('Task-ul parinte nu are subiect'); }
				if (data.issue.project != undefined) {
					localStorage.setItem('tranzit_parentProjectId', data.issue.project.id);
				} else { alert('Task-ul parinte nu are project id'); }
				if (data.issue.assigned_to != undefined) {
					localStorage.setItem('tranzit_parentAssignedId', data.issue.assigned_to.id);
				} else { alert('Task-ul parinte nu are asignat'); }
				if (data.issue.id != undefined) {
					localStorage.setItem('tranzit_parentIssueId', data.issue.id);
				}
				/*localStorage.setItem('tranzit_parentSubject',data.issue.subject);
				localStorage.setItem('tranzit_parentProjectId',data.issue.project.id);
				localStorage.setItem('tranzit_parentAssignedId',data.issue.assigned_to.id);
				localStorage.setItem('tranzit_parentIssueId',data.issue.id);*/
	
	
				console.log(unitatiAprobareAlese);
	
				for (i = 0; i <= unitatiAprobareAlese.length - 1; i++) {
					if (
						unitatiAprobareAlese[i].id == "1477" ||
						unitatiAprobareAlese[i].id == "1354" ||
						unitatiAprobareAlese[i].id == "324" ||
						unitatiAprobareAlese[i].id == "325" ||
						unitatiAprobareAlese[i].id == "326"
					) {
						newTranzitSubtask(
							unitatiAprobareAlese[i].intro,
							unitatiAprobareAlese[i].id,
							localStorage.getItem('tranzit_parentProjectId'),
							localStorage.getItem('tranzit_parentAssignedId'),
							localStorage.getItem('tranzit_parentIssueId'),
							"4" // OPEN=1 NEW=4
						);
					} else {
						newTranzitSubtask(
							unitatiAprobareAlese[i].intro,
							unitatiAprobareAlese[i].id,
							localStorage.getItem('tranzit_parentProjectId'),
							localStorage.getItem('tranzit_parentAssignedId'),
							localStorage.getItem('tranzit_parentIssueId'),
							"1" // OPEN=1 NEW=4
						);
					}
	
					console.log('---------------');
					console.log(unitatiAprobareAlese[i].intro);
					console.log('newTranzit() - END ^');
				}
	
				$(document).bind('ajaxStop', function () {
					setTimeout(function () {
						var createdTranzit = JSON.parse(localStorage.getItem('createdTranzit'));
						console.log(createdTranzit);
	
						window.location.reload(); //reloadTranzit
					}, 500);
				});
	
	
	
			} // if parinte e Closed/Inchis	
		}); // ajax done function GET info parinte
	} //newTranzit()	
	





	//------------------------------- function newTranzitSubtask -------------------------------------------------------
	function newTranzitSubtask(issueIntro, assignedToUpdate, parentProjectId, parentAssignedId, parentIssueId, statusID) {
	
		/*------ Adaugam watcherii de conducere STS - vizualizare -------*/
		//var conducereWatchers = ['91','639','638','637','640','54','88','90','972'];		
		var conducereWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + "1432" + ".json?include=users"  // group STS - Vizualizare
		}).done(function (data) {
			//console.log(data.group.users);
			var conducereWatchers = [];
			$.each(data.group.users, function (index, value) {
				conducereWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('conducereWatchers', JSON.stringify(conducereWatchers, null, 2));
		}); // get watchers from CONDUCERE group
		/*======= END Adaugam watcherii de conducere STS - vizualizare ======*/
	
	
	
		/*------ Adaugam watcherii de pe issue assigned to -------*/
		var assignedToIdWatchers = [];
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/groups/" + localStorage.getItem('currentIssue_assigned_to_id') + ".json?include=users"
		}).done(function (data) {
			//console.log(data.group.users);
			var assignedToIdWatchers = [];
			$.each(data.group.users, function (index, value) {
				assignedToIdWatchers.push(data.group.users[index].id.toString());
			});
			localStorage.setItem('assignedToIdWatchers', JSON.stringify(assignedToIdWatchers, null, 2));
		});
		/*======= END Adaugam watcherii de pe issue assigned to ======*/
	
		var currentIssueWatchers = JSON.parse(localStorage.getItem('currentIssueWatchers'));
		var conducereWatchers = JSON.parse(localStorage.getItem('conducereWatchers'));
		var assignedToIdWatchers = JSON.parse(localStorage.getItem('assignedToIdWatchers'));
	
		var allWatchersToAdd_0 = $.merge(currentIssueWatchers, conducereWatchers);
		if (assignedToIdWatchers == undefined) {
			assignedToIdWatchers = [];
		}
		var allWatchersToAdd = $.merge(allWatchersToAdd_0, assignedToIdWatchers);
	
	
	
		var newIssue_tranzit =
		{
			"issue":
			{
				"project_id": parentProjectId,//project_id
				"tracker_id": 74, //49 solicitare aprobare // 74 TRANZIT
				"status_id": statusID, // NEW sau OPEN
				"priority_id": 2, // normala
				"subject": issueIntro + localStorage.getItem('tranzit_parentSubject'),
				"assigned_to_id": parentAssignedId,
				"parent_issue_id": parentIssueId, //window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]
				"watcher_user_ids": allWatchersToAdd //JSON.parse(localStorage.getItem('currentIssueWatchers'))
				//"related_issue_ids": localStorage.getItem('currentIssueRelations')
			}
		}
		console.log('newIssue Tranzit', newIssue_tranzit);
	
	
		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue_tranzit)
		}).done(function (data) {
			console.log("newTranzitSubtask() - POST new subtask issue");
			console.log(data);
	
			$('#content').prepend("<div class='flash notice' id='flash_notice'>Issue <a target='_blank' href='/issues/" + data.issue.id + "'>" + data.issue.id + "</a> a fost creat cu succes!</div>");
	
			var createdTranzit = JSON.parse(localStorage.getItem('createdTranzit'));
			createdTranzit.push(data.issue.id);
			localStorage.setItem('createdTranzit', JSON.stringify(createdTranzit));
	
			// if( assignedToUpdate == 1477 ) {
			// 	localStorage.setItem('tranzit_tree_parent_issue', data.issue.id);
			// }
			if (
				assignedToUpdate == 1477 || 
				assignedToUpdate == 1354 ||
				assignedToUpdate == 324 ||
				assignedToUpdate == 325 ||
				assignedToUpdate == 326
			) {
				localStorage.setItem('tranzit_parentProjectId', data.issue.project.id);
				localStorage.setItem('tranzit_parentAssignedId', data.issue.assigned_to.id);
				localStorage.setItem('tranzit_parentIssueId', data.issue.id);
			}
	
	
			var i = 0;
	
			//---------------------- ADD RELATIONS - RELATED ISSUES - to new tranzit -----------------------------
			function addRelationsLoop() {
				if (localStorage.getItem('currentIssueRelations') != undefined) {
					if (i <= JSON.parse(localStorage.getItem('currentIssueRelations')).length - 1) {
						$.ajax({
							type: "POST",
							//async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							}, // 12345 aici trebuie admin pentru add relations $('#loggedas .user').text()
							url: "/issues/" + data.issue.id + "/relations?relation[relation_type]=relates&relation[issue_to_id]=" + JSON.parse(localStorage.getItem('currentIssueRelations'))[i] + "&relation[delay]=&commit=Add"
						}).done(function (data) {
							//console.log(data);
							addRelationsLoop();
						});
						i++;
					}
				}
			}
			addRelationsLoop();
	
	
			$.ajax({
				type: "PUT",
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				},
				url: "/issues/" + data.issue.id + ".json",
				data: JSON.stringify({ "issue": { "project_id": "822", "assigned_to_id": assignedToUpdate } })
			}).done(function (data) {
				console.log("PUT update la project_id CONDUCERE 822 si " + assignedToUpdate);
				console.log(data);
			});


			// $.ajax({
			// 	type: "PUT",
			// 	headers: {
			// 		"Content-Type": "application/json",
			// 		"X-Redmine-API-Key": STS.apiKey,
			// 		"X-Redmine-Switch-User": $('#loggedas .user').text()
			// 	},
			// 	url: "/issues/" + data.issue.id + ".json",
			// 	data: JSON.stringify({ "issue": { "project_id": "822", "assigned_to_id": assignedToUpdate } }),
			// 	statusCode: {
			// 		200: function(response) {
			// 			if( assignedToUpdate == 1477 ) {

			// 				var currentIssue = JSON.parse(localStorage.getItem('currentIssue'));
			// 				assignedToUpdate = currentIssue.issue.assigned_to.id;
			
			// 				$.ajax({
			// 					type: "PUT",
			// 					headers: {
			// 						"Content-Type": "application/json",
			// 						"X-Redmine-API-Key": STS.apiKey,
			// 						"X-Redmine-Switch-User": $('#loggedas .user').text()
			// 					},
			// 					url: "/issues/" + data.issue.id + ".json",
			// 					data: JSON.stringify({ "issue": { "project_id": "822", "assigned_to_id": assignedToUpdate } })
			// 				}).done(function (data) {
			// 					console.log("PUT update la project_id CONDUCERE 822 si " + assignedToUpdate);
			// 					console.log(data);
			// 				});
			
			// 			} // tranzit parent tree asignee
			// 		}
			// 	}

			// });

						

	
		});
	
	
	} // function newTranzitSubtask()
	
} // if document intern for tranzit


if (
	(window.location.href.indexOf('issues') != -1) &&
	(
		$('#content h2').text().indexOf('Tranzit #') != -1
	)
	&& ( $('#loggedas .user').text() == 'admin' || $('#loggedas .user').text() == 'radu.pereteanu' || $('#loggedas .user').text() == 'manuela.sarateanu' || $('#loggedas .user').text() == 'alexandra.luca')
) {
	$('#button_tranzit_in_lucru,#button_tranzit_aproba').show();
	
	$('#button_tranzit_in_lucru').on('click', function () {
		var issue_id_approve = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];
		$.ajax({
			type: "PUT",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + issue_id_approve + ".json",
			data: JSON.stringify({ "issue": { "status_id": "17" } })
		}).done(function (data) {
			console.log(data);
		});

		aprobareClickDreapta(issue_id_approve);

		$(document).bind('ajaxStop', function () {
			setTimeout(function () {
				window.location.reload();
			}, 100);
		});
	});

	$('#button_tranzit_aproba').on('click', function () {
		var issue_id_approve = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];
		$.ajax({
			type: "PUT",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + issue_id_approve + ".json",
			data: JSON.stringify({ "issue": { "status_id": "24" } })
		}).done(function (data) {
			console.log(data);
		});

		aprobareClickDreapta(issue_id_approve);

		$(document).bind('ajaxStop', function () {
			setTimeout(function () {
				window.location.reload();
			}, 100);
		});
	});
} // if tranzit subtask show buttons in lucru & aproba


//======================== END DOCUMENTE IN TRANZIT =====================================




























	function commentDeleteOnParent(issueID, noteToAdd) {
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issueID + ".json?include=journals"
		}).done(function (data) {
			if (data.issue.parent != undefined) {
				var parentOfParent = data.issue.parent.id;
				console.log(parentOfParent);

				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, //$('#loggedas .user').text()		
					url: "/issues/" + parentOfParent + ".json",
					data: JSON.stringify({ "issue": { "notes": noteToAdd } })
				}).done(function (data) {
					//console.log(data);
				});

				setTimeout(function () {
					commentDeleteOnParent(parentOfParent, noteToAdd);
				}, 100);
			}
		});

	}; // function commentDeleteOnParent()


	function commentEditOnParent(issueID, noteToAdd) {
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issueID + ".json?include=journals"
		}).done(function (data) {
			if (data.issue.parent != undefined) {
				var parentOfParent = data.issue.parent.id;
				console.log(parentOfParent);

				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, //$('#loggedas .user').text()		
					url: "/issues/" + parentOfParent + ".json",
					data: JSON.stringify({ "issue": { "notes": noteToAdd } })
				}).done(function (data) {
					//console.log(data);
				});

				setTimeout(function () {
					commentEditOnParent(parentOfParent, noteToAdd);
				}, 100);
			}
		});

	}; // function commentEditOnParent()


	function commentOnParent(issueID, noteToAdd) {
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issueID + ".json?include=journals"
		}).done(function (data) {
			if (data.issue.parent != undefined) {
				var parentOfParent = data.issue.parent.id;
				console.log(parentOfParent);

				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, //$('#loggedas .user').text()		
					url: "/issues/" + parentOfParent + ".json",
					data: JSON.stringify({ "issue": { "notes": noteToAdd } })
				}).done(function (data) {
					//console.log(data);
				});

				setTimeout(function () {
					commentOnParent(parentOfParent, noteToAdd);
				}, 100);
			}
		});

	}; // function commentOnParent()


	function addWatcherOnParent(issueID, watcherToAdd, assignedIsGroup) {
		console.log("Adding " + watcherToAdd + " to parent issue id: " + issueID);

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issueID + ".json?include=journals"
		}).done(function (data) {
			// if (data.issue.tracker.name.indexOf('Document electronic') == -1) {
			// 	return;
			// } 
			var watchers = "";
			if (assignedIsGroup) {
				$.each(watcherToAdd, function (index) {
					watchers = watchers + "&watcher[user_ids][]=" + watcherToAdd[index];
				});
			} else {
				watchers = "&watcher[user_ids][]=" + watcherToAdd;
			}

			var watchers_json  = "utf8=✓&object_type=issue&object_id[]=" + issueID + "&user_search=" + watchers;
			$.ajax({
				type: "POST",
				async: false,
				headers: {
					"Content-Type": "application/x-www-form-urlencoded",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/watchers",
				dataType: "text/javascript; charset=utf-8",
				data: watchers_json
			}).done(function (data) {
				console.log(data);
			});			


			if (data.issue.parent != undefined) {
				var parentOfParent = data.issue.parent.id;
				console.log(parentOfParent);

				setTimeout(function () {
					addWatcherOnParent(parentOfParent, watcherToAdd, assignedIsGroup);
				}, 100);
			}
		});

	};

	$(document).on('submit', '#new-relation-form', function (value) {
		console.log(value);
		console.log($('#relation_issue_to_id').val());

		var relationIssueId = $('#relation_issue_to_id').val();
		var currentIssueId = localStorage.getItem('currentIssue_id');
		var currentIssue;
		var relationIssue;
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + relationIssueId + ".json?include=watchers"
		}).done(function (data) {
			relationIssue = data.issue;
		});
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + currentIssueId + ".json?include=watchers"
		}).done(function (data) {
			currentIssue = data.issue;
		});

		if (currentIssue.tracker.name.indexOf('Cerere de servicii') == -1 && relationIssue.tracker.name.indexOf('Cerere de servicii') != -1) {
			var sourceIssue = relationIssue;
			var destinationIssue = currentIssue;
		} else if (currentIssue.tracker.name.indexOf('Cerere de servicii') != -1 && relationIssue.tracker.name.indexOf('Cerere de servicii') == -1) {
			var sourceIssue = currentIssue;
			var destinationIssue = relationIssue;
		} else {
			return;
		}


		var watchers = "";
		$.each(sourceIssue.watchers, function (index) {
			watchers = watchers + "&watcher[user_ids][]=" + sourceIssue.watchers[index].id;
			console.log(sourceIssue.watchers[index])
		});
		var watchers_json  = "utf8=✓&object_type=issue&object_id[]=" + destinationIssue.id + "&user_search=" + watchers;
		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/x-www-form-urlencoded",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/watchers",
			dataType: "text/javascript; charset=utf-8",
			data: watchers_json
		}).done(function (data) {
			console.log(data);
		});	
	});



	//--- On DELETE comment ---
	$('#history .journal .icon-del').on('click', function () {
		localStorage.setItem('delete_comment_text', $('#journal-' + $(this).attr('href').split('journals/')[1].split('?')[0] + '-notes p').text());
	});
	localStorage.setItem("comment_count", $('#history .journal').length);
	$('#history').on('DOMSubtreeModified', function () {
		console.log('DOM CHANGE');
		if (localStorage.getItem("comment_count") > $('#history .journal').length) {
			console.log('comment DELETE');
			localStorage.setItem("comment_count", $('#history .journal').length);

			//---------------- Commentul STERS il punem pe toti parintii ----------------------
			var noteToAdd = "[Delete] Comentariul a fost sters de " + localStorage.getItem('logged_user_name') + " : \n " + localStorage.getItem('delete_comment_text');
			commentDeleteOnParent(window.location.href.split('/issues/')[1].split('?')[0].split('#')[0], noteToAdd);
			//================ END Commentul STERS il punem pe toti parintii ==================
		}
	});//--- END On DELETE comment ---



	//------------------------------------ ON SUBMIT ---------------------------------------	
	//$('#main').on('click','input[type=submit]',function(e){
	$('#main').on('click', 'input[type=submit]', function (e) {

		console.log("Va rugam asteptati...");


		//--- On Save - edit comment ---
		if ($('input[name="journal[private_notes]"]').length > 0 && $('textarea[name="journal[notes]"]').length > 0) {
			//---------------- Commentul modificat il punem pe toti parintii ----------------------
			if ($('textarea[name="journal[notes]"]').val() != "" && $('textarea[name="journal[notes]"]').val() != undefined) {
				var noteToAdd = "[Edit] Modificat de " + localStorage.getItem('logged_user_name') + " : \n " + $('textarea[name="journal[notes]"]').val();
				commentEditOnParent(window.location.href.split('/issues/')[1].split('?')[0].split('#')[0], noteToAdd);
			}
			//================ END Commentul modificat il punem pe toti parintii ==================
		} // END On Save - edit comment



		//$('#issue-form').on('submit',function(e){
		//if( $('#update').css('display') == 'block' ) {

		if (
			(window.location.href.indexOf('/issues/new') != -1 || window.location.href.indexOf('/issues/') != -1) &&
			(window.location.href.indexOf('/issues/bulk_edit') == -1) &&
			(
				($(this).attr('name') == 'commit' && $(this).attr('value') == 'Submit') ||
				($(this).attr('name') == 'commit' && $(this).attr('value') == 'Trimite') ||

				($(this).attr('name') == 'commit' && $(this).attr('value') == 'Create') ||
				($(this).attr('name') == 'commit' && $(this).attr('value') == 'Creeaza') ||

				($(this).attr('name') == 'continue' && $(this).attr('value') == 'Create and continue') ||
				($(this).attr('name') == 'continue' && $(this).attr('value') == 'Creeaza si continua')
			)

		) {
			$('body').append("<div class='modal_message_overlay'><div class='modal_message'><img src='" + STS.loadingGif + "'/> Va rugam asteptati, pagina se va reincarca automat...</div></div>");

			e.preventDefault();
			console.log('submit click');


			if( window.location.href.indexOf('/projects/') != -1 ) {
				// new issue from redmine interface
				
				//---- RNCD default asigneed ---
				if( 
					window.location.href.indexOf('/projects/rncd/issues/new') != -1 &&
					(
						$('#issue_parent_issue_id').val() == undefined ||
						$('#issue_parent_issue_id').val() == ''
					)
				) {	
					$('#issue_assigned_to_id').val(2987);
				}

			} else {

				//-------------------------------- ALFRESCO NEW WATCHER FROM ASSIGNED ------------------------------------------
				var optgroup = [];
				var assignedIsGroup = false;
				var assignedUserId = $('#issue_assigned_to_id').val();

				// Redmine 7 pune și utilizatorii în optgroup-uri (Implicați / Utilizatori / Grupuri);
				// grupuri sunt doar opțiunile din optgroup-ul cu eticheta Grupuri
				$('#issue_assigned_to_id optgroup').filter(function(){ return $(this).attr('label') == STS.groupsLabel; }).find('option').each(function(){
					optgroup.push( $(this).val() );
				});
				if( $.inArray($('#issue_assigned_to_id').val(), optgroup) != -1 ) {
					console.log('este grup selectat');
					assignedIsGroup = true;

					//--- Redmine watcher ---
					var urlForWatchersToAdd = "/watchers.json?object_id=" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + "&watcher[user_ids][]="+assignedUserId+"&object_type=issue";	
					$.ajax({
						type: "POST",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						}, 
						url: urlForWatchersToAdd
					}).done(function (data) {
						console.log("Watcher groups added successfully from Assigned");
					});

					//--- Alfresco watcher ---
					var watchersJSON = [];
					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/groups/" + $('#issue_assigned_to_id').val() + ".json?include=users"
					}).done(function (data) {
						console.log(data);
						assignedUserId = [];
						$.each(data.group.users, function (eachIndex) {
							watchersJSON.push(data.group.users[eachIndex].id);
							assignedUserId.push(data.group.users[eachIndex].id);
						});
						console.log(watchersJSON);
					});
					//console.log($(this).val());					


					var new_watchers = [];
					for (i = 0; i <= watchersJSON.length - 1; i++) {

						$.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/users/" + watchersJSON[i] + ".json"
						}).done(function (data) {
							console.log(data.user.login);
							var new_watcher = data.user.login;
							new_watchers.push(new_watcher);			
						}); // get user id for each watcher
					} // for each watcher from group



					// --- alfresco api ---
					// var origin = "https://secretariat.stsnet.ro/";
					var origin = localStorage.getItem('alfresco_origin');
					// var nodeId = "40d5f9bf-d7b9-4952-8899-af3dd731717c";
					var nodeId = localStorage.getItem('alfresco_nodeId');
					var query = "?include=permissions";
					var i;

					if (stsAlfrescoNodeOk(origin, nodeId)) $.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"Authorization": STS.portalAuth
						},
						url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
					}).done(function (data, statusText, xhr) {
						console.log(data);
						console.log(data.entry.permissions.locallySet);
						var locallySetPermissions = data.entry.permissions.locallySet;

						var add_permission = {
							"permissions":
							{
								"isInheritanceEnabled": data.entry.permissions.isInheritanceEnabled,
								"locallySet":
									[
										//{ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" }
									]
							}
						}
						// add existing permissions
						if (locallySetPermissions != undefined) {
							for (i = 0; i <= locallySetPermissions.length - 1; i++) {
								add_permission["permissions"]["locallySet"].push(locallySetPermissions[i]);
							}
						}
						// add new permissions
						for (i = 0; i <= new_watchers.length - 1; i++) {
							if( JSON.stringify(add_permission).indexOf(new_watchers[i]) == -1 ) {
								add_permission["permissions"]["locallySet"].push({ "authorityId": new_watchers[i], "name": "Consumer", "accessStatus": "ALLOWED" })
							}							
						}				
						
						// console.log(add_permission);

						$.ajax({
							type: "PUT",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"Authorization": STS.portalAuth
							},
							data: JSON.stringify(add_permission),
							url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
						}).done(function (data, statusText, xhr) {
							console.log(data);
						});

					}); // alfresco api

					





				} else {
					console.log('este watcher selectat');
					
					//--- Redmine watcher ---
					var watchers_json  = "utf8=✓&object_type=issue&object_id[]="+window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]+"&user_search=&watcher[user_ids][]=" + assignedUserId;
					$.ajax({
						type: "POST",
						async: false,
						headers: {
							"Content-Type": "application/x-www-form-urlencoded",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/watchers",
						dataType: "text/javascript; charset=utf-8",
						data: watchers_json
					}).done(function (data) {
						console.log(data);
					});



					//--- Alfresco watcher ---
					// var new_watcher = $('#issue_assigned_to_id').val();
					// trebuie sa facem request cu email catre alfresco, nu id-ul din redmine

					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/users/" + $('#issue_assigned_to_id').val() + ".json"
					}).done(function (data) {
						console.log(data.user.login);
						var new_watcher = data.user.login;


						// --- alfresco api ---
						// var origin = "https://secretariat.stsnet.ro/";
						var origin = localStorage.getItem('alfresco_origin');
						// var nodeId = "40d5f9bf-d7b9-4952-8899-af3dd731717c";
						var nodeId = localStorage.getItem('alfresco_nodeId');
						var query = "?include=permissions";
						var i;

						if (stsAlfrescoNodeOk(origin, nodeId)) $.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"Authorization": STS.portalAuth
							},
							url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
						}).done(function (data, statusText, xhr) {
							console.log(data);
							console.log(data.entry.permissions.locallySet);
							var locallySetPermissions = data.entry.permissions.locallySet;

							var add_permission = {
								"permissions":
								{
									"isInheritanceEnabled": data.entry.permissions.isInheritanceEnabled,
									"locallySet":
										[
											//{ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" }
										]
								}
							}							
							// add existing permissions
							if (locallySetPermissions != undefined) {
								for (i = 0; i <= locallySetPermissions.length - 1; i++) {
									add_permission["permissions"]["locallySet"].push(locallySetPermissions[i]);
								}
							}
							// add new permissions
							if( JSON.stringify(add_permission).indexOf(new_watcher) == -1 ) {
								add_permission["permissions"]["locallySet"].push({ "authorityId": new_watcher, "name": "Consumer", "accessStatus": "ALLOWED" })
							}	



							//console.log(add_permission);


							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"Authorization": STS.portalAuth
								},
								data: JSON.stringify(add_permission),
								url: origin + "alfresco/api/-default-/public/alfresco/versions/1/nodes/" + nodeId + query
							}).done(function (data, statusText, xhr) {
								console.log(data);
							});

						}); // alfresco api

					});// get watcher email from id

					
					
				}			
				//=========================== END ALFRESCO NEW WATCHER FROM ASSIGNED ============================================





				//------------------------ SUBMIT Repartitie = asignat => parent asignat ----------
				if (
					($('#issue_status_id').val() == 4) &&
					($('#issue_tracker_id').val() == 52) && // daca e repartitie
					($('#issue_assigned_to_id').val() != "") // daca are asignee 
				) {

					$('#issue_status_id').val(5);  // il facem asignat


					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						},
						url: "/issues/" + window.location.href.split('/issues/')[1] + ".json?include=watchers"
					}).done(function (data) {

						/*
						$.ajax({
							type:"PUT",
							async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": "admin"},	// $('#loggedas .user').text()
							url:"/issues/"+ data.issue.parent.id +".json",
							data: JSON.stringify({"issue":{"status_id":"5"}})
						}).done(function(data){
							console.log(data);
							console.log('Statusul pentru: '+ data.issue.parent.id +" a fost schimbat in 5(Assigned)");
						});
						*/

						//--- ^ commented, check if parent is CLOSED first ---
						if( data.issue.parent != undefined ) {					  
							$.ajax({
								type: "GET",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": "admin"
								},
								url: "/issues/" + data.issue.parent.id + ".json"
							}).done(function (data_parent) {
								var closed_statuses = [6, 9, 24, 8, 25, 26, 31, 27, 28, 29, 30, 32, 33, 36, 37, 38, 39];
								if ($.inArray(data_parent.issue.status.id, closed_statuses) != -1) {
									console.log('Parent issue status type = closed, cannot change to assigned');
								} else {
									$.ajax({
										type: "PUT",
										async: false,
										headers: {
											"Content-Type": "application/json",
											"X-Redmine-API-Key": STS.apiKey,
											"X-Redmine-Switch-User": "admin"
										},	// $('#loggedas .user').text()
										url: "/issues/" + data.issue.parent.id + ".json",
										data: JSON.stringify({ "issue": { "status_id": "5" } })
									}).done(function (data) {
										console.log(data);
										console.log('Statusul pentru: ' + data.issue.parent.id + " a fost schimbat in 5(Assigned)");
									});
								}
							});
						}



					});



				} // SUBMIT Repartitie = asignat => parent asignat



				//------------------------ Daca are parinte si e Rezolutie, facem parintele Assigned ----------------------
				if ($('#issue_tracker_id').val() == 6) { // daca e Rezolutie

					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						},
						url: "/issues/" + $('#issue_parent_issue_id').val() + ".json"
					}).done(function (data_parent) {
						var closed_statuses = [6, 9, 24, 8, 25, 26, 31, 27, 28, 29, 30, 32, 33, 36, 37, 38, 39];
						if ($.inArray(data_parent.issue.status.id, closed_statuses) != -1) {
							console.log('Parent issue status type = closed, cannot change to assigned');
						} else {
							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": "admin"
								},	// $('#loggedas .user').text()
								url: "/issues/" + $('#issue_parent_issue_id').val() + ".json",
								data: JSON.stringify({ "issue": { "status_id": "5" } })
							}).done(function (data) {
								console.log(data);
							});
						}
					});



					/* ---- este comentat deoarece la un task nou, nu exista parent id, va exista dupa submit
					$.ajax({
						type:"GET",
						async:false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": $('#loggedas .user').text()},		
						url:"/issues/" + window.location.href.split('/issues/')[1] + ".json?include=watchers"
					}).done(function(data){
						if(
							data.issue.parent.id != ""
						){
							$.ajax({
								type:"PUT",
								async:false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": $('#loggedas .user').text()},	// "admin"
								url:"/issues/"+data.issue.parent.id+".json",
								data: JSON.stringify({ "issue": { "status_id": "5"} })
							}).done(function(data){
								console.log(data);
							});		
						} // if has parent									
					}); // ajax get info
					*/

				} // if rezolutie
				//======================== Daca are parinte si e Repartitie, facem parintele Assigned =======================	




			} // end if( window.location.href.indexOf('/projects/') == -1 )




			
			//--- Redmine watcher for parent and grandparent issues
			var parentIssueId = $('#issue_parent_issue_id').val();
			if (parentIssueId && assignedUserId) {
				addWatcherOnParent(parentIssueId, assignedUserId, assignedIsGroup)
			}










			//----------------- IF solicitare aprobare = aprobat, parent devine OPEN ----------------------	
			if (
				(window.location.href.indexOf('issues') != -1) &&
				($('#content h2').text().indexOf('Solicitare aprobare #') != -1)
			) {
				//------- AICI PARENT open mutat - inainte de sumbit
				$.ajax({
					type: "GET",
					//async:false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					}, // 'admin'
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,children,relations"
				}).done(function (data) {
					if (
						((data.issue.status.id == 24) || ($('#issue_status_id').val() == 24)) && // daca e Aprobat
						(data.issue.assigned_to.id != 324 && data.issue.assigned_to.id != 325 && data.issue.assigned_to.id != 326)
					) {
						console.log('E solicitare aprobare, unitate centrala sau teritoriala');
						//---------------------- VERIFICAM PARINTELE - COPII APROBATI --------------------

						$.ajax({
							type: "GET",
							//async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							}, // $('#loggedas .user').text()	
							url: "/issues/" + data.issue.parent.id + ".json?include=children"
						}).done(function (data) {
							//console.log(data);

							if (data.issue.children.length > 0) {
								var i = 0;
								localStorage.setItem('solicitareAprobare_CopiiAprobati', 0);

								console.log('Avem copii: ' + data.issue.children.length);

								function checkSolicitareAprobLoop() {
									if (i <= data.issue.children.length - 1) {
										$.ajax({
											type: "GET",
											//async:false,
											headers: {
												"Content-Type": "application/json",
												"X-Redmine-API-Key": STS.apiKey,
												"X-Redmine-Switch-User": 'admin'
											}, // $('#loggedas .user').text()
											url: "/issues/" + data.issue.children[i].id + ".json"
										}).done(function (data) {
											//console.log(data);
											if (data.issue.status.id == 24) {  //daca acest copil e Aprobat
												localStorage.setItem('solicitareAprobare_CopiiAprobati', parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')) + 1);
											}
											checkSolicitareAprobLoop();
										});
										i++;
									}

									console.log('Copii aprobati: ' + parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati')));

									if (data.issue.children.length == parseInt(localStorage.getItem('solicitareAprobare_CopiiAprobati'))) { // daca avem toti copiii aprobati									
										console.log('SUNT toti copiii sunt aprobati: ' + data.issue.children.length);

										$.ajax({
											type: "GET",
											async: false,
											headers: {
												"Content-Type": "application/json",
												"X-Redmine-API-Key": STS.apiKey,
												"X-Redmine-Switch-User": 'admin'
											}, // $('#loggedas .user').text()
											url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
										}).done(function (data) {

											//------------ verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN --------
											$.ajax({
												type: "GET",
												async: false,
												headers: {
													"Content-Type": "application/json",
													"X-Redmine-API-Key": STS.apiKey,
													"X-Redmine-Switch-User": 'admin'
												}, // $('#loggedas .user').text()
												url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
											}).done(function (data) {
												if (data.issue.tracker.id == 49) { // daca e solicitare aprobare parintele													
													if (data.issue.status.id != 24 && data.issue.status.id != 26 && data.issue.status.id != 27) { // daca nu e aprobat/anulat
														$.ajax({
															type: "PUT",
															async: false,
															headers: {
																"Content-Type": "application/json",
																"X-Redmine-API-Key": STS.apiKey,
																"X-Redmine-Switch-User": 'admin'
															}, //------PROBLEMA OPEN APROBARE change admin si punem numele: {"issue":{"notes": noteToAdd }}
															url: "/issues/" + data.issue.id + ".json",
															data: JSON.stringify({ "issue": { "status_id": "1" } }) // il facem OPEN daca are toti copiii aprobati
														}).done(function (data) {
															console.log(data);
														}); // ajax il facem OPEN
													}
												} // ---- verificam daca parintele este solicitare aprobare, DOAR atunci il facem OPEN 
											});




										}); // ajax get

									}


								}
								checkSolicitareAprobLoop();


							} // daca are copii parintele
						}); //---------------------- ajax done VERIFICAM PARINTELE - COPII APROBATI --------------------
					} // daca nu e conducere si e APROBAT

				});	//-------------- FINAL verificare aprobat -----------------



				//------------------------ SUBMIT solicitare aprobare = aprobat => parent open ----------
				$.ajax({
					type: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": "admin"
					},
					url: "/issue_statuses.json"
				}).done(function (data) {
					var i;
					var issueStatusClosed = [];
					for (i = 0; i <= data.issue_statuses.length - 1; i++) {
						if (data.issue_statuses[i].is_closed == true) {
							issueStatusClosed.push(data.issue_statuses[i].id);
						}
					}


					if (
						//$('#issue_status_id').val() == 24 &&
						(issueStatusClosed.indexOf(parseInt($('#issue_status_id').val())) != -1) &&
						($('#issue_assigned_to_id').val() == 324 || $('#issue_assigned_to_id').val() == 325 || $('#issue_assigned_to_id').val() == 326)
					) {

						$.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": $('#loggedas .user').text()
							},
							url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
						}).done(function (data) {
							console.log(data);
							console.log('Parent pentru issue: ' + data.issue.parent.id);

							$.ajax({
								type: "GET",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": $('#loggedas .user').text()
								},
								url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
							}).done(function (dataParent) {
								if (dataParent.issue.status.id != 24 && dataParent.issue.status.id != 26 && dataParent.issue.status.id != 27) { // daca nu e aprobat/anulat
									$.ajax({
										type: "PUT",
										async: false,
										headers: {
											"Content-Type": "application/json",
											"X-Redmine-API-Key": STS.apiKey,
											"X-Redmine-Switch-User": "admin"
										},	// $('#loggedas .user').text()
										url: "/issues/" + data.issue.parent.id + ".json",
										data: JSON.stringify({ "issue": { "status_id": "1" } })
									}).done(function (data) {
										console.log(data);
										console.log('Statusul pentru: ' + data.issue.parent.id + " a fost schimbat in 1(open)");
									}); // update status parinte open daca avem copiii aprobati
								}
							});


						});

					} // IF  solicitare aprobare = aprobat => parent open

				}); // GET ISSUE STATUS CLOSED CHECKED



				//---------------------- DACA este 49 (Solicitare aprobare) si il aprobam/anulam, asignee devine userul <<me>>  ------------------			
				if (
					$('#issue_status_id').val() == 24 ||  // Daca e Aprobat
					$('#issue_status_id').val() == 26 ||  // Daca e Aprobat cu observatii
					$('#issue_status_id').val() == 27     // Daca e Anulat
				) {
					$('#issue_assigned_to_id option:eq(1)').attr('selected', 'selected');  // asignee << me >>
				}


			} // IF solicitare aprobare







			/*---------------- Commentul adaugat il punem pe toti parintii ----------------------*/
			if( $('#issue_notes').length > 0 ) {
				if ($('#issue_notes').val() != "" && $('#issue_notes').val() != undefined) {
					var issueID = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];
					var noteToAdd = "Actualizat de " + localStorage.getItem('logged_user_name') + " : \n " + $('#issue_notes').val();
					commentOnParent(issueID, noteToAdd);
				} 
			}
			
			if( $('.subject').length > 0 ) {
				if( $('.subject').html().indexOf('Document electronic #') != -1 ) {
					var issueID = window.location.href.split('/issues/')[1].split('?')[0].split('#')[0];
					var projectName = $('#issue_project_id option:selected').html() ? " din " + $('#issue_project_id option:selected').html().replace(/&nbsp;/g,'') : "";
					var noteToAdd = "Utilizatorul " + localStorage.getItem('logged_user_name') + projectName + " a asignat rezolutia " + issueID + " catre " + $('#issue_assigned_to_id option:selected').text() + " cu subiectul " + $('#issue_subject').val();
					commentOnParent(issueID, noteToAdd);
				}
			}			
			/*================ END Commentul adaugat il punem pe toti parintii ==================*/



			




			//$('#issue-form').submit();

			//$(document).bind('ajaxStop', function() {
			setTimeout(function () {
				$('#issue-form').submit();
			}, 2000);
			//});			


		} // /issues/








	}); // $('#issue-form').submit(); LA SUBMIT


	//=========================== END ADAUGA SOLICITARI APROBARE ============================================
	//========================================================================================================
	//========================================================================================================

































	//-------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------------------------------------------
	//------------------------- 1. ADAUGA Repartitie DJTS JUDET - Petitie 112 ------------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		(($('#content h2').text().indexOf('Petitie 112 #') != -1))
	) {

		$('#buttonNewRepartForPetitieDJTS').show();
		$('#buttonNewRepartForPetitieDJTS').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitiePetitie112_DJTS').show();
		});

		$('#newPOPUP_close_adaugaRepartitiePetitie112_DJTS').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitiePetitie112_DJTS').hide();
		});

		$('#newPOPUP_cauta_adaugaRepartitiePetitie112_DJTS').on('keyup', function () {
			if ($('#newPOPUP_cauta_adaugaRepartitiePetitie112_DJTS').val() == '') {
				$('.newPOPUP_row').show();
			} else {
				$('.newPOPUP_row').each(function () {
					if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_adaugaRepartitiePetitie112_DJTS').val().toLowerCase()) == -1) {
						$(this).hide();
					} else {
						$(this).show();
					}
				});
			}
		});

		$('#newPOPUP_alege_adaugaRepartitiePetitie112_DJTS').on('click', function () {
			var unitatiAprobareAlese = [];

			if ($('#newPOPUP_overlay_adaugaRepartitiePetitie112_DJTS .newPOPUP_row input:checkbox:checked').length > 0) {

				$('#newPOPUP_overlay_adaugaRepartitiePetitie112_DJTS .newPOPUP_row input:checkbox:checked').each(function (index) {
					unitatiAprobareAlese[index] = {
						"intro": $(this).attr('data-intro'),
						"id": $(this).attr('data-id'),
						"project_id": $(this).attr('data-intro').split('Sefului unitatii ')[1].split(' va rog')[0]
					}
				});
				newRepartitieIfPetitie112(JSON.stringify(unitatiAprobareAlese), 1);
			} // if checked > 0
		}); // on click ALEGE

	}


	//-------------------------------------------------------------------------------------------------------------------------------
	//-------------------------------------------------------------------------------------------------------------------------------
	//------------------------- 2. ADAUGA Repartitie daca Rezolutie/Repartie cu parinte Petitie 112 ------------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		(($('#content h2').text().indexOf('Rezolutie #') != -1) || ($('#content h2').text().indexOf('Repartitie #') != -1)) /*&&
		  ( $('.current-project').text() == 'DMS - STS' ) */
	) {

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {
			//console.log(data.issue.parent.id);

			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": $('#loggedas .user').text()
				},
				url: "/issues/" + data.issue.parent.id + ".json?include=watchers"
			}).done(function (data) {
				//console.log(data.issue.tracker.id);]
				if (data.issue.tracker.id == 59) {
					$('#buttonNewRepartIfParentPetitie112').show();
					$('#buttonNewRepartIfParentPetitie112').on('click', function () {
						$('#newPOPUP_overlay_adaugaRepartitie_ifParentPetitie112').show();
					});

					$('#newPOPUP_close_adaugaRepartitie_ifParentPetitie112').on('click', function () {
						$('#newPOPUP_overlay_adaugaRepartitie_ifParentPetitie112').hide();
					});

					$('#newPOPUP_cauta_adaugaRepartitie_ifParentPetitie112').on('keyup', function () {
						if ($('#newPOPUP_cauta_adaugaRepartitie_ifParentPetitie112').val() == '') {
							$('.newPOPUP_row').show();
						} else {
							$('.newPOPUP_row').each(function () {
								if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_adaugaRepartitie_ifParentPetitie112').val().toLowerCase()) == -1) {
									$(this).hide();
								} else {
									$(this).show();
								}
							});
						}
					});

					$('#newPOPUP_alege_adaugaRepartitie_ifParentPetitie112').on('click', function () {
						var unitatiAprobareAlese = [];

						if ($('#newPOPUP_overlay_adaugaRepartitie_ifParentPetitie112 .newPOPUP_row input:checkbox:checked').length > 0) {

							$('#newPOPUP_overlay_adaugaRepartitie_ifParentPetitie112 .newPOPUP_row input:checkbox:checked').each(function (index) {
								unitatiAprobareAlese[index] = {
									"intro": $(this).attr('data-intro'),
									"id": $(this).attr('data-id'),
									"project_id": $(this).attr('data-intro').split('Sefului unitatii ')[1].split(' va rog')[0]
								}
							});
							newRepartitieIfPetitie112(JSON.stringify(unitatiAprobareAlese), 1);
						} // if checked > 0
					}); // on click ALEGE
				}
			});

		}); // vedem daca parintele e Petitie 112 = id 59



	} // ADAUGA Repartitie daca Rezolutie/Repartie cu parinte Petitie 112







	//--------------------------------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------------------
	//------------------------- 3. ADAUGA Repartitie daca este Petitie 112 ------------------------------------
	if (
		(window.location.href.indexOf('issues') != -1) &&
		(($('#content h2').text().indexOf('Petitie 112 #') != -1)) &&
		($('.current-project').text() == 'DMS - STS')
	) {

		$('#buttonNewRepartIfPetitie112').show();


		$('#buttonNewRepartIfPetitie112').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitie_ifPetitie').show();
		});

		$('#newPOPUP_close_adaugaRepartitie_ifPetitie').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitie_ifPetitie').hide();
		});

		$('#newPOPUP_cauta_adaugaRepartitie_ifPetitie').on('keyup', function () {
			if ($('#newPOPUP_cauta_adaugaRepartitie_ifPetitie').val() == '') {
				$('.newPOPUP_row').show();
			} else {
				$('.newPOPUP_row').each(function () {
					if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_adaugaRepartitie_ifPetitie').val().toLowerCase()) == -1) {
						$(this).hide();
					} else {
						$(this).show();
					}
				});
			}
		});

		$('#newPOPUP_alege_adaugaRepartitie_ifPetitie').on('click', function () {
			var unitatiAprobareAlese = [];

			if ($('#newPOPUP_overlay_adaugaRepartitie_ifPetitie .newPOPUP_row input:checkbox:checked').length > 0) {

				$('#newPOPUP_overlay_adaugaRepartitie_ifPetitie .newPOPUP_row input:checkbox:checked').each(function (index) {
					unitatiAprobareAlese[index] = {
						"intro": $(this).attr('data-intro'),
						"id": $(this).attr('data-id'),
						"project_id": $(this).attr('data-intro').split('Sefului unitatii ')[1].split(' va rog')[0]
					}
				});
				newRepartitieIfPetitie112(JSON.stringify(unitatiAprobareAlese), 0);
			} // if checked > 0
		}); // on click ALEGE


	}





	//--------------------------------------------------------------------------------------------------------
	//--------------------------------------------------------------------------------------------------------
	//------------------------- 4. ADAUGA Repartitie daca Cerere de servicii ------------------------------------

	var lista_servicii_repartitie = [
		{
			id: "0",
			tip_serviciu: "Realizarea de retele securizate de telecomunicatii speciale de date de tip intranet",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "VPN criptat",
					unitati: ["DCAOSR", "DCPD", "DESA", "DESR"]
				},
				{
					id: "1",
					serviciu: "VPN L2 - L3",
					unitati: ["DCAOSR", "DCPD", "DESA", "DESR"]
				}
			]
		},
		{
			id: "1",
			tip_serviciu: "Servicii de acces la internet si serviciile asociate accesului la internet",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Acces internet",
					unitati: ["DSCSTI"]
				},
				{
					id: "1",
					serviciu: "Gazduire",
					unitati: ["DSCSTI"]
				}
			]
		},
		{
			id: "2",
			tip_serviciu: "Servicii de tip CERT prin CORIS-STS-CERT",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Audit de securitate si raspuns la incidente de securitate cibernetica CERT (CORIS-STS)",
					unitati: ["DSCSTI"]
				},
				{
					id: "1",
					serviciu: "Dezvoltare instrumente de securitate",
					unitati: ["DSCSTI"]
				}
			]
		},
		{
			id: "3",
			tip_serviciu: "Servicii de radiocomunicatii mobile si fixe, analogice si digitale, de banda ingusta si de banda larga in retelele administrate de serviciul de telecomunicati speciale",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Servicii de comunicatii satelitare la nivelul HUB VSAT",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				},
				{
					id: "1",
					serviciu: "Servicii de transport radioreleu",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				},
				{
					id: "2",
					serviciu: "Servicii pe sportul retelelor de date (ATM, Ethernet MPLS)",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				},
				{
					id: "3",
					serviciu: "Servicii pe suport FO la nivelul echipamentelor de multiplexare DWDM",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				},
				{
					id: "4",
					serviciu: "Servicii pe suportul retelelor de radiocomunicatii de banda larga (WiMAX, LMDS) si de banda ingusta (TETRA)",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				},
				{
					id: "5",
					serviciu: "Servicii de comunicatii pe US (VHF- UHF)",
					unitati: ["DESR", "DCPD", "DCAOSR"]
				}
			]
		},
		{
			id: "4",
			tip_serviciu: "Servicii de comunictii speciale de voce si video",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Videoconferinta VTO-VTCS",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "1",
					serviciu: "Acces in retelele telefonice S, TO, IC si de institutie",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "2",
					serviciu: "Aplicatii pe TETRA",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "3",
					serviciu: "Asistenta pe retele de cabluri de CU si FO (magistrale si de distributie)",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "4",
					serviciu: "Implementare retele locale de comunicatii",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "5",
					serviciu: "Instalare echipamente terminale",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "6",
					serviciu: "Proiectare retele locale de comunicatii",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "7",
					serviciu: "Servicii de instalare si operationalizare echipamente in reteaua TETRA",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "8",
					serviciu: "Servicii de voce - date in retelele de comunicatii satelitare",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "9",
					serviciu: "Transport voce-date in tehnologie PDH, SDH, ethernet",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "10",
					serviciu: "Asistenta tehnica la beneficiari",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				}
			]
		},
		{
			id: "5",
			tip_serviciu: "Servicii IPTV",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Servicii IPTV",
					unitati: ["DESA"]
				}
			]
		},
		{
			id: "6",
			tip_serviciu: "Servicii de gazduire",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Gazduire echipamente si furnizare de servicii",
					unitati: ["DCDSSI", "DESA", "DSCSTI", "DCAOSR"]
				},
				{
					id: "1",
					serviciu: "Gazduire pe echipamente STS",
					unitati: ["DCDSSI", "DESA", "DSCSTI", "DCAOSR"]
				},
				{
					id: "2",
					serviciu: "Gazduire pe Platforma de Virtualizare",
					unitati: ["DCDSSI", "DESA", "DSCSTI", "DCAOSR"]
				}
			]
		},
		{
			id: "7",
			tip_serviciu: "Serviciul de transmitere de date prin mesaje text prin intermediul serviciului de mesaje scurte si SMS",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Infrastructura  SMSC",
					unitati: ["DCDSSI", "DCAOSR"]
				}
			]
		},
		{
			id: "8",
			tip_serviciu: "Servicii de tip pki (semnatura digitala)",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Generare certificate digitale",
					unitati: ["DSCSTI"]
				},
				{
					id: "1",
					serviciu: "Servicii de validare certificate digitale",
					unitati: ["DSCSTI"]
				},
				{
					id: "2",
					serviciu: "Servicii Time Stamp",
					unitati: ["DSCSTI"]
				}
			]
		},
		{
			id: "9",
			tip_serviciu: "Servicii de comunicatii de date cu acces din retelele operatorilor de telefonie mobila",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Accesul la resurse private prin infrastructura Operatorilor de Telefonie Mobila prin APN",
					unitati: ["DESA", "DCAOSR"]
				}
			]
		},
		{
			id: "10",
			tip_serviciu: "Servicii de acces in reteaua de tip extranet",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Extranet",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "1",
					serviciu: "Configurare acces la resurse din extranet DRPCIV",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "2",
					serviciu: "Configurare acces la resurse din extranet PATRIMVEN",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "3",
					serviciu: "Configurare acces la resurse din extranet SNEP",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "4",
					serviciu: "Configurare acces la resurse din extranet SPV",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				},
				{
					id: "5",
					serviciu: "Configurare acces la resurse din extranet ETERA",
					unitati: ["DESA", "DCPD", "DCAOSR"]
				}
			]
		},
		{
			id: "11",
			tip_serviciu: "Servicii de securitate a comunicatiilor.",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Evaluare TEMPEST EMI a echipamentelor si zonare TEMPEST; Control tehnic antiinterceptare",
					unitati: ["DSCSTI"]
				},
				{
					id: "1",
					serviciu: "Monitorizare radio si goniometrie fixa si mobila",
					unitati: ["DSCSTI"]
				},
				{
					id: "2",
					serviciu: "SMEC",
					unitati: ["DSCSTI", "DCPD", "DESA", "DCAOSR"]
				}
			]
		},
		{
			id: "12",
			tip_serviciu: "Servicii de asistenta tehnica, consultanta tehnica si implementare de proiecte de tehnologia informatiei si a comunicatiilor",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Servicii de expertiza tehnica",
					unitati: ["DCDSSI"]
				},
				{
					id: "1",
					serviciu: "Suport tehnic pentru administrarea anumitor sisteme informatice",
					unitati: ["DCDSSI", "DCAOSR"]
				},
				{
					id: "2",
					serviciu: "Instalare si Configurare Servicii Informatice",
					unitati: ["DCDSSI", "DESA", "DSCSTI", "DCAOSR"]
				},
				{
					id: "3",
					serviciu: "Asistenta tehnica in caz de incidente sisteme informatice",
					unitati: ["DCDSSI"]
				},
				{
					id: "4",
					serviciu: "Dezvoltare solutii IT",
					unitati: ["DTI"]
				},
				{
					id: "5",
					serviciu: "Dezvoltare Aplicatii pentru beneficiarii externi",
					unitati: ["DCPD"]
				}
			]
		},
		{
			id: "13",
			tip_serviciu: "Altele",
			serviciu_furnizat: [
				{
					id: "0",
					serviciu: "Altele",
					unitati: ["Altele"]
				}
			]
		}
	];

	if ($('.newPOPUP_categoryRow_unitati_centrale')[1] != undefined) {
		$('.newPOPUP_categoryRow_unitati_centrale')[1].remove();
	}

	var i, j;
	$('#tip_serviciu_cere_servicii').append("<option disabled selected>Tip serviciu</option>");

	//------------ ADD OPTION SELECT TIP SERVICIU -------------
	for (i = 0; i <= lista_servicii_repartitie.length - 1; i++) {
		$('#tip_serviciu_cere_servicii').append(
			"<option value='" + lista_servicii_repartitie[i].id + "' >" +
			lista_servicii_repartitie[i].tip_serviciu +
			"</option>"
		);
	}

	//------------- SELECT TIP SERVICIU ----------------------
	$('.newPOPUP').on('change', '#tip_serviciu_cere_servicii', function () {
		$('.newPOPUP_row input:checkbox').prop('checked', false);
		$('#serviciu_furnizat_cere_servicii option').remove();
		$('#serviciu_furnizat_cere_servicii').append("<option disabled selected>Serviciu furnizat</option>");
		$('.newPOPUP_categoryRow_unitati_centrale .newPOPUP_row input').removeAttr('unitate_pricipala');

		for (j = 0; j <= lista_servicii_repartitie[$('#tip_serviciu_cere_servicii').val()].serviciu_furnizat.length - 1; j++) {
			$('#serviciu_furnizat_cere_servicii').append(
				"<option value='" + lista_servicii_repartitie[$('#tip_serviciu_cere_servicii').val()].serviciu_furnizat[j].id + "' >" +
				lista_servicii_repartitie[$('#tip_serviciu_cere_servicii').val()].serviciu_furnizat[j].serviciu +
				"</option>"
			);
		}
	});

	//---------------- SELECT SERVICIU FURNIZAT -----------------
	$('.newPOPUP').on('change', '#serviciu_furnizat_cere_servicii', function () {
		$('.newPOPUP_row input:checkbox').prop('checked', false);
		var unitati_serviciu = lista_servicii_repartitie[$('#tip_serviciu_cere_servicii').val()].serviciu_furnizat[$('#serviciu_furnizat_cere_servicii').val()].unitati;
		$('.newPOPUP_categoryRow_unitati_centrale .newPOPUP_row input').removeAttr('unitate_pricipala');

		for (i = 0; i <= unitati_serviciu.length - 1; i++) {

			$('.newPOPUP_categoryRow_unitati_centrale .newPOPUP_row').each(function () {
				var denumire = $.trim($(this).text());
				if (denumire == unitati_serviciu[i] + " - Conducere") {
					$(this).children().prop('checked', true);
					console.log(denumire + " MATCH");
					if (i == 0) { $(this).children().attr('data-unitatepricipala', '1'); } else { $(this).children().attr('data-unitatepricipala', '0'); }
					$(this).children().attr('data-unitate', unitati_serviciu[i]);
				}
			});


		}

	});







	if (
		(window.location.href.indexOf('issues') != -1) &&
		(($('#content h2').text().indexOf('Cerere de servicii #') != -1)) &&
		($('.current-project').text() == 'DMS - STS')
	) {

		$('#buttonNewRepartIfCerereServicii').show();


		$('#buttonNewRepartIfCerereServicii').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitie_ifCerereServicii').show();
		});

		$('#newPOPUP_close_adaugaRepartitie_ifCerereServicii').on('click', function () {
			$('#newPOPUP_overlay_adaugaRepartitie_ifCerereServicii').hide();
		});

		$('#newPOPUP_cauta_adaugaRepartitie_ifCerereServicii').on('keyup', function () {
			if ($('#newPOPUP_cauta_adaugaRepartitie_ifCerereServicii').val() == '') {
				$('.newPOPUP_row').show();
			} else {
				$('.newPOPUP_row').each(function () {
					if ($(this).html().toLowerCase().indexOf($('#newPOPUP_cauta_adaugaRepartitie_ifCerereServicii').val().toLowerCase()) == -1) {
						$(this).hide();
					} else {
						$(this).show();
					}
				});
			}
		});

		$('#newPOPUP_alege_adaugaRepartitie_ifCerereServicii').on('click', function () {
			if ($('#serviciu_furnizat_cere_servicii').val() != undefined || 1) {
				var unitatiAprobareAlese = [];

				if ($('#newPOPUP_overlay_adaugaRepartitie_ifCerereServicii .newPOPUP_row input:checkbox:checked').length > 0) {

					var noteToAdd_cerere = "Au fost aduagate repartii pentru urmatoarele unitati: ";

					$('#newPOPUP_overlay_adaugaRepartitie_ifCerereServicii .newPOPUP_row input:checkbox:checked').each(function (index) {

						//---------- ADD PRINCIPALA SECUNDARA to description -----------
						var unitate_pricipala = $(this).data('unitatepricipala');
						if (unitate_pricipala == 1) {
							var unitate_pricipala_text = $(this).data('unitate') + " Unitate Principala ";
						} else {
							var unitate_pricipala_text = $(this).data('unitate') + " Unitate Secundara ";
						}

						//--------- CREATE NOTE to cerere de servicii --------------
						noteToAdd_cerere = noteToAdd_cerere + unitate_pricipala_text + " | ";

						unitatiAprobareAlese[index] = {
							"intro": $(this).attr('data-intro'),
							"id": $(this).attr('data-id'),
							"group_id": $(this).attr('data-groupid'),
							"project_id": $(this).attr('data-intro').split('Sefului unitatii ')[1].split(' va rog')[0]/*,
							"description": unitate_pricipala_text + ": " + $('#tip_serviciu_cere_servicii option:selected').text() + " - " + $('#serviciu_furnizat_cere_servicii option:selected').text()*/

						}
					});

					//----------------------- ADAUGA Watcher Groups - unitati alese - pe parinte --------------------
					var urlForWatchersToAdd = "/watchers.json?object_id=" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + "&object_type=issue";
					// add STS - MD default
					urlForWatchersToAdd = urlForWatchersToAdd.concat("&watcher[user_ids][]=327");
					$.each(unitatiAprobareAlese, function (index, value) {
						urlForWatchersToAdd = urlForWatchersToAdd.concat("&watcher[user_ids][]=" + unitatiAprobareAlese[index].group_id);
					});

					console.log(urlForWatchersToAdd);
					console.log("---------------- ^^ -----------------");

					$.ajax({
						type: "POST",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": "admin"
						},
						url: urlForWatchersToAdd
					}).done(function (data) {
						console.log("newSolicitariAprobare2() - Watcher groups added successfully");
					});

					//--------- ADD NOTE to cerere de servicii --------------
					/*$.ajax({
						type:"PUT",
						async:false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'},		
						url:"/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?",
						data: JSON.stringify( {"issue":{"notes": noteToAdd_cerere }})
					}).done(function(data){
						console.log(data);
					});*/

					//--------- NEW > Assigned - cerere de servicii --------------
					var currentIssue = JSON.parse(localStorage.getItem('currentIssue'));
					if( currentIssue.issue.status.id == 4 ) {
						$.ajax({
							type:"PUT", 
							// async:false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'},
							url:"/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?",
							data: JSON.stringify({ "issue": { "status_id": "5" } })
						}).done(function(data){
							console.log(data);
						});
					}

					newRepartitieIfCerereServicii(JSON.stringify(unitatiAprobareAlese));
				} // if checked > 0
			} else {
				alert("Alegeti Tip Serviciu si Serviciu Furnizat!");
			}

		}); // on click ALEGE


	}





	function newRepartitieSubtask(assignedToUpdate, parentProjectId, newProjectId, parentSubject, parentAssignedId, newAssignedId, parentIssueId, statusID, customFields, description) {
		var newIssue =
		{
			"issue":
			{
				"project_id": parentProjectId,//project_id
				"tracker_id": 52, // repartitie , rezolutie = 6
				"status_id": statusID, // NEW
				"priority_id": 2, // normala
				"subject": parentSubject,
				"assigned_to_id": parentAssignedId,
				"parent_issue_id": parentIssueId, //window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]
				"watcher_user_ids": JSON.parse(localStorage.getItem('currentIssueWatchers')),
				"custom_fields": customFields,
				"description": description
			}
		}

		$.ajax({
			type: "POST",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/issues.json",
			data: JSON.stringify(newIssue)
		}).done(function (data) {
			console.log("POST new subtask issue");
			console.log(data);

			localStorage.setItem('newRepartie_parentProjectId', data.issue.project.id);
			localStorage.setItem('newRepartie_parentAssignedId', data.issue.assigned_to.id);
			localStorage.setItem('newRepartie_parentIssueId', data.issue.id);

			$.ajax({
				type: "PUT",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": "admin"
				},
				url: "/issues/" + data.issue.id + ".json",
				data: JSON.stringify({ "issue": { "assigned_to_id": assignedToUpdate, "project_id": newProjectId } })
			}).done(function (data) {
				console.log("PUT update la project_id CONDUCERE 822 si " + assignedToUpdate);
				console.log(data);
			});

			if (newAssignedId != 0) {
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": "admin"
					},
					url: "/issues/" + data.issue.id + ".json",
					data: JSON.stringify({ "issue": { "assigned_to_id": newAssignedId } })
				}).done(function (data) {
					console.log("PUT update la noul asignee " + newAssignedId);
					console.log(data);
				});
			}

		});

	} //newRepartieiSubtask()




	function newRepartitieIfCerereServicii(jsonStringAlese) {

		var unitatiAprobareAlese = JSON.parse(jsonStringAlese);
		//----------------------- GET info despre issue parinte --------------------
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {
			console.log("GET info despre issue parinte");
			console.log(data);

			var customFields = data.issue.custom_fields;
			for (i = 0; i <= customFields.length - 1; i++) {
				delete customFields[i].name;
			}


			/*---------------------- WATCHER LOCKED -------------------------*/
			var users_locked = [];
			var j = 0;
			for (i = 0; i <= $('.watchers li').length - 1; i++) {
				if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
					users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
				}
				if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
					users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
				}
			}

			var watchersJSON = [];
			for (i = 0; i <= data.issue.watchers.length - 1; i++) {
				//watchersJSON.push( (data.issue.watchers[i].id).toString() );
				if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
					watchersJSON.push((data.issue.watchers[i].id).toString());
				} else {
					console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
				}
			}

			/*--------- REMOVE WATCHERS DUPLICATES ---------*/
			var unique_watchersJSON = [];

			$.each(watchersJSON, function (i, el) {
				if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
			});
			watchersJSON = unique_watchersJSON
			console.log(watchersJSON);
			/*======= END REMOVE WATCHERS DUPLICATES ========*/

			localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));


			for (i = 0; i <= unitatiAprobareAlese.length - 1; i++) {

				//newRepartitieSubtask(assignedToUpdate, parentProjectId, newProjectId, parentSubject, parentAssignedId, newAssignedId, parentIssueId, statusID, customFields)

				newRepartitieSubtask(
					unitatiAprobareAlese[i].id, //assignedToUpdate
					data.issue.project.id, //parentProjectId
					data.issue.project.id, //newProjectId
					data.issue.subject, //parentSubject
					data.issue.assigned_to.id, // parentAssignedId
					0, // newAssignedId
					data.issue.id, //parentIssueId
					"4", //statusID
					customFields,
					unitatiAprobareAlese[i].description
				);

				console.log('---------------');
				console.log(unitatiAprobareAlese[i].intro);
			}

			$(document).bind('ajaxStop', function () {
				setTimeout(function () {
					window.location.reload();
				}, 500);

			});

		});
	} // newRepartitieIfCerereServicii()





	function newRepartitieIfPetitie112(jsonStringAlese, changeNewAssignee) {

		var unitatiAprobareAlese = JSON.parse(jsonStringAlese);
		//----------------------- GET info despre issue parinte --------------------
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": "admin"
			},
			url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers"
		}).done(function (data) {

			var customFields = data.issue.custom_fields;
			for (i = 0; i <= customFields.length - 1; i++) {
				delete customFields[i].name;
			}

			var directii_json = {
				"CM": 222,
				"CPP": 513,
				"DAP": 221,
				"DCAOSR": 217,
				"DCDSSI": 218,
				"DCPD": 211,
				"DCRB": 223,
				"DCRE": 229,
				"DEFC": 219,
				"DESA": 215,
				"DESR": 216,
				"DJSG": 230,
				"DJTS ALBA": 228,
				"DJTS ARAD": 471,
				"DJTS ARGES": 472,
				"DJTS BACAU": 473,
				"DJTS BIHOR": 474,
				"DJTS BISTRITA-NASAUD": 475,
				"DJTS BOTOSANI": 476,
				"DJTS BRAILA": 478,
				"DJTS BRASOV": 477,
				"DJTS BUZAU": 481,
				"DJTS CALARASI": 483,
				"DJTS CARAS-SEVERIN": 482,
				"DJTS CLUJ": 484,
				"DJTS CONSTANTA": 485,
				"DJTS COVASNA": 486,
				"DJTS DAMBOVITA": 487,
				"DJTS DOLJ": 488,
				"DJTS GALATI": 489,
				"DJTS GIURGIU": 490,
				"DJTS GORJ": 511,
				"DJTS HARGHITA": 491,
				"DJTS HUNEDOARA": 492,
				"DJTS IALOMITA": 493,
				"DJTS IASI": 494,
				"DJTS MARAMURES": 495,
				"DJTS MEHEDINTI": 496,
				"DJTS MURES": 497,
				"DJTS NEAMT": 498,
				"DJTS OLT": 499,
				"DJTS PRAHOVA": 500,
				"DJTS SALAJ": 502,
				"DJTS SATU MARE": 501,
				"DJTS SIBIU": 504,
				"DJTS SUCEAVA": 505,
				"DJTS TELEORMAN": 507,
				"DJTS TIMIS": 503,
				"DJTS TULCEA": 506,
				"DJTS VALCEA": 509,
				"DJTS VASLUI": 508,
				"DJTS VRANCEA": 510,

				/*"DJTS ALBA - Petitie 112": 1767,
				"DJTS ARAD - Petitie 112": 1768,
				"DJTS ARGES - Petitie 112": 1769,
				"DJTS BACAU - Petitie 112": 1770,
				"DJTS BIHOR - Petitie 112": 1771,
				"DJTS BISTRITA-NASAUD - Petitie 112": 1772,
				"DJTS BOTOSANI - Petitie 112": 1773,
				"DJTS BRAILA - Petitie 112": 1774,
				"DJTS BRASOV - Petitie 112": 1775,
				"DJTS BUZAU - Petitie 112": 1776,
				"DJTS CALARASI - Petitie 112": 1777,
				"DJTS CARAS-SEVERIN - Petitie 112": 1778,
				"DJTS CLUJ - Petitie 112": 1779,
				"DJTS CONSTANTA - Petitie 112": 1780,
				"DJTS COVASNA - Petitie 112": 1781,
				"DJTS DAMBOVITA - Petitie 112": 1782,
				"DJTS DOLJ - Petitie 112": 1783,
				"DJTS GALATI - Petitie 112": 1784,
				"DJTS GIURGIU - Petitie 112": 1785,
				"DJTS GORJ - Petitie 112": 1786,
				"DJTS HARGHITA - Petitie 112": 1787,
				"DJTS HUNEDOARA - Petitie 112": 1788,
				"DJTS IALOMITA - Petitie 112": 1789,
				"DJTS IASI - Petitie 112": 1790,
				"DJTS MARAMURES - Petitie 112": 1791,
				"DJTS MEHEDINTI - Petitie 112": 1792,
				"DJTS MURES - Petitie 112": 1793,
				"DJTS NEAMT - Petitie 112": 1794,
				"DJTS OLT - Petitie 112": 1795,
				"DJTS PRAHOVA - Petitie 112": 1796,
				"DJTS SALAJ - Petitie 112": 1797,
				"DJTS SATU MARE - Petitie 112": 1798,
				"DJTS SIBIU - Petitie 112": 1799,
				"DJTS SUCEAVA - Petitie 112": 1800,
				"DJTS TELEORMAN - Petitie 112": 1801,
				"DJTS TIMIS - Petitie 112": 1802,
				"DJTS TULCEA - Petitie 112": 1803,
				"DJTS VALCEA - Petitie 112": 1804,
				"DJTS VASLUI - Petitie 112": 1805,
				"DJTS VRANCEA - Petitie 112": 1806,*/

				"DJTS ALBA - Petitie 112": 228,
				"DJTS ARAD - Petitie 112": 471,
				"DJTS ARGES - Petitie 112": 472,
				"DJTS BACAU - Petitie 112": 473,
				"DJTS BIHOR - Petitie 112": 474,
				"DJTS BISTRITA-NASAUD - Petitie 112": 475,
				"DJTS BOTOSANI - Petitie 112": 476,
				"DJTS BRAILA - Petitie 112": 478,
				"DJTS BRASOV - Petitie 112": 477,
				"DJTS BUZAU - Petitie 112": 481,
				"DJTS CALARASI - Petitie 112": 483,
				"DJTS CARAS-SEVERIN - Petitie 112": 482,
				"DJTS CLUJ - Petitie 112": 484,
				"DJTS CONSTANTA - Petitie 112": 485,
				"DJTS COVASNA - Petitie 112": 486,
				"DJTS DAMBOVITA - Petitie 112": 487,
				"DJTS DOLJ - Petitie 112": 488,
				"DJTS GALATI - Petitie 112": 489,
				"DJTS GIURGIU - Petitie 112": 490,
				"DJTS GORJ - Petitie 112": 511,
				"DJTS HARGHITA - Petitie 112": 491,
				"DJTS HUNEDOARA - Petitie 112": 492,
				"DJTS IALOMITA - Petitie 112": 493,
				"DJTS IASI - Petitie 112": 494,
				"DJTS MARAMURES - Petitie 112": 495,
				"DJTS MEHEDINT - Petitie 112I": 496,
				"DJTS MURES - Petitie 112": 497,
				"DJTS NEAMT - Petitie 112": 498,
				"DJTS OLT - Petitie 112": 499,
				"DJTS PRAHOVA - Petitie 112": 500,
				"DJTS SALAJ - Petitie 112": 502,
				"DJTS SATU MARE - Petitie 112": 501,
				"DJTS SIBIU - Petitie 112": 504,
				"DJTS SUCEAVA - Petitie 112": 505,
				"DJTS TELEORMAN - Petitie 112": 507,
				"DJTS TIMIS - Petitie 112": 503,
				"DJTS TULCEA - Petitie 112": 506,
				"DJTS VALCEA - Petitie 112": 509,
				"DJTS VASLUI - Petitie 112": 508,
				"DJTS VRANCEA - Petitie 112": 510,

				"DL": 220,
				"DMP": 226,
				"DMRU": 231,
				"DOES": 225,
				"DOMO": 224,
				"DSCSTI": 234,
				"DSI": 232,
				"DTI": 210,
				"SIAPI": 235,
				"SICCD": 233
			}

			var petitii_112 = {
				"DJTS ALBA": 1767,
				"DJTS ARAD": 1768,
				"DJTS ARGES": 1769,
				"DJTS BACAU": 1770,
				"DJTS BIHOR": 1771,
				"DJTS BISTRITA-NASAUD": 1772,
				"DJTS BOTOSANI": 1773,
				"DJTS BRAILA": 1774,
				"DJTS BRASOV": 1775,
				"DJTS BUZAU": 1776,
				"DJTS CALARASI": 1777,
				"DJTS CARAS-SEVERIN": 1778,
				"DJTS CLUJ": 1779,
				"DJTS CONSTANTA": 1780,
				"DJTS COVASNA": 1781,
				"DJTS DAMBOVITA": 1782,
				"DJTS DOLJ": 1783,
				"DJTS GALATI": 1784,
				"DJTS GIURGIU": 1785,
				"DJTS GORJ": 1786,
				"DJTS HARGHITA": 1787,
				"DJTS HUNEDOARA": 1788,
				"DJTS IALOMITA": 1789,
				"DJTS IASI": 1790,
				"DJTS MARAMURES": 1791,
				"DJTS MEHEDINTI": 1792,
				"DJTS MURES": 1793,
				"DJTS NEAMT": 1794,
				"DJTS OLT": 1795,
				"DJTS PRAHOVA": 1796,
				"DJTS SALAJ": 1797,
				"DJTS SATU MARE": 1798,
				"DJTS SIBIU": 1799,
				"DJTS SUCEAVA": 1800,
				"DJTS TELEORMAN": 1801,
				"DJTS TIMIS": 1802,
				"DJTS TULCEA": 1803,
				"DJTS VALCEA": 1804,
				"DJTS VASLUI": 1805,
				"DJTS VRANCEA": 1806
			}



			//project_id = directii_json[ $('.assigned-to .value').text().split(' - Conducere')[0] ];



			console.log("GET info despre issue parinte");
			console.log(data);



			/*---------------------- WATCHER LOCKED -------------------------*/
			var users_locked = [];
			var j = 0;
			for (i = 0; i <= $('.watchers li').length - 1; i++) {
				if ($('.watchers li .user:eq(' + i + ')').hasClass('locked') == true) {
					users_locked[j] = $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li .user:eq(' + i + ')').attr('href').split('users/')[1]);
				}
				if ($('.watchers li:eq(' + i + ')')[0].innerHTML.indexOf('user active') == -1) {
					users_locked[j] = $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1];
					j++;
					console.log("User LOCKED: " + $('.watchers li:eq(' + i + ')')[0].classList[0].split('user-')[1]);
				}
			}

			var watchersJSON = [];
			for (i = 0; i <= data.issue.watchers.length - 1; i++) {
				//watchersJSON.push( (data.issue.watchers[i].id).toString() );
				if ($.inArray((data.issue.watchers[i].id).toString(), users_locked) == -1) {
					watchersJSON.push((data.issue.watchers[i].id).toString());
				} else {
					console.log(data.issue.watchers[i].id + " - watcher-ul este LOCKED");
				}
			}

			/*--------- REMOVE WATCHERS DUPLICATES ---------*/
			var unique_watchersJSON = [];

			$.each(watchersJSON, function (i, el) {
				if ($.inArray(parseInt(el), unique_watchersJSON) === -1) unique_watchersJSON.push(el);
			});
			watchersJSON = unique_watchersJSON
			console.log(watchersJSON);
			/*======= END REMOVE WATCHERS DUPLICATES ========*/

			localStorage.setItem('currentIssueWatchers', JSON.stringify(watchersJSON));



			console.log(unitatiAprobareAlese);



			for (i = 0; i <= unitatiAprobareAlese.length - 1; i++) {
				if (changeNewAssignee == 0) {
					var theNewAssignee = 0;
				} else {
					var theNewAssignee = petitii_112[(unitatiAprobareAlese[i].project_id).toUpperCase()];
				}

				//newRepartitieSubtask(assignedToUpdate, parentProjectId, newProjectId, parentSubject, parentAssignedId, newAssignedId, parentIssueId, statusID, customFields)				
				newRepartitieSubtask(
					unitatiAprobareAlese[i].id, //assignedToUpdate
					data.issue.project.id, //parentProjectId PUT ulterior in directii_json[(unitatiAprobareAlese[i].project_id).toUpperCase()]
					directii_json[(unitatiAprobareAlese[i].project_id).toUpperCase()], //newProjectId
					data.issue.subject, //parentSubject
					unitatiAprobareAlese[i].id, // parentAssignedId data.issue.assigned_to.id
					theNewAssignee, // newAssignedId data.issue.assigned_to.id
					data.issue.id, //parentIssueId
					"4", //statusID
					customFields
				);

				console.log('---------------');
				console.log(unitatiAprobareAlese[i].intro);
			}


			$.ajax({
				type: "PUT",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,relations",
				data: JSON.stringify({ "issue": { "status_id": "5" } }) // facem statusul Assigned 5
			}).done(function (data) {
				console.log(data);
				console.log('Statusul pentru: ' + data.issue.id + " a fost schimbat in 5(Assigned)");
			});


			$(document).bind('ajaxStop', function () {
				setTimeout(function () {
					window.location.reload();
				}, 500);

			});

		});
	} // newRepartitieIfPetitie112()




























	if (
		(window.location.href.indexOf('issues') != -1) &&
		(($('#content h2').text().indexOf('Repartitie #') != -1)) // || ( $('#content h2').text().indexOf('Repartitie #') != -1 )
	) {
		//---------- daca un task Repartitie e NEW ii punem ASIGNEE, il facem Asigned -----------
		$('#issue_assigned_to_id').on('change', function () {
			if (
				($('#issue_assigned_to_id').val() != "") &&     //e asignat
				($('#issue_status_id').val() == 4)		      // e NEW
			) {
				$('#issue_status_id').val(5);
			}
		});
	}



	//----------------------- ASCUNDEM Istoric adaugare watcheri, "CV -" ----------------------------
	$(".journal.has-notes:contains('watchers')").hide();
	$(".details li:contains('CV -')").hide();


	//-------- ASCUNDEM "CV - Link intranet" daca avem "Link intranet" si "CV - Link intranet" completate -----
	if (window.location.href.indexOf('issues/') != -1) {
		if (
			($('.cf_24 .value a').attr('href') != undefined) &&
			($('.cf_34 .value a').attr('href') != undefined)
		) {
			$('.cf_34').hide();
		}
	}


	//------------------- CHANGE COLOR ON DEVEL ------------------------
	if (window.location.href.indexOf('.devel.stsnet.ro') != -1) {
		$('#header').css('background', '#ff8800');
	}











	//------------------------ SEND NOTIFICATION PORTAL ------------------------------
	if ($('#loggedas .user').text() == 'admin') {
		$('#notificationManage').show();
	}


	function send_notification_portal_redmine(username, title, subject, time, link, notification_issue_id) {

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + notification_issue_id + ".json?include=watchers"
		}).done(function (data) {
			var notification_payload = JSON.stringify(data);

			$.ajax({
				type: "GET",
				async: false,
				url: "https://portal.sts.ro/api/notification-types?filter[code]=REDMINE"
			}).done(function (data) {
				console.log(data[0].id);

				var application_type_id = parseInt(data[0].id);

				$.ajax({
					type: "GET",
					async: false,
					url: "https://portal.sts.ro/api/users?filter[username]=" + username
				}).done(function (data) {

					if (data[0].id != undefined) {
						var portal_id = [];
						portal_id[0] = data[0].id;
						console.log(portal_id);
						//---- send portal notification ----
						$.ajax({
							type: "POST",
							async: false,
							url: "https://portal.sts.ro/api/notifications",
							headers: { "notification-authorization": "L9FKD9nXRFS3k8ncpv8gnFjkGYB69A7A" },
							contentType: "application/json",
							dataType: "json",
							data: JSON.stringify({
								"id": null,
								"title": title,
								"description": subject,
								"notification_receiver_type_id": 4,//https://portal.sts.ro/api/notification-receiver-types?filter[code]=SELECTION
								"notification_priority_id": 2,
								"sender_application_id": application_type_id,
								"notification_type_id": application_type_id,
								"sender_user_id": null,
								"link": link,
								"is_sticky": false,
								"open_in_new_tab": true,
								"published_at": time,
								"notification_tags": [7], //https://portal.sts.ro/api/notification-tags?filter[code]=REDMINE
								"selected_users_list": portal_id,
								"selected_groups_list": [],
								"payload": notification_payload
							})
						}).done(function (data) {
							console.log(data);
						}); // done send notification

					} // if data.id != undefined

				}); // done map redmine_id <> portal_id


			}); // ajax get applicaiton type id (redmine = 1)


		}); // get issue data for notifications


	}// function send_notification_portal_redmine




	function verify_notification_portal_redmine_sol_aprob_open() {
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues.json?tracker_id=49&status_id=1&limit=100"
		}).done(function (data1) {
			//console.log(data1);

			var notification_counter = [];
			notification_counter[1] = 1;
			notification_counter[2] = 1;

			var i;
			for (i = 0; i <= data1.issues.length - 1; i++) {
				//console.log(">>>" + " [" + data1.issues[i].status.name + "] " + data1.issues[i].tracker.name + " - " + data1.issues[i].id + " : " + data1.issues[i].subject + " | " + data1.issues[i].assigned_to.name + " | " + data1.issues[i].assigned_to.id);

				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/groups/" + data1.issues[i].assigned_to.id + ".json?include=users&limit=100"
				}).done(function (data2) {
					//console.log(data2.group.users);
					var j;
					for (j = 0; j <= data2.group.users.length - 1; j++) {
						//console.log(data2.group.users[j].id + " - " + data2.group.users[j].name);
						$.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/users/" + data2.group.users[j].id + ".json?limit=100"
						}).done(function (data3) {
							console.log(data3.user.login + " >>> " + " [" + data1.issues[i].status.name + "] " + data1.issues[i].tracker.name + " - " + data1.issues[i].id + " : " + data1.issues[i].subject + " | " + data1.issues[i].assigned_to.name + " [" + data1.issues[i].assigned_to.id + "]" + " , link: " + window.location.origin + "/issues/" + data1.issues[i].id + "/");

							//---- set notifiation parameters ----
							var notification_username = data3.user.login;

							var notification_title = "[" + data1.issues[i].status.name + "] " + data1.issues[i].tracker.name + " - " + data1.issues[i].id;

							var notification_subject = data1.issues[i].subject + " | " + data1.issues[i].assigned_to.name + " [" + data1.issues[i].assigned_to.id + "]";

							var notification_link = window.location.origin + "/issues/" + data1.issues[i].id + "/";

							//var notification_time = new Date().toJSON().split('.')[0] + "+02:00"; //"2020-01-09T11:19:18+02:00";
							var date = new Date();
							var userTimezoneOffset = date.getTimezoneOffset() * 60000;
							var date_final = new Date(date.getTime() - userTimezoneOffset).toJSON();
							var notification_time = date_final;

							var notification_issue_id = data1.issues[i].id;

							//---- send notification for each username ----					
							/////send_notification_portal_redmine(notification_username,notification_title,notification_subject,notification_time);



							var date_now = new Date(new Date().toJSON().split('.')[0] + "Z");
							var date_last = new Date(data1.issues[i].updated_on);
							var diff_days = parseInt((new Date(date_now) - new Date(date_last)) / (1000 * 60 * 60 * 25), 10);

							function generate_notificaiton_table_row(checkbox_set_id) {
								var notification_table_row =
									"<tr class='newPOPUP_notification_row' id='newPOPUP_notification_row-" + checkbox_set_id + "_" + notification_counter[checkbox_set_id] + "'>" +
									"<td class='newPOPUP_results_notification_counter'>" + notification_counter[checkbox_set_id] + "</td>" +
									"<td>" +
									"<input type='checkbox' class='newPOPUP_notification_checkbox newPOPUP_notification_checkbox-" + checkbox_set_id + "' id='newPOPUP_notification_checkbox-" + checkbox_set_id + "_" + notification_counter[checkbox_set_id] + "'" +
									"notification_username='" + notification_username + "' " +
									"notification_title='" + notification_title + "' " +
									"notification_subject='" + notification_subject + "' " +
									"notification_time='" + notification_time + "' " +
									"notification_link='" + notification_link + "' " +
									"notification_issue_id='" + notification_issue_id + "' " +
									"'/>" +
									"</td>" +
									"<td>" +
									"<a href='" + window.location.origin + "/issues/" + data1.issues[i].id + "' target='_blank'>" + data1.issues[i].id + "</a>" +
									"</td>" +
									"<td class='newPOPUP_results_notification_subject'>" + data1.issues[i].subject + "</td>" +
									"<td class='newPOPUP_results_notification_login'>" + data3.user.login + "</td>" +
									"<td class='newPOPUP_results_notification_assigned'>" + data1.issues[i].assigned_to.name + "</td>" +
									"<td>" + data1.issues[i].updated_on.replace('T', '   ').replace('Z', '') + "</td>" +
									"<td>" + diff_days + " zile</td>"
								"</tr>";
								notification_counter[checkbox_set_id]++;
								$('#newPOPUP_notification_result-' + checkbox_set_id).append(notification_table_row);
							}

							if (
								data1.issues[i].assigned_to.id == 325 ||
								data1.issues[i].assigned_to.id == 326 ||
								data1.issues[i].assigned_to.id == 324 ||
								data1.issues[i].assigned_to.id == 1354
							) {
								if (parseInt(diff_days) >= 2) {
									generate_notificaiton_table_row(2);
								}
							} else {
								generate_notificaiton_table_row(1);
							}

						});
					}
				});

				console.log("------------------------------------------");

			}
			alert('Au fost identificate ' + (notification_counter[1] + notification_counter[2]) + ' issue-uri.');
		});
	} // function verify_notification_portal_redmine_sol_aprob_open()




	$('#notificationManage').on('click', function () {
		$('#newPOPUP_overlay_notification').show();
	});

	$('#newPOPUP_close_notification').on('click', function () {
		$('#newPOPUP_overlay_notification').hide();
		$('.newPOPUP_results_notification').html('');
	});

	//---- check for notifications ----
	$('.newPOPUP_notificationVerify_button').on('click', function () {
		$('#newPOPUP_notification_checkbox_all-' + $(this).attr('id').split('-')[1]).prop("checked", false);
		$('.newPOPUP_results_notification').html('');
		verify_notification_portal_redmine_sol_aprob_open();
	});

	//---- send selected notifications ----
	$('.newPOPUP_notificationSend_button').on('click', function () {
		var notification_selected_counter = 0;
		for (i = 0; i <= $('.newPOPUP_notification_checkbox').length - 1; i++) {
			if ($('.newPOPUP_notification_checkbox:eq(' + i + ')').prop('checked')) {
				notification_selected_counter++;
				/*console.log( $('#newPOPUP_notification_row-' + $(this).attr('id').split('-')[1] + '_' + (i+1) ).attr('notification_username') );
				console.log( $('#newPOPUP_notification_row-' + $(this).attr('id').split('-')[1] + '_' + (i+1) ).attr('notification_title') );
				console.log( $('#newPOPUP_notification_row-' + $(this).attr('id').split('-')[1] + '_' + (i+1) ).attr('notification_subject') );
				console.log( $('#newPOPUP_notification_row-' + $(this).attr('id').split('-')[1] + '_' + (i+1) ).attr('notification_time') );*/
				var username = $('.newPOPUP_notification_checkbox:eq(' + i + ')').attr('notification_username');
				console.log(username);
				var title = $('.newPOPUP_notification_checkbox:eq(' + i + ')').attr('notification_title');
				console.log(title);
				var subject = $('.newPOPUP_notification_checkbox:eq(' + i + ')').attr('notification_subject');
				console.log(subject);
				var time = $('.newPOPUP_notification_checkbox:eq(' + i + ')').attr('notification_time');
				console.log(time);
				var link = $('.newPOPUP_notification_checkbox:eq(' + i + ')').attr('notification_link');
				console.log(link);
				console.log('-------------------------');
				send_notification_portal_redmine(username, title, subject, time, link);
			}
		}

		alert('Au fost trimise ' + notification_selected_counter + ' notificari.');

	});

	$('.newPOPUP_notification_checkbox_all').on('change', function () {
		//console.log($(this).attr('id'));
		//console.log(this.checked);

		$('.newPOPUP_notification_checkbox-' + $(this).attr('id').split('-')[1]).prop("checked", $(this).prop("checked"));
	});
	//======================= END NOTIFICATION PORTAL ============================




	//------------------------ APPROVE ISSUE ------------------------------	
	if ($('#loggedas .user').text() == 'admin' || $('#loggedas .user').text() == 'laura.jurcut' || $('#loggedas .user').text() == 'manuela.sarateanu') {
		$('#approveIssuesManage').show();
	}

	function search_issues_solicitare_open() {
		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/issues.json?tracker_id=49&status_id=1&limit=100"
		}).done(function (data1) {
			console.log(data1);
			var approve_counter = [];
			approve_counter[1] = 1;
			approve_counter[2] = 1;

			var i;
			for (i = 0; i <= data1.issues.length - 1; i++) {

				var date_now = new Date(new Date().toJSON().split('.')[0] + "Z");
				var date_last = new Date(data1.issues[i].updated_on);
				var diff_days = parseInt((new Date(date_now) - new Date(date_last)) / (1000 * 60 * 60 * 25), 10);

				function generate_approve_table_row(checkbox_set_id) {
					var approve_table_row =
						"<tr class='newPOPUP_approve_row' id='newPOPUP_approve_row-" + checkbox_set_id + "_" + approve_counter[checkbox_set_id] + "'>" +
						"<td class='newPOPUP_results_approve_counter'>" + approve_counter[checkbox_set_id] + "</td>" +
						"<td class='newPOPUP_results_approve_checkbox'>" +
						"<input type='checkbox' class='newPOPUP_approve_checkbox newPOPUP_approve_checkbox-" + checkbox_set_id + "' id='newPOPUP_approve_checkbox-" + checkbox_set_id + "_" + approve_counter[checkbox_set_id] + "'" +
						"approve_issue_id='" + data1.issues[i].id + "' " +
						"approve_subject='" + data1.issues[i].subject + "' " +
						"approve_assigned_to='" + data1.issues[i].assigned_to.name + "' " +
						"approve_time='" + date_last + "' " +
						"'/>" +
						"</td>" +
						"<td class='newPOPUP_results_approve_issue_id'>" +
						"<a href='" + window.location.origin + "/issues/" + data1.issues[i].id + "' target='_blank'>" + data1.issues[i].id + "</a>" +
						"</td>" +
						"<td class='newPOPUP_results_approve_subject'>" + data1.issues[i].subject + "</td>" +
						"<td class='newPOPUP_results_approve_assigned'>" + data1.issues[i].assigned_to.name + "</td>" +
						"<td class='newPOPUP_results_approve_updated_on'>" + data1.issues[i].updated_on.replace('T', '   ').replace('Z', '') + "</td>" +
						"<td class='newPOPUP_results_approve_zile'>" + diff_days + " zile</td>"
					"</tr>";

					approve_counter[checkbox_set_id]++;
					$('#newPOPUP_approve_result-' + checkbox_set_id).append(approve_table_row);
				}

				if (
					data1.issues[i].assigned_to.id == 325 ||
					data1.issues[i].assigned_to.id == 326 ||
					data1.issues[i].assigned_to.id == 324 ||
					data1.issues[i].assigned_to.id == 1354
				) {
					/*if( parseInt(diff_days) >= 2 && $('#loggedas .user').text() == 'admin' ) {
						generate_approve_table_row(2);
					}*/
				} else {
					if ($('#loggedas .user').text() == 'laura.jurcut' || $('#loggedas .user').text() == 'manuela.sarateanu') {
						if (parseInt(diff_days) >= 2) {
							generate_approve_table_row(1);
						}
					}
					if ($('#loggedas .user').text() == 'admin') {
						if (parseInt(diff_days) >= 2) {
							generate_approve_table_row(1);
						}
					}
				}

			} // for all issues	
		});
	}

	$('#approveIssuesManage').on('click', function () {
		$('#newPOPUP_overlay_approve').show();
	});

	$('#newPOPUP_close_approve').on('click', function () {
		$('#newPOPUP_overlay_approve').hide();
		$('.newPOPUP_results_approve').html('');
	});


	//---- check for issues ----
	$('.newPOPUP_approveCheck_button').on('click', function () {
		$('#newPOPUP_approve_checkbox_all-' + $(this).attr('id').split('-')[1]).prop("checked", false);
		$('.newPOPUP_results_approve').html('');
		search_issues_solicitare_open();
	});

	//---- approve selected issues ----
	$('.newPOPUP_approveSubmit_button').on('click', function () {
		var issues_selected_counter = 0;
		for (i = 0; i <= $('.newPOPUP_approve_checkbox').length - 1; i++) {
			if ($('.newPOPUP_approve_checkbox:eq(' + i + ')').prop('checked')) {
				issues_selected_counter++;

				console.log($('.newPOPUP_approve_checkbox:eq(' + i + ')').attr('approve_issue_id'));
				console.log($('.newPOPUP_approve_checkbox:eq(' + i + ')').attr('approve_subject'));
				console.log($('.newPOPUP_approve_checkbox:eq(' + i + ')').attr('approve_assigned_to'));
				console.log($('.newPOPUP_approve_checkbox:eq(' + i + ')').attr('approve_time'));
				console.log('-------------------------');

				var issue_id_approve = $('.newPOPUP_approve_checkbox:eq(' + i + ')').attr('approve_issue_id');

				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues/" + issue_id_approve + ".json",
					data: JSON.stringify({ "issue": { "status_id": "24" } })
				}).done(function (data) {
					console.log(data);
				});
				aprobareClickDreapta(issue_id_approve);



			}
		}

		alert('Au fost aprobate ' + issues_selected_counter + ' issue-uri.');

		// STS 7.0: după aprobare, dialogul se închide (ca la butonul de închidere)
		if (issues_selected_counter > 0) {
			$('#newPOPUP_overlay_approve').hide();
			$('.newPOPUP_results_approve').html('');
		}

	});

	$('.newPOPUP_approve_checkbox_all').on('change', function () {
		//console.log($(this).attr('id'));
		//console.log(this.checked);

		$('.newPOPUP_approve_checkbox-' + $(this).attr('id').split('-')[1]).prop("checked", $(this).prop("checked"));
	});


	//======================= END APPROVE ISSUE ============================









	//------------------------ MANAGE GROUPS ------------------------------	
	$.ajax({
		type: "GET",
		async: false,
		headers: {
			"Content-Type": "application/json",
			"X-Redmine-API-Key": STS.apiKey,
			"X-Redmine-Switch-User": $('#loggedas .user').text()
		},
		url: "/users/current.json?include=groups"
	}).done(function (data) {


		/*if( 
			( window.location.href.indexOf('issues') != -1 ) &&
			( 
				( $('#content h2').text().indexOf('Document de iesire #') != -1 ) || 
				( $('#content h2').text().indexOf('Document intern #') != -1 ) 	|| 
				( $('#content h2').text().indexOf('Proiecte Instalare Echipamente #') != -1 )			
			)
		) {
			//$('#buttonNewSolAprobIfDocAprobCond').show();
		*/


		localStorage.setItem('logged_user_id', data.user.id);
		localStorage.setItem('logged_user_login', data.user.login);
		localStorage.setItem('logged_user_name', data.user.firstname + ' ' + data.user.lastname);
		localStorage.setItem('logged_user_directie', data.user.custom_fields[0].value);

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/users/" + data.user.id + ".json?include=groups"
		}).done(function (data) {
			for (i = 0; i <= data.user.groups.length - 1; i++) {
				if (data.user.groups[i].name == "group_manager") {
					$('#groupManage').show();
					//break;
				}
				if (data.user.groups[i].name.indexOf('DOES') != -1) {
					$('#buttonNewSolAprobIfDocAprobCond_addVerificare_consilieri').show();
				}
				if (
					(
						data.user.groups[i].name.toLowerCase().indexOf('conducere') != -1 ||
						data.user.groups[i].name.toLowerCase().indexOf('- md') != -1 ||
						data.user.groups[i].name.toLowerCase().indexOf('does - petitie 112') != -1
					) &&
					(
						($('#content h2').text().indexOf('Document de iesire #') != -1) ||
						($('#content h2').text().indexOf('Document intern #') != -1) ||
						($('#content h2').text().indexOf('Proiecte Instalare Echipamente #') != -1)
					)
				) {
					localStorage.setItem('user_group_conducere', data.user.groups[i].name);
					$('#buttonNewSolAprobIfDocAprobCond').show();
				}
			}
		});
	});




	$('#groupManage').on('click', function () {
		$('#newPOPUP_overlay_groupManage').show();

		populateGroupManage();

	});

	$('#newPOPUP_close_groupManage').on('click', function () {
		$('#newPOPUP_overlay_groupManage').hide();
		$('#groupManage_groups').html('');
	});

	$('#groupManage_userInput').on('keyup', function () {
		$('#groupManage_userResults').html('');
		$('.groupManage_checkbox').prop('checked', false);
		if ($('#groupManage_userInput').val().length >= 4) {
			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/users.json?name=" + $('#groupManage_userInput').val()
			}).done(function (data) {
				//console.log(data.users);		

				for (i = 0; i <= data.users.length - 1; i++) {
					if ($('#loggedas .user').text() == "eugen.ciutaru") {
						$('#groupManage_userResults').append("<div data-id='" + data.users[i].id + "' class='groupManage_user'>" + data.users[i].lastname + " " + data.users[i].firstname + "</div>");
					} else if (data.users[i].custom_fields[0].value == $('#groupManage_unitatea').attr('data-unit-name')) {
						$('#groupManage_userResults').append("<div data-id='" + data.users[i].id + "' class='groupManage_user'>" + data.users[i].lastname + " " + data.users[i].firstname + "</div>");
					}
				}
			});
		} else {
			$('#groupManage_userResults').html('');
			$('.groupManage_checkbox').prop('checked', false);
		}
	});



	//------------------- show groups people on mouseover -------------------------
	$('#newPOPUP_overlay_groupManage').on('mouseover', '.newPOPUP_row_300', function () {

		$('#groupManage_groupsMembers').html('');

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/groups/" + $(this).attr('data-group-id') + ".json?include=users"
		}).done(function (data) {
			for (i = 0; i <= data.group.users.length - 1; i++) {
				if (data.group.users[i].id != 1) {
					$('#groupManage_groupsMembers').append("<div class='newPOPUP_row_300'>" + data.group.users[i].name + "</div>");
				}
			}
		});

	}).on('mouseout', '.newPOPUP_row_300', function () {
		$('#groupManage_groupsMembers').html('');
	});



	$('#groupManage_userResults').on('click', '.groupManage_user', function () {
		$('#groupManage_userInput').val($(this).text());
		$('#groupManage_adauga').attr('data-user-id', $(this).attr('data-id'));
		$('#groupManage_userResults').html('');
		$('.groupManage_checkbox').prop('checked', false);

		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/users/" + $(this).attr('data-id') + ".json?include=groups"
		}).done(function (data) {
			// console.log(data.user.groups);
			var included_groups_array = [];
			for (i = 0; i <= data.user.groups.length - 1; i++) {
				$('.groupManage_checkbox').each(function () {
					if ($(this).attr('data-group-id') == data.user.groups[i].id) {
						$('#groupManage_checkbox_' + data.user.groups[i].id).prop('checked', true);
						console.log('selected user groups: ' + data.user.groups[i].id);
						included_groups_array.push(data.user.groups[i].id);
					}
				});
			}
			// console.log(included_groups_array);
			localStorage.setItem('included_groups_array', JSON.stringify(included_groups_array)); // array to save clicked user's existing groups
		});

	});


	function populateGroupManage() {
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/users/current.json"
		}).done(function (data) {

			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/users/" + data.user.id + ".json?include=groups"
			}).done(function (data) {
				//console.log(data);
				// console.log(data.user.groups);

				$('#groupManage_unitatea').text("Unitatea militara:" + data.user.custom_fields[0].value);
				$('#groupManage_unitatea').attr('data-unit-id', data.user.custom_fields[0].id);
				$('#groupManage_unitatea').attr('data-unit-name', data.user.custom_fields[0].value);


				var already_appended = [];

				for (i = 0; i <= data.user.groups.length - 1; i++) {

					//---------- daca e in UNITATE - Conducere, vede UNITATE - Orice -------
					if (data.user.groups[i].name == $('#groupManage_unitatea').attr('data-unit-name') + " - Conducere") {
						//alert( data.user.groups[i].name );

						$.ajax({
							type: "GET",
							async: false,
							headers: {
								"Content-Type": "application/json",
								"X-Redmine-API-Key": STS.apiKey,
								"X-Redmine-Switch-User": 'admin'
							},
							url: "/groups.json"
						}).done(function (data) {
							for (i = 0; i <= data.groups.length - 1; i++) {
								if (data.groups[i].name.indexOf($('#groupManage_unitatea').attr('data-unit-name')) != -1) {
									if ($('#groupManage_checkbox_' + data.groups[i].id).length == 0) {
										$('#groupManage_groups').append("<div class='newPOPUP_row_300' data-group-id='" + data.groups[i].id + "'><input class='groupManage_checkbox' id='groupManage_checkbox_" + data.groups[i].id + "' type='checkbox' data-group-id='" + data.groups[i].id + "'>" + data.groups[i].name + "</div>");
									}
								}
							}
						});


					} else {
						if (
							data.user.groups[i].name != "group_manager" &&
							(data.user.groups[i].name.indexOf($('#groupManage_unitatea').attr('data-unit-name')) != -1 || data.user.groups[i].name == "STS - utilizatori")
						) {
							if (data.user.groups[i].id != 1029) {
								if ($('#groupManage_checkbox_' + data.user.groups[i].id).length == 0) {
									$('#groupManage_groups').append("<div class='newPOPUP_row_300' data-group-id='" + data.user.groups[i].id + "' ><input class='groupManage_checkbox' id='groupManage_checkbox_" + data.user.groups[i].id + "' type='checkbox' data-group-id='" + data.user.groups[i].id + "'>" + data.user.groups[i].name + "</div>");
								}
							}
						}
					} // daca nu e in conducere		

				}

			});

		});
	}

	$('#groupManage_adauga').on('click', function () {
		var included_groups_array = JSON.parse(localStorage.getItem('included_groups_array'));

		$('.groupManage_checkbox').each(function () {
			if (
				$(this).prop('checked') == true
			) {
				if (!included_groups_array.includes(parseInt($(this).attr('data-group-id')))) {
					$.ajax({
						type: "POST",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/groups/" + $(this).attr('data-group-id') + "/users.json?user_id=" + $('#groupManage_adauga').attr('data-user-id')
					}).done(function (data) {
						console.log(data);
					});
				}
			} else {
				$.ajax({
					type: "DELETE",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/groups/" + $(this).attr('data-group-id') + "/users/" + $('#groupManage_adauga').attr('data-user-id') + ".json"
				}).done(function (data) {
					console.log(data);
				});
			}
		});

		alert('Modificarile au fost salvate cu succes!');

	});
	//====================== END MANAGE GROUPS ============================









	//------------------ Verifica daca avem task-uri NEW cu toti copiii aprobati --------------	
	if ($('#loggedas .user').text() == "admin" && window.location.pathname == "/") {
		$('#homeCheckNewOpenErrors').show();

		$('#homeCheckNewOpenErrorsButton').on('click', function () {

			$.ajax({
				type: "GET",
				async: false,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				}, // $('#loggedas .user').text()
				url: "/issue_statuses.json"
			}).done(function (data) {
				var i;
				var issueStatusClosed = [];
				for (i = 0; i <= data.issue_statuses.length - 1; i++) {
					if (data.issue_statuses[i].is_closed == true && data.issue_statuses[i].id != 26) {
						issueStatusClosed.push(data.issue_statuses[i].id);
					}
				}

				console.log("---------------------------------");
				console.log("Status-urile de tip closed sunt: ");
				console.log(issueStatusClosed);
				console.log("=================================");

				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": "admin"
					},
					url: "/issues.json?project_id=206&query_id=53&limit=100"
				}).done(function (data) {
					console.log(data);

					var i;
					var newToBeOpen = 0;

					for (i = 0; i <= data.issues.length - 1; i++) {

						//------ daca issue este de tip NEW -------
						if (data.issues[i].status.id == 4) {
							//if($.inArray( parseInt(data.issues[i].status.id) , issueStatusClosed ) != -1) {
							if (data.issues[i].status.id != 24 && data.issues[i].status.id != 26 && data.issues[i].status.id != 27) { // daca nu e aprobat/anulat

								console.log("Issue cu id-ul " + data.issues[i].id + " este de tip New, vom verifica daca are copii");
								console.log("=========================================================");

								// get children check if all are CLOSED;
								$.ajax({
									type: "GET",
									async: false,
									headers: {
										"Content-Type": "application/json",
										"X-Redmine-API-Key": STS.apiKey,
										"X-Redmine-Switch-User": "admin"
									},
									url: "/issues/" + data.issues[i].id + ".json?include=children"
								}).done(function (data) {
									//console.log(data);		

									//----- verificam daca are copii ------------
									if (data.issue.children != undefined) {

										var parentToMakeOpen = data.issue.id;
										console.log("Issue cu id-ul " + parentToMakeOpen + " are copii");

										$.ajax({
											type: "GET",
											async: false,
											headers: {
												"Content-Type": "application/json",
												"X-Redmine-API-Key": STS.apiKey,
												"X-Redmine-Switch-User": "admin"
											},
											url: "/issues/" + data.issue.children[0].id + ".json"
										}).done(function (data) {
											if ($.inArray(parseInt(data.issue.status.id), issueStatusClosed) != -1) {
												console.log("Copilul cu id-ul " + data.issue.id + " are status id " + data.issue.status.id + " si e de tip closed");

												console.log("Facem issue cu id-ul " + parentToMakeOpen + " Open");
												console.log("===================================================")
												$('#homeCheckNewOpenErrorsResponse').text("Facem issue cu id-ul " + parentToMakeOpen + "Open");

												// facem parintele OPEN adica 1 din 4
												$.ajax({
													type: "PUT",
													async: false,
													headers: {
														"Content-Type": "application/json",
														"X-Redmine-API-Key": STS.apiKey,
														"X-Redmine-Switch-User": "admin"
													},
													url: "/issues/" + parentToMakeOpen + ".json",
													data: JSON.stringify({ "issue": { "status_id": "1" } })
												}).done(function (data) {
													console.log(data);
													console.log('Statusul pentru: ' + parentToMakeOpen + " a fost schimbat in 1(open)");
												});

												newToBeOpen = newToBeOpen + 1;
											}
										});

									} // daca are copii
								});
							} // daca nu e aprobat/anulat
						}// daca isseu e new
					}

					console.log("Am avut " + newToBeOpen + " task-uri NEW care ar fi trebuit sa fie OPEN");
					$('#homeCheckNewOpenErrorsResponse').text("Am avut " + newToBeOpen + " New si trebuiau OPEN");
				});


			});





		});
	}
	//================ END Verifica daca avem task-uri NEW cu toti copiii aprobati =============











	//---------------------- CUSTOM QUERIES HOMEPAGE ----------------------
	if ($('#homeCustomQueries').length == 1 && window.location.pathname == "/") {
		$('#homeCustomQueriesContainer').show();

		$.ajax({
			type: "GET",
			//async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": $('#loggedas .user').text()
			},
			url: "/queries.json?limit=100"
		}).done(function (data) {
			console.log(data);

			$(data.queries).each(function (index) {
				if (data.queries[index].project_id != undefined) {
					$('#homeCustomQueries').append("<div><a class='homeQuery' href='/projects/" + data.queries[index].project_id + "/issues?query_id=" + data.queries[index].id + "' target='_blank'>" + /*index + '. ' +*/ data.queries[index].name + "<span id='homeQueryID_" + data.queries[index].id + "'></span></a></div>");
				}
			});

		});

		$('#homeCustomQueriesButton').on('click', function () {
			$('.homeQuery').each(function () {
				var queryId = $(this).attr('href').split('query_id=')[1];
				$.ajax({
					type: "GET",
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": $('#loggedas .user').text()
					},
					url: "/issues.json?project_id=206&query_id=" + queryId + "&limit=100"
				}).done(function (data) {
					console.log(data);
					var issueCounter = 0;
					$(data.issues).each(function (index) {
						if (data.issues[index].status.id == 1 || data.issues[index].status.id == 4) {
							issueCounter++;
						}
					});
					$('#homeQueryID_' + queryId).text(" (" + issueCounter + ")");
				});
			});


		});

	}
	//=================== END CUSTOM QUERIES HOMEPAGE =====================




	//---------------------- ADD TARGET BLANK TO CV LINK ------------------
	if (window.location.href.indexOf('/issues/') != -1) {
		$('.issue .attribute .value a').attr('target', '_blank');
	}

	if ($('#new-attachments').length > 0) {
		$('#new-attachments').closest('fieldset').remove();
	}
	//==================== END ADD TARGET BLANK TO CV LINK ================











	//---------------------------------- MY PAGE --------------------------------
	if (window.location.href.indexOf('/my/page') != -1) {

		//--- Add target _blank to issues ---
		$('#list-top a').attr('target', '_blank');
		$('#list-top a').on('click', function () {
			if ($(this).parent().parent().find('td').css('background-color') != 'rgba(255, 0, 0, 0.15)') {
				$(this).parent().parent().find('td').css('background-color', 'rgba(0, 198, 0, 0.1)');
			}
		});

		//--- Add CLOSE issue button ---
		$('body').append("<div class='modal_message_overlay'><div class='modal_message'><img src='" + STS.loadingGif + "'/> Va rugam asteptati...</div></div>");

		//--- ADD inchide button my page ---
		$('.id').each(function () {
			var each_id = $(this).find('a').text();
			$(this).parent().append("<td><a href='javascript:void(0)' class='my_page_close my_page_close icon-only icon-close'></a></td>");
			$('tr.issue').css('white-space', 'normal');
		});

		//--- Inchide issue my page ---
		$('.my_page_close').on('click', function () {

			var the_id = $(this).parent().parent().attr('id').split('issue-')[1];

			//if( confirm('Doriti sa inchideti urmatorul issue: ' + the_id + ' ?') ) {

			//$('body').append("<div class='modal_message_overlay'><div class='modal_message'><img src='" + STS.loadingGif + "'/> Va rugam asteptati...</div></div>");
			$.ajax({
				type: "GET",
				async: true,
				headers: {
					"Content-Type": "application/json",
					"X-Redmine-API-Key": STS.apiKey,
					"X-Redmine-Switch-User": 'admin'
				},
				url: "/issues/" + the_id + ".json?include=watchers,children,journals,relations"
			}).done(function (data) {

				if (data.issue.tracker.id != 49) {
					//------- CLOSE MAIN ISSUE --------------
					close_issue_id(the_id);
					//------- CLOSE CHILDREN --------------
					/*if( data.issue.children != undefined ) {
						console.log(data.issue.children);
						for(i=0;i<=data.issue.children.length-1;i++) {				
							//console.log(data.issue.children);
							close_issue_id( data.issue.children[i].id );
						}												
					}*/
					//------- CLOSE RELATED --------------
					if (data.issue.relations != undefined) {
						console.log(data.issue.relations);
						for (i = 0; i <= data.issue.relations.length - 1; i++) {
							//console.log(data.issue.relations);
							if (data.issue.relations[i].issue_id == the_id) {
								close_issue_id(data.issue.relations[i].issue_to_id);
							} else {
								close_issue_id(data.issue.relations[i].issue_id);
							}
						}
					}
				} else {
					approve_issue_id(the_id);
				}


				setTimeout(function () {
					// moved red background and close alerts to close_issue_id() function						
					// $('#issue-' + the_id + ' td').css('background-color', 'rgb(255 0 0 / 15%)'); // $('#issue-' + the_id).remove();
					$('.modal_message_overlay').remove();
				}, 200);
			});
			//} // confirm doriti sa incideti issue

		}); // on click close issue my page		



		$('thead tr').append('<th></th>');
		$('.modal_message_overlay').remove();

	} // if my page
	//=================================== END MY PAGE ============================
























	//------------------------- NOTIFICARE SALI SEDINTE ---------------------
	function send_notification_credentials_sali(username, title, subject, time, link) {
		$.ajax({
			type: "GET",
			async: false,
			url: "https://portal.sts.ro/api/notification-types?filter[code]=REDMINE"
		}).done(function (data) {
			console.log(data[0].id);

			var application_type_id = parseInt(data[0].id);

			$.ajax({
				type: "GET",
				async: false,
				url: "https://portal.sts.ro/api/users?filter[username]=" + username
			}).done(function (data) {

				if (data[0].id != undefined) {
					var portal_id = [];
					portal_id[0] = data[0].id;
					console.log(portal_id);
					//---- send portal notification ----
					$.ajax({
						type: "POST",
						async: false,
						url: "https://portal.sts.ro/api/notifications",
						headers: { "notification-authorization": "L9FKD9nXRFS3k8ncpv8gnFjkGYB69A7A" },
						contentType: "application/json",
						dataType: "json",
						data: JSON.stringify({
							"id": null,
							"title": title,
							"description": subject,
							"notification_receiver_type_id": 4,//https://portal.sts.ro/api/notification-receiver-types?filter[code]=SELECTION
							"notification_priority_id": 2,
							"sender_application_id": application_type_id,
							"notification_type_id": application_type_id,
							"sender_user_id": null,
							"link": link,
							"is_sticky": false,
							"open_in_new_tab": true,
							"published_at": time,
							"notification_tags": [7], //https://portal.sts.ro/api/notification-tags?filter[code]=REDMINE
							"selected_users_list": portal_id,
							"selected_groups_list": []
						})
					}).done(function (data) {
						console.log('Notificare Sali Videoconferinta: TRIMISA -- Catre username: ' + username);
						console.log(data);
					}); // done send notification

				} // if data.id != undefined

			}); // done map redmine_id <> portal_id


		}); // ajax get applicaiton type id (redmine = 1)
	} // end function send notification credentials	
	var credentials_sali = {
		"VTC-DCAOSR-Cam.Video1-25 loc": {
			id: "11999111",
			pin: "35628"
		},
		"VTC-DCAOSR-Cam.Video2-25 loc": {
			id: "11999112",
			pin: "48639"
		},
		"VTC-DCAOSR-Cam.Video3-25 loc": {
			id: "11999113",
			pin: "86453"
		},
		"VTC-DCAOSR-Cam.Video4-25 loc": {
			id: "11999114",
			pin: "29742"
		},
		"VTC-DCAOSR-Cam.Video Confidentiala-25 loc": {
			id: "11999115",
			pin: "54564"
		}
	};
	var credentials_sali_users = {
		"VTC-DCAOSR-Cam.Video1-25 loc": {
			ext_user1: "ukzSXY!47",
			ext_user2: "jayJYD(76",
			ext_user3: "vfxLOY!20",
			ext_user4: "tkbPVP)43",
			ext_user5: "otfMRN)81",
			ext_user6: "zthTVR$44",
			ext_user7: "zpoKPR)96",
			ext_user8: "dxbHHD&13",
			ext_user9: "arkYFN)78",
			ext_user10: "pthLYJ&61",
			ext_user11: "uecVED)48",
			ext_user12: "ektGNC(06",
			ext_user13: "tnmWLT)45",
			ext_user14: "sfgAWG&63",
			ext_user15: "kygZEG)74",
			ext_user16: "xyhGRJ)91",
			ext_user17: "qmsDWX)33",
			ext_user18: "tzmWUC&04",
			ext_user19: "eqpGQO(40",
			ext_user20: "nyrWRT)22",
			ext_user21: "wzmRJX$46",
			ext_user22: "xftEAN!25",
			ext_user23: "fgvRUT&94",
			ext_user24: "gxaWQZ!08",
			ext_user25: "mggZXJ$33"

		},
		"VTC-DCAOSR-Cam.Video2-25 loc": {
			ext_user26: "jwgOEQ)31",
			ext_user27: "tmcHXH&17",
			ext_user28: "zbaHXC!53",
			ext_user29: "eqfVRL!25",
			ext_user30: "nfrCFJ!59",
			ext_user31: "ghrMXD$81",
			ext_user32: "ytxZFJ&69",
			ext_user33: "psaMLQ(33",
			ext_user34: "fvpGZN$95",
			ext_user35: "pkuZHT)93",
			ext_user36: "hfgVYN!54",
			ext_user37: "easVTY)53",
			ext_user38: "xyfOJT!37",
			ext_user39: "rzrRFF!79",
			ext_user40: "yvtRNA&13",
			ext_user41: "ctqAMU(30",
			ext_user42: "rzaJOP&41",
			ext_user43: "uzhHYY(27",
			ext_user44: "kdyJBQ&55",
			ext_user45: "ykdQGL!88",
			ext_user46: "ztwYRR(74",
			ext_user47: "habURN&45",
			ext_user48: "dxoOTC!85",
			ext_user49: "zrrYVL)48",
			ext_user50: "rtdFWV$87"

		},
		"VTC-DCAOSR-Cam.Video3-25 loc": {
			ext_user51: "kzwVBS!27",
			ext_user52: "wdqLAY!89",
			ext_user53: "rkvVSO!70",
			ext_user54: "hsmMPD&61",
			ext_user55: "ukrYLO&89",
			ext_user56: "cagZGW&54",
			ext_user57: "vrpDWT!78",
			ext_user58: "okjESQ)17",
			ext_user59: "eorVHG&32",
			ext_user60: "amzFZB)28",
			ext_user61: "wmdYKZ)22",
			ext_user62: "rcmLCB!17",
			ext_user63: "gppHBP$88",
			ext_user64: "pjrCUS!92",
			ext_user65: "uruMKB$90",
			ext_user66: "tjqRLN)81",
			ext_user67: "hnzBGH(86",
			ext_user68: "pzbXQV!03",
			ext_user69: "aaeNHL)09",
			ext_user70: "sazFYA)02",
			ext_user71: "ghoCZK&55",
			ext_user72: "ayzSEP!92",
			ext_user73: "cexVLZ&57",
			ext_user74: "bdjYHX!47",
			ext_user75: "nbcDKC$91"

		},
		"VTC-DCAOSR-Cam.Video4-25 loc": {
			ext_user76: "susLEA!35",
			ext_user77: "vkfPXG!12",
			ext_user78: "tcbKLG&35",
			ext_user79: "ppuLYL)79",
			ext_user80: "aofTDT)50",
			ext_user81: "traMYA)56",
			ext_user82: "nrhEKL!38",
			ext_user83: "bkcSOQ)00",
			ext_user84: "mwoVPE!36",
			ext_user85: "bfwGGN$15",
			ext_user86: "ekuXNR&34",
			ext_user87: "sstZTU)37",
			ext_user88: "wzrSLY$05",
			ext_user89: "jebACH&31",
			ext_user90: "bztVAB)15",
			ext_user91: "mewPEC$66",
			ext_user92: "noxGWS!86",
			ext_user93: "dynRAL(03",
			ext_user94: "rryGGD(02",
			ext_user95: "nryYVT&02",
			ext_user96: "wwtNZH(74",
			ext_user97: "qkvECA&81",
			ext_user98: "qrtPAT$49",
			ext_user99: "rzbFGA$17",
			ext_user100: "zbeTJN$89"


		},
		"VTC-DCAOSR-Cam.Video Confidentiala-25 loc": {
			ext_user101: "zjpETN!99",
			ext_user102: "qyqJXM&68",
			ext_user103: "aspDAU$12",
			ext_user104: "ahgTNN&99",
			ext_user105: "aboBNL)51",
			ext_user106: "btuUNV(04",
			ext_user107: "wzrJDG$65",
			ext_user108: "fgjXBF$09",
			ext_user109: "npbDSC(16",
			ext_user110: "crxBDX!20",
			ext_user111: "gzrDBJ&06",
			ext_user112: "bpeKPA!19",
			ext_user113: "jobTTJ(32",
			ext_user114: "etzVLO)88",
			ext_user115: "pdmTVR!66",
			ext_user116: "frwTAU$63",
			ext_user117: "wtoHBW)07",
			ext_user118: "uboTXV)50",
			ext_user119: "yzpZOZ$18",
			ext_user120: "oqqSSL$60",
			ext_user121: "rhbZDO)11",
			ext_user122: "pxnGCQ!08",
			ext_user123: "cywDWP$21",
			ext_user124: "zoyCBM$28",
			ext_user125: "jozGDM&36"

		}
	};


	$('#save_meeting').on('click', function () {

		if ($('#project_id option:selected').text() == "Rezervare Sali Videoconferinta") {
			if ($('#category_id option:selected').text() == "DCAOSR") {
				//var username = 'manuela.sarateanu';
				if ($('#meeting_rooms option:selected').text().indexOf('VTC-DCAOSR') != -1) {
					var nume_sala_selectata = $('#meeting_rooms option:selected').text();
				} else {
					var nume_sala_selectata = $('#selected_meeting_room option:selected').text();
				}


				var username = $('#loggedas .user').text();
				var subject_credentials_sali = "ID: " + credentials_sali[nume_sala_selectata].id + "PIN: " + credentials_sali[nume_sala_selectata].pin;
				var subject_credentials_sali_users = JSON.stringify(credentials_sali_users[nume_sala_selectata]).replace('{', '').replace('}', '').replace(/\",/g, '"\n <br>');

				var title = "Rezervare sala: " + nume_sala_selectata;
				var subject = "Sala: " + $('#selected_meeting_room').val() + "<br> Info Sala: " + subject_credentials_sali + "<br> Login users: <br>" + subject_credentials_sali_users;
				//var time = new Date().toJSON().split('.')[0] + "+02:00";
				var date = new Date();
				var userTimezoneOffset = date.getTimezoneOffset() * 60000;
				var date_final = new Date(date.getTime() - userTimezoneOffset).toJSON();
				var time = date_final;
				var link = "https://redmine.stsnet.ro";
				send_notification_credentials_sali(username, title, subject, time, link);
			}
		} else if ($('#project_id option:selected').text() == "Rezervare Sali Audioconferinta") {
			//var username = 'radu.pereteanu';
			var username = $('#loggedas .user').text();

			var title = "Rezervare sala: " + $('#selected_meeting_room').val();
			var subject = "Sala: " + $('#selected_meeting_room').val() + "<br> Numar participanti:" + $('#participants').val();
			//var time = new Date().toJSON().split('.')[0] + "+02:00";
			var date = new Date();
			var userTimezoneOffset = date.getTimezoneOffset() * 60000;
			var date_final = new Date(date.getTime() - userTimezoneOffset).toJSON();
			var time = date_final;
			var link = "https://redmine.stsnet.ro";
			send_notification_credentials_sali(username, title, subject, time, link);
			send_notification_credentials_sali('vlad.podoprigora', title, subject, time, link);
		}




	});

	//===================== END NOTIFICARE SALI SEDINTE =====================







	//---------------- CLOSE ANY ISSUE BUTTON ---------------------------
	if (
		window.location.href.indexOf('issues/') != -1 &&
		window.location.href.indexOf('issues/new') == -1 &&
		window.location.href.indexOf('issues/gantt') == -1
	) {
		//--- Document intern - close button if status closed
		$.ajax({
			type: "GET",
			async: false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issue_statuses.json"
		}).done(function (statuses) {
			var i;
			var issueStatusClosed = [];
			for (i = 0; i <= statuses.issue_statuses.length - 1; i++) {
				if (statuses.issue_statuses[i].is_closed == true) {
					issueStatusClosed.push(statuses.issue_statuses[i].id);
				}
			}
			localStorage.setItem('closed_statuses', JSON.stringify(issueStatusClosed));

			setTimeout(function () {

				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json"
				}).done(function (data) {
					//--- inchide repartitie ---
					if (data.issue.tracker.id == '52') {
						$('#buttonInchideRepartitie').show();
						$('body').on('click', '#buttonInchideRepartitie', function () {
							close_issue_id(window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]);
							setTimeout(function () {
								window.location.reload();
							}, 500);
						});
					}
					//--- inchide document intern ---
					if ($.inArray(data.issue.status.id, issueStatusClosed) != -1) {
						console.log('Issue status type = closed');
					} else {
						console.log('Issue status type != closed');
					}
					// punem buton Close issue pentru toate documentele interne chiar daca sunt inchise (pt a inchide eventuale issue related nou aparute)
					if (
						$('#content h2').text().indexOf('Document intern #') != -1
					) {
						$("<button id='close_issue_button'>INCHIDE Issue</button>").insertAfter('div.issue');
					}

					if (
						$('#content h2').text().indexOf('Rezolutie #') != -1 || 
						$('#content h2').text().indexOf('Document electronic #') != -1
					) {
						$("<button id='close_issue_button'>FINALIZARE</button>").insertAfter('div.issue');
					}

					if (
						$('#content h2').text().indexOf('Transfer #') != -1
					) {
						$("<button id='close_issue_button'>DE ACORD</button>").insertAfter('div.issue');
					}
				});

			}, 100);


			// Click Buton Inchide Task
			$('body').on('click', '#close_issue_button', function () {

				$('body').append("<div class='modal_message_overlay'><div class='modal_message'><img src='" + STS.loadingGif + "'/> Va rugam asteptati, pagina se va reincarca automat...</div></div>");

				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + window.location.href.split('/issues/')[1].split('?')[0].split('#')[0] + ".json?include=watchers,children,journals,relations"
				}).done(function (data) {
					//------- CLOSE MAIN ISSUE --------------
					close_issue_id(window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]);
					//------- CLOSE CHILDREN --------------
					/*if( data.issue.children != undefined ) {
						console.log(data.issue.children);
						for(i=0;i<=data.issue.children.length-1;i++) {				
							//console.log(data.issue.children);
							close_issue_id( data.issue.children[i].id );
						}												
					}*/
					//------- CLOSE RELATED --------------
					if (data.issue.relations != undefined) {
						console.log(data.issue.relations);
						for (i = 0; i <= data.issue.relations.length - 1; i++) {
							//console.log(data.issue.relations);
							if (data.issue.relations[i].issue_id == window.location.href.split('/issues/')[1].split('?')[0].split('#')[0]) {
								close_issue_id(data.issue.relations[i].issue_to_id);
							} else {
								close_issue_id(data.issue.relations[i].issue_id);
							}
						}
					}

					setTimeout(function () {
						window.location.reload();
					}, 500);

				});

			}); // on CLOSE BUTTON CLICK

		});
	}

	//----------------------------- CLOSE ISSUE BY ID --------------------------------
	function close_issue_id(issue_id) {
		var noteToAdd = "Issue-ul a fost inchis de catre: " + localStorage.getItem('logged_user_name');

		// verificam daca issue este deja inchis
		$.ajax({
			type: "GET",
			async: true,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issue_id + ".json?include=children"
		}).done(function (data) {

			console.log('-------------------------');
			console.log(data.issue.id + ' are status=' + data.issue.status.id + " si este done=" + data.issue.done_ratio + "%");
			// verificam daca task-ul NU e closed
			if (data.issue.status.id != 8) {
				// verificam daca nu are copii SAU daca are copii si e done 100%
				if (
					data.issue.children == undefined ||
					(data.issue.children != undefined && data.issue.done_ratio == 100)
				) {
					console.log()
					// incercam sa inchidem task-ul
					$.ajax({
						type: "PUT",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						}, //$('#loggedas .user').text()	
						url: "/issues/" + issue_id + ".json",
						data: JSON.stringify({ "issue": { "status_id": "8" } })
					}).done(function (put_data) {

					});

					//verificam daca s-a inchis si adaugam comentariu
					$.ajax({
						type: "GET",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						},
						url: "/issues/" + issue_id + ".json"
					}).done(function (data2) {
						if (data2.issue.status.id == "8") {
							if (window.location.href.indexOf('/my/page') != -1) {
								$('#issue-' + data.issue.id + ' td').css('background-color', 'rgba(255, 0, 0, 0.15)');
								$('#issue-' + data.issue.id + ' td').find('.icon-close').remove();
							}
							$.ajax({
								type: "PUT",
								async: false,
								headers: {
									"Content-Type": "application/json",
									"X-Redmine-API-Key": STS.apiKey,
									"X-Redmine-Switch-User": 'admin'
								}, //$('#loggedas .user').text()	
								url: "/issues/" + issue_id + ".json",
								data: JSON.stringify({ "issue": { "done_ratio": "100", "notes": noteToAdd } })
							}).done(function (put_data) {

							});
						} else {
							console.log(data2.issue.id + " - nu a putut fi inchis, probabil are subtask-uri deschise");
							if (window.location.href.indexOf('/my/page') != -1) {
								alert(data2.issue.id + " - nu a putut fi inchis, probabil are subtask-uri deschise");
							}
						}
					});
				} else {
					console.log(data.issue.id + ' nu poate fi inchis deoarece nu are copii sau nu este done 100%');
					if (window.location.href.indexOf('/my/page') != -1) {
						alert(data.issue.id + ' nu poate fi inchis deoarece nu are copii sau nu este done 100%');
					}
				}
			} else { // daca e inchis
				if (data.issue.done_ratio == 100) {
					$.ajax({
						type: "PUT",
						async: false,
						headers: {
							"Content-Type": "application/json",
							"X-Redmine-API-Key": STS.apiKey,
							"X-Redmine-Switch-User": 'admin'
						}, //$('#loggedas .user').text()	
						url: "/issues/" + data.issue.id + ".json",
						data: JSON.stringify({ "issue": { "done_ratio": "100" } })
					}).done(function (put_data) {

					});
				}
			}
		});





		/*
		// incercam sa inchidem task-ul
		$.ajax({
			type:"PUT",
			async:false,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'}, //$('#loggedas .user').text()	
			url:"/issues/" + issue_id + ".json",
			data: JSON.stringify({"issue":{"status_id":"8"}}) 
		}).done(function(data){
		    
		});
 
		//verificam daca s-a inchis si adaugam comentariu
		$.ajax({
			type:"GET",
			async:true,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'},		
			url:"/issues/" + issue_id + ".json"
		}).done(function(data){
			if( data.issue.status.id == "8" ) {
				$.ajax({
					type:"PUT",
					async:false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'}, //$('#loggedas .user').text()	
					url:"/issues/" + issue_id + ".json",
					data: JSON.stringify({"issue":{"done_ratio":"100","notes": noteToAdd}}) 
				}).done(function(data){
				    
				});
			}
		});
		*/



		/*$(document).ajaxComplete(function(){
			setTimeout(function(){						
				window.location.reload();
			},500);
		});*/
	} // function close issue by id
	//================== END CLOSE ANY ISSUE BUTTON ==============================



	//-------------------------- APPROVE ISSUE BY ID ------------------------------
	function approve_issue_id(issue_id) {
		var noteToAdd = "Issue-ul a fost aprobat de catre: " + localStorage.getItem('logged_user_name');

		// verificam daca issue este deja aprobat
		$.ajax({
			type: "GET",
			async: true,
			headers: {
				"Content-Type": "application/json",
				"X-Redmine-API-Key": STS.apiKey,
				"X-Redmine-Switch-User": 'admin'
			},
			url: "/issues/" + issue_id + ".json?include=children"
		}).done(function (data) {

			console.log('-------------------------');
			console.log(data.issue.id + ' are status=' + data.issue.status.id + " si este done=" + data.issue.done_ratio + "%");
			// verificam daca task-ul NU e deja aprobat
			if (data.issue.status.id != 24) {
				$.ajax({
					type: "PUT",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					}, //$('#loggedas .user').text()	
					url: "/issues/" + issue_id + ".json",
					data: JSON.stringify({ "issue": { "status_id": "24", "notes": noteToAdd } })
				}).done(function (put_data) {

				});

				//verificam daca s-a aprobat si adaugam comentariu
				$.ajax({
					type: "GET",
					async: false,
					headers: {
						"Content-Type": "application/json",
						"X-Redmine-API-Key": STS.apiKey,
						"X-Redmine-Switch-User": 'admin'
					},
					url: "/issues/" + issue_id + ".json"
				}).done(function (data2) {
					if (data2.issue.status.id == "24") {
						if (window.location.href.indexOf('/my/page') != -1) {
							$('#issue-' + data.issue.id + ' td').css('background-color', 'rgba(0, 198, 0, 0.15)');
							$('#issue-' + data.issue.id + ' td').find('.icon-close').remove();
						}
					}
				});

			} else { // daca e aprobat
				console.log('Issue-ul este deja aprobat');
			}
		});

	} // function approve issue by id
	//================== END APPROVE ANY ISSUE BUTTON ==============================











	//--- ACCORION ---
	$('#content').on('click', '.accordion_title', function () {
		$(this).parent().toggleClass('accordion_open');
		if ($(this).parent().find('.accordion_body').is(':visible') && $(this).parent().find('iframe').attr('data-loaded') != '1') {
			$(this).parent().find('iframe').attr('src', $(this).parent().find('iframe').attr('data-url'));
			$(this).parent().find('iframe').attr('data-loaded', '1');
			var theWindow = window.open($(this).parent().find('iframe').attr('data-fullurl'), '', 'width=1px,height=1px,top=7000px,left=7000px');
			setTimeout(function () {
				theWindow.close();
			}, 5000);
		}
	});










	console.log("application.js loaded successfully!");

}); // document ready


/* ---- Personalizări mici, mutate din view-urile din core ---- */
$(function () {
  // Subiect issue: maxim 512 caractere (coloana issues.subject e varchar(512))
  $(document).on('focus input', '#issue_subject', function () {
    if ($(this).attr('maxlength') !== '512') { $(this).attr('maxlength', 512); }
  });

  // Bulk edit / lista de issue-uri: % realizat 100 => status 8, altfel status 1
  // (mutat din issues/bulk_edit.html.erb și issues/index.html.erb)
  if ($('body').is('.controller-issues.action-bulk_edit, .controller-issues.action-index')) {
    $(document).on('change', '#issue_done_ratio', function () {
      if ($('#issue_done_ratio').val() == 100) {
        $('#issue_status_id').val(8);
      } else {
        $('#issue_status_id').val(1);
      }
    });
  }

  // Linkurile personalizate din meniul de sus (Grupuri, Notificari, Aproba issue)
  // (în Redmine 7 elementele <li> se adaugă în aceeași listă cu Home, ca să stea pe același rând)
  var $links = $('#sts-top-menu-links');
  if ($links.length) {
    var $menuList = $('#top-menu .general-menu .top-menu__links ul').first();
    if ($menuList.length) {
      $menuList.append($links.find('li'));
    } else {
      $('#top-menu .general-menu .top-menu__links').append($links.children());
    }
    $links.remove();
  }
});

// ---------------------------------------------------------------------------
// STS 7.0: My page cu blocuri încărcate la cerere (vezi lib/sts_customizari/my_page_lazy.rb).
// Fiecare bloc apare doar cu titlul; datele se aduc la click. Blocurile lăsate deschise sunt
// ținute minte în browser (localStorage) și se încarcă singure după ce pagina a apărut.
// Independent de restul JS-ului STS (nu depinde de cheia API).
// ---------------------------------------------------------------------------
(function ($) {
	var KEY = 'sts_mypage_open_blocks';

	function openBlocks() {
		try { return JSON.parse(localStorage.getItem(KEY) || '[]') || []; } catch (e) { return []; }
	}
	function remember(id, open) {
		try {
			var list = $.grep(openBlocks(), function (x) { return x !== id; });
			if (open) { list.push(id); }
			localStorage.setItem(KEY, JSON.stringify(list));
		} catch (e) { /* fără localStorage: blocul doar nu e ținut minte */ }
	}

	function showLoaded($box) {
		$box.find('.sts-block-title').hide();
		$box.find('.sts-block-body').show();
		$box.find('.sts-block-collapse').show();
	}

	function loadBlock($box) {
		var $body = $box.find('.sts-block-body');
		if ($box.data('stsLoaded')) { showLoaded($box); return; }
		if ($box.data('stsLoading')) { return; }
		$box.data('stsLoading', true);
		$body.show().html($('<p class="sts-block-loading"></p>').text($box.data('loading')));
		$.ajax({ url: $box.data('url'), dataType: 'html', cache: false })
			.done(function (html) {
				$body.html(html);
				$box.data('stsLoaded', true);
				showLoaded($box);
			})
			.fail(function () {
				$body.html($('<p class="sts-block-error"></p>').text($box.data('error')));
				$box.find('.sts-block-title').show();
			})
			.always(function () { $box.data('stsLoading', false); });
	}

	$(document).on('click', '.sts-lazy-block .sts-block-load', function (e) {
		e.preventDefault();
		var $box = $(this).closest('.sts-lazy-block');
		remember($box.attr('id'), true);
		loadBlock($box);
	});

	$(document).on('click', '.sts-lazy-block .sts-block-collapse', function (e) {
		e.preventDefault();
		var $box = $(this).closest('.sts-lazy-block');
		remember($box.attr('id'), false);
		$box.find('.sts-block-body').hide();
		$box.find('.sts-block-collapse').hide();
		$box.find('.sts-block-title').show();
	});

	$(function () {
		var open = openBlocks();
		$('.sts-lazy-block').each(function () {
			if ($.inArray(this.id, open) >= 0) { loadBlock($(this)); }
		});
	});
})(jQuery);


// ---------------------------------------------------------------------------
// STS 7.0: lista de watcheri din pagina issue-ului, restrânsă când are mulți utilizatori.
// Titlul „Watchers (N)” devine clicabil și deschide / închide lista. Starea aleasă e ținută
// minte în browser. Lista rămâne în pagină (doar ascunsă), pentru că JS-ul STS o citește
// (ex. „Aproba issue”). Se reaplică după adăugarea / ștergerea unui watcher (AJAX).
// ---------------------------------------------------------------------------
(function ($) {
	var KEY = 'sts_watchers_open', LIMIT = 10;

	function isOpen() {
		try { return localStorage.getItem(KEY) === '1'; } catch (e) { return false; }
	}
	function setOpen(open) {
		try { localStorage.setItem(KEY, open ? '1' : '0'); } catch (e) { /* doar nu se ține minte */ }
	}

	function apply() {
		var $w = $('#watchers');
		if (!$w.length) { return; }
		var $h = $w.children('h3').first(), $ul = $w.children('ul.watchers');
		if (!$h.length || !$ul.length) { return; }
		if ($ul.children('li').length <= LIMIT) {
			$h.removeClass('sts-watchers-toggle sts-open');
			$ul.show();
			return;
		}
		var open = isOpen();
		$h.addClass('sts-watchers-toggle').toggleClass('sts-open', open);
		$ul.toggle(open);
	}

	$(document).on('click', '#watchers h3.sts-watchers-toggle', function () {
		setOpen(!isOpen());
		apply();
	});
	$(function () { apply(); });
	$(document).ajaxComplete(function () { apply(); });
})(jQuery);

// ---------------------------------------------------------------------------
// STS 7.0: Overview proiect - lista de membri se încarcă la click pe „Members (N)”.
// Starea (deschis / închis) e ținută minte în browser; deschisă => se încarcă singură.
// ---------------------------------------------------------------------------
(function ($) {
	var KEY = 'sts_members_open';

	function isOpen() {
		try { return localStorage.getItem(KEY) === '1'; } catch (e) { return false; }
	}
	function setOpen(open) {
		try { localStorage.setItem(KEY, open ? '1' : '0'); } catch (e) { /* doar nu se ține minte */ }
	}

	function load($box) {
		var $body = $box.find('.sts-members-body');
		if ($box.data('stsLoaded')) { $body.show(); return; }
		if ($box.data('stsLoading')) { return; }
		$box.data('stsLoading', true);
		$body.show().html($('<p class="sts-block-loading"></p>').text($box.data('loading')));
		$.ajax({ url: $box.data('url'), dataType: 'html', cache: false })
			.done(function (html) {
				// din răspuns păstrăm doar rândurile cu roluri (titlul există deja)
				var $rows = $('<div>').html(html).find('.members.box > p');
				$body.empty().append($rows);
				$box.data('stsLoaded', true);
			})
			.fail(function () {
				$body.html($('<p class="sts-block-error"></p>').text($box.data('error')));
			})
			.always(function () { $box.data('stsLoading', false); });
	}

	$(document).on('click', '.sts-lazy-members .sts-members-load', function (e) {
		e.preventDefault();
		var $box = $(this).closest('.sts-lazy-members');
		var $body = $box.find('.sts-members-body');
		if ($body.css('display') !== 'none' && $box.data('stsLoaded')) {
			$body.hide();
			$box.removeClass('sts-open');
			setOpen(false);
		} else {
			$box.addClass('sts-open');
			setOpen(true);
			load($box);
		}
	});

	$(function () {
		if (isOpen()) {
			$('.sts-lazy-members').each(function () { $(this).addClass('sts-open'); load($(this)); });
		}
	});
})(jQuery);
