# Puma pentru Redmine STS: mai multe procese, ca o cerere lentă să nu le blocheze pe celelalte.
# Valorile se pot schimba din .env (WEB_CONCURRENCY, RAILS_MAX_THREADS).
workers Integer(ENV.fetch('WEB_CONCURRENCY', 3))
threads_count = Integer(ENV.fetch('RAILS_MAX_THREADS', 5))
threads threads_count, threads_count
preload_app!
port ENV.fetch('PORT', 3000)
environment ENV.fetch('RAILS_ENV', 'production')
