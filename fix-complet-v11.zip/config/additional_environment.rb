# STS: în 3.4.2, linia default_timezone = :local era comentată în config/application.rb,
# deci datele din baza ta sunt salvate în UTC. Păstrăm la fel ca orele să nu se decaleze.
config.active_record.default_timezone = :utc

# DMSF 5.x păstrează documentele prin Active Storage (vezi plugins/redmine_dmsf/README.md, „Active Storage”).
# Redmine 7 nu îl încarcă implicit, așa că îl activăm aici. Fișierele stau în files/dmsf_as (config/storage.yml).
require 'active_storage/engine'
config.active_storage.service = :local
