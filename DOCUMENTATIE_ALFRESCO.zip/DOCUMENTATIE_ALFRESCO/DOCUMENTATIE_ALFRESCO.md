# Documentație tehnică — Platformă ECM: Managementul Documentelor și al Înregistrărilor (Alfresco Community + Governance Services)

## 1. Prezentarea sistemului

### Descriere
Sistemul este o platformă **ECM** (Enterprise Content Management) folosită pentru stocarea, clasificarea, versionarea, căutarea și guvernanța documentelor. Pe lângă managementul documentelor, platforma asigură și **Records Management (RM)** — managementul înregistrărilor cu valoare probatorie: plan de clasificare (file plan), declarare de înregistrări, scheme de retenție și eliminare, blocări (holds), transferuri și pistă de audit dedicată.

Platforma este un sistem **distribuit, bazat pe servicii Java**: un repository central (aplicație Java/Spring pe Tomcat), un motor de căutare separat, servicii de transformare a conținutului, un broker de mesaje și interfețele utilizator. Metadatele sunt păstrate în baza de date relațională, iar fișierele binare în **content store**-ul de pe disc.

### Configurația instalată

| Element | Valoare |
|---------|---------|
| Produs | **Alfresco Content Services 7.4.0 — ediția Community** |
| Modul de guvernanță | **Alfresco Governance Services Community** (Records Management), instalat ca modul peste repository și Share |
| Bază de date | **PostgreSQL** |
| Platformă de execuție | Java 11/17, Apache Tomcat 9 |
| Motor de căutare | Alfresco Search Services (Apache Solr 8) |
| Broker de mesaje | Apache ActiveMQ |
| Transformări | Transform Service (T-Engines: LibreOffice, ImageMagick, PDF Renderer, Tika) + Shared File Store |
| Stocare conținut | Content store pe sistemul de fișiere (`alf_data/contentstore`) |
| Interfețe utilizator | Alfresco Share (inclusiv consola RM) și Alfresco Digital Workspace |

Fiind ediția **Community**, în sistem **nu sunt disponibile** componentele exclusiv Enterprise: Search Enterprise (Elasticsearch), conectorii de stocare S3 / Azure, SAML SSO, modulul de Security Controls (marcaje de securitate și clearance) și certificarea DoD 5015.02. Funcționalitatea de Records Management descrisă mai jos este cea din Governance Services Community.

### Scop
Platforma acoperă întregul ciclu de viață al conținutului: **ingestie → clasificare și metadate → colaborare și versionare → căutare → declarare ca înregistrare → retenție → eliminare sau transfer**, cu trasabilitate și control de acces la nivel de nod.

### Rol în ecosistem
- **Repository central de documente** pentru aplicațiile interne — aplicația de Registratură Electronică folosește Alfresco ca depozit de fișiere și de aspecte/metadate.
- **Sistem de guvernanță a înregistrărilor**, care păstrează documentele pe durata legală de retenție și le elimină controlat la expirare.
- **Punct de integrare** prin API-uri standard (REST, CMIS, WebDAV, AOS).

---

## 2. Funcționalități

### 2.1 Managementul documentelor

| Zonă | Funcționalitate |
|------|-----------------|
| **Repository și model de conținut** | Foldere ierarhice, tipuri și **aspecte** (metadate), modele de conținut personalizate definite în XML, asocieri între noduri |
| **Versionare** | Versiuni majore și minore, istoric complet, revenire la o versiune anterioară, check-in / check-out (blocare document) |
| **Colaborare (Share)** | Site-uri de colaborare, biblioteci de documente, membri și roluri de site, comentarii, activități, calendar, wiki, discuții |
| **Căutare** | Căutare full-text și după metadate, cu limbajele **AFTS** și **CMIS QL**; fațete, evidențiere, căutări salvate |
| **Reguli și acțiuni** | Reguli pe folder (la adăugare, modificare sau ștergere), acțiuni (copiere, mutare, adăugare aspect, transformare, execuție script), scripturi JavaScript server-side |
| **Fluxuri de lucru** | Procese **Activiti** (BPMN 2.0) de aprobare și review, în paralel sau serial, cu sarcini și termene |
| **Transformări și previzualizare** | Generare de previzualizări PDF/imagine, thumbnail-uri și extragere de text, prin Transform Service |
| **Securitate** | Permisiuni pe nod (ACL) cu moștenire, roluri predefinite (Consumer, Contributor, Editor, Collaborator, Coordinator), grupuri și autorități |
| **Trasabilitate** | Audit configurabil, istoric de versiuni, proprietăți `cm:creator`, `cm:modifier`, `cm:created`, `cm:modified` pe fiecare nod |
| **Ciclu de viață** | Coș de gunoi (archive store), ștergere definitivă, curățare programată a conținutului orfan |
| **Interfețe de acces** | Share, Digital Workspace, WebDAV, FTP, IMAP, SMTP inbound și **AOS** (editare directă din MS Office) |

### 2.2 Records Management (Governance Services)

| Zonă | Funcționalitate |
|------|-----------------|
| **File Plan** | Plan de clasificare ierarhic: **categorii de înregistrări**, subcategorii și **dosare** (record folders), cu identificatori unici generați automat |
| **Declarare înregistrări** | Declararea unui document ca **înregistrare** — devine imutabil; sunt suportate și înregistrările **in-place**, care rămân în site-ul de colaborare, dar intră sub guvernanța file plan-ului |
| **Containere speciale** | **Unfiled Records** (înregistrări neclasificate), **Holds** (blocări), **Transfers** (transferuri în curs) |
| **Scheme de eliminare** | Definite pe categorie sau pe dosar, cu pași succesivi: **Cutoff**, **Retain**, **Transfer**, **Accession**, **Destroy**, declanșați pe dată, pe eveniment sau combinat |
| **Evenimente de ciclu de viață** | Evenimente predefinite și personalizate (încheiere caz, obsolescență, document superseded) care declanșează pașii de eliminare |
| **Holds** | Suspendă eliminarea pentru înregistrările și dosarele implicate în litigii sau controale; adăugarea și scoaterea din hold se fac cu motiv înregistrat |
| **Transfer și accession** | Export controlat al înregistrărilor către o arhivă externă sau către autoritatea de arhivare, cu confirmare de transfer |
| **Distrugere** | Distrugerea conținutului la expirarea retenției, cu păstrarea opțională a metadatelor (ghost record) ca dovadă a existenței înregistrării |
| **Metadate de înregistrare** | Identificator unic, dată de declarare, dată de deschidere și de închidere a dosarului, cod de clasificare, referințe între înregistrări |
| **Înregistrări non-electronice** | Evidența documentelor pe hârtie sau pe suport de stocare, cu locație fizică de depozitare |
| **Audit RM** | Pistă de audit dedicată, nemodificabilă, care acoperă toate operațiile asupra înregistrărilor; poate fi filtrată și exportată |
| **Roluri și capabilități** | Roluri RM cu capabilități granulare (declarare, clasificare, eliminare, gestionare hold-uri, administrare file plan) |
| **Rapoarte** | Raport file plan, raport de distrugere, raport de transfer, raport hold |

---

## 3. Utilizatori și roluri

Autorizarea se face pe **permisiuni la nivel de nod** (ACL), prin roluri de repository și de site, la care se adaugă **rolurile RM** aplicabile în file plan.

### Roluri de platformă
- **Administrator** — membrii grupului `ALFRESCO_ADMINISTRATORS` și contul `admin`; administrează utilizatori, grupuri, modele de conținut, subsisteme și job-uri programate.
- **Coordinator / Collaborator / Contributor / Editor / Consumer** — rolurile predefinite de acces pe nod, de la control total până la doar citire.
- **Roluri de site** (Manager, Collaborator, Contributor, Consumer) — se aplică în site-urile de colaborare din Share.
- **Utilizatori sincronizați din directorul de domeniu** — creați și actualizați automat de subsistemul de sincronizare, atunci când autentificarea LDAP/AD este activată.
- **Conturi de serviciu** — folosite de aplicațiile client pentru apeluri server-to-server prin REST și CMIS; cel mai important este contul folosit de aplicația de Registratură Electronică.

### Roluri Records Management
- **Records Management Administrator** — configurează file plan-ul, schemele de eliminare, rolurile, capabilitățile și auditul RM.
- **Records Manager** — clasifică, declară, închide dosare, execută pașii de eliminare și gestionează hold-urile.
- **Records Management Power User** — creează dosare și înregistrări, cu drepturi extinse în zona proprie.
- **Records Management User** — declară și consultă înregistrări, fără drepturi de eliminare.
- **Roluri personalizate** — se definesc în consola RM prin combinarea capabilităților existente.

---

## 4. Date prelucrate

Metadatele și structura se află în baza de date **PostgreSQL**, fișierele binare în content store-ul de pe disc, iar indexul de căutare în Solr.

### Structura bazei de date (repository)
- **alf_store / alf_node / alf_node_properties / alf_node_aspects** — nodurile (documente, foldere, înregistrări), proprietățile și aspectele lor. Store-uri: `workspace://SpacesStore` (conținut curent), `archive://SpacesStore` (coș de gunoi), `versionStore` / `version2Store` (versiuni), `system`.
- **alf_child_assoc / alf_node_assoc** — ierarhia de foldere și asocierile între noduri.
- **alf_content_data / alf_content_url** — referințele către fișierele binare (cale în content store, mărime, mime-type, encoding).
- **alf_transaction / alf_server** — tranzacțiile de modificare, folosite și de indexarea incrementală.
- **alf_qname / alf_namespace** — dicționarul de tipuri, aspecte și proprietăți.
- **alf_access_control_list / alf_acl_member / alf_access_control_entry / alf_permission / alf_authority** — permisiuni, utilizatori și grupuri.
- **alf_audit_app / alf_audit_entry / alf_audit_model / alf_prop_*** — pista de audit, inclusiv auditul RM.
- **act_*** — tabelele motorului de workflow Activiti (definiții de proces, instanțe, sarcini, variabile, istoric).
- **alf_locale, alf_mimetype, alf_encoding, alf_content_clean, alf_applied_patch** — nomenclatoare și evidența patch-urilor de schemă aplicate.

### Modelul de conținut
- **Conținut general:** `cm:content`, `cm:folder`, `cm:person`, `st:site`, `cm:thumbnail`; aspecte: `cm:versionable`, `cm:auditable`, `cm:titled`, `cm:taggable`.
- **Records Management** (namespace `rma` / `rmc`): `rma:filePlan`, `rma:recordCategory`, `rma:recordFolder`, `rma:record`, `rma:dispositionSchedule`, `rma:dispositionActionDefinition`, `rma:dispositionAction`, `rma:hold`, `rma:transfer`, `rma:unfiledRecordContainer`, `rma:nonElectronicDocument`; aspecte: `rma:declaredRecord`, `rma:filePlanComponent`, `rma:vitalRecord`, `rma:cutOff`, `rma:ghosted`.

### Fișiere și index
- **Content store:** `alf_data/contentstore`, cu structură de directoare pe an/lună/zi/oră; conținutul șters trece prin `contentstore.deleted` înainte de curățare.
- **Index de căutare:** colecțiile Solr `alfresco` (conținut curent) și `archive` (coș de gunoi), care conțin textul extras și metadatele nodurilor.

### Date sensibile
- **Documente interne și înregistrări cu valoare probatorie**, inclusiv cele supuse retenției legale.
- **Date cu caracter personal** din conținutul documentelor și din profilurile de utilizator (nume, email, funcție, fotografie).
- **Pista de audit** — evidența accesărilor și modificărilor pe fiecare document.
- **Credențiale** — hash-urile parolelor conturilor interne, parola contului de bind LDAP, credențialele bazei de date și secretul partajat cu Solr, aflate în fișierele de configurare și în variabilele de mediu.

---

## 5. Fluxuri de date și interconectări

### 5.1 Arhitectura sistemului

![Diagramă](docs/diagrams/arhitectura.png)

### 5.2 Ingestia și clasificarea unui document

![Diagramă](docs/diagrams/flux-ingestie-document.png)

### 5.3 Autentificarea

![Diagramă](docs/diagrams/flux-autentificare.png)

### 5.4 Ciclul de viață al unei înregistrări

![Diagramă](docs/diagrams/flux-ciclu-viata-inregistrare.png)

---

## 6. Autentificare

- **Lanț de subsisteme de autentificare** (`authentication.chain`), evaluate în ordinea configurată în `alfresco-global.properties` sau din Admin Console. Subsistemele disponibile în instalare:
  - **alfrescoNtlm** — conturi interne, cu parolele stocate în baza de date; este subsistemul implicit și acoperă contul `admin` și conturile de serviciu;
  - **ldap** / **ldap-ad** — autentificare și **sincronizare** de utilizatori și grupuri din LDAP sau Active Directory (`ldap.authentication.*`, `ldap.synchronization.*`);
  - **kerberos** — SSO în domeniu prin SPNEGO, cu keytab pentru serviciul HTTP;
  - **passthru** — delegarea autentificării către un controler de domeniu;
  - **external** — autentificare delegată unui proxy sau agent SSO, pe baza unui header;
  - **identity-service** — OAuth2 / OpenID Connect cu token JWT, folosit în special de Digital Workspace.
- **Tichete de sesiune:** după autentificare, repository-ul emite un **ticket** (`alf_ticket`), folosit ca alternativă la Basic Auth în apelurile REST și CMIS; durata de valabilitate și numărul de sesiuni sunt configurabile.
- **Autentificarea aplicațiilor client:** HTTP Basic cu cont de serviciu sau ticket obținut prin `POST /authentication/versions/1/tickets`.
- **Share și Digital Workspace** deleagă autentificarea către repository, folosind același lanț de subsisteme.
- **Sincronizarea utilizatorilor** rulează ca job programat (diferențial și complet); conturile șterse în directorul de domeniu pot fi dezactivate automat în Alfresco.
- **SAML 2.0 nu este disponibil** în ediția Community; pentru SSO federat se folosește identity-service sau Kerberos.

---

## 7. Managementul modificărilor

- **Patch-uri de schemă:** la fiecare pornire, repository-ul aplică automat patch-urile de schemă necesare și le înregistrează în `alf_applied_patch`. Înainte de orice actualizare se face copie de siguranță pentru baza de date PostgreSQL, pentru `alf_data` (content store) și pentru fișierele de configurare.
- **Module și add-on-uri:** se instalează ca **AMP** (prin Module Management Tool) sau ca JAR; **Alfresco Governance Services** este instalat astfel, în ambele aplicații (repository și Share). Compatibilitatea modulelor cu versiunea de repository este verificată la pornire, pe baza `module.properties`.
- **Modele de conținut personalizate:** definite în XML și încărcate dinamic (Data Dictionary → Models) sau livrate prin modul. La orice modificare, versiunea modelului trebuie incrementată, iar modificările incompatibile (ștergerea de proprietăți sau tipuri folosite) nu sunt permise.
- **Configurare:** `alfresco-global.properties`, fișierele de subsisteme, configurările de UI din Share Config, plus variabilele de mediu ale containerelor sau ale serviciului Tomcat.
- **Trasabilitatea modificărilor de conținut:**
  - versionarea documentelor, cu istoric complet și comentarii de versiune;
  - auditul configurabil pe aplicații de audit (acces, modificare, ștergere, operații RM);
  - proprietățile `cm:created`, `cm:modified`, `cm:creator`, `cm:modifier` pe fiecare nod;
  - pentru înregistrări, pista de audit RM, nemodificabilă și exportabilă.
- **Reindexare:** după modificări de model, restaurări sau incidente de indexare se rulează reindexarea Solr (completă sau pe interval de tranzacții).
- **Configurațiile și modelele de conținut se țin sub control de versiune**, iar modulele se livrează prin procedura de instalare controlată pe mediile de test și de producție.

---

## 8. Interfețe expuse

### REST API v1 — prefix `/alfresco/api/-default-/public/alfresco/versions/1`
- **Noduri:** `GET/POST/PUT/DELETE /nodes/{id}`, `/nodes/{id}/children`, `/nodes/{id}/content`, `/nodes/{id}/copy`, `/nodes/{id}/move`, `/nodes/{id}/lock`
- **Versiuni:** `/nodes/{id}/versions`, `/nodes/{id}/versions/{versionId}/content`, `revert`
- **Rendition-uri și previzualizare:** `/nodes/{id}/renditions`, `/nodes/{id}/renditions/{id}/content`
- **Site-uri:** `/sites`, `/sites/{id}/members`, `/sites/{id}/containers`
- **Utilizatori și grupuri:** `/people`, `/groups`, `/groups/{id}/members`
- **Partajare și organizare:** `/shared-links`, `/tags`, `/comments`, `/favorites`, `/trashcan`
- **Căutare:** `POST /search/versions/1/search`
- **Sistem:** `/discovery`, `POST /authentication/versions/1/tickets`

### REST API Governance Services — prefix `/alfresco/api/-default-/public/gs/versions/1`
- `GET/POST /file-plans/{id}/categories`, `/record-categories/{id}`, `/record-categories/{id}/children`
- `GET/POST /record-folders/{id}/records`, `/record-folders/{id}`
- `POST /records/{id}/file` — depunerea unei înregistrări în file plan
- `POST /files/{id}/declare` — declararea in-place a unui document ca înregistrare
- `/unfiled-containers/{id}/children`, `/unfiled-record-folders/{id}/children`
- `/transfer-containers/{id}`, `/transfers/{id}/children`
- `/holds`, `POST /holds/{id}/children`, `DELETE /holds/{id}/children/{id}`
- `/gs-sites`

### Alte interfețe
- **CMIS 1.0 / 1.1** — binding AtomPub (`/alfresco/api/-default-/public/cmis/versions/1.1/atom`) și Browser (`.../browser`).
- **Web Scripts** — servicii REST personalizabile la `/alfresco/service/...`.
- **WebDAV** — `/alfresco/webdav`, pentru montare ca unitate de rețea.
- **AOS (Alfresco Office Services)** — `/alfresco/aos`, pentru editare directă din MS Office.
- **FTP, IMAP, SMTP inbound** — acces și ingestie prin protocoale de fișiere și email.
- **ActiveMQ** — evenimente de repository (`alfresco.repo.event2`) pentru integrări event-driven.

---

## 9. Tehnologii

**Platformă și backend**
- **Java 11 / 17**, **Spring Framework**, **Apache Tomcat 9**
- Repository Alfresco Community 7.4.0 (`alfresco.war`) și modulele **Alfresco Governance Services Community** (repository și Share)
- **Activiti** — motor de workflow BPMN 2.0
- **Apache Chemistry / OpenCMIS** — suport CMIS
- **Apache Tika**, **LibreOffice**, **ImageMagick**, **Alfresco PDF Renderer** — transformări, rulate în T-Engines separate

**Căutare și mesagerie**
- **Alfresco Search Services** (Apache Solr)
- **Apache ActiveMQ** și **Shared File Store** (fișiere temporare pentru transformări)

**Interfețe utilizator**
- **Alfresco Share** — Spring Surf, FreeMarker, YUI/jQuery; include consola de Records Management
- **Alfresco Digital Workspace** — Angular, pe baza **ADF** (Alfresco Development Framework)

**Stocare și date**
- **PostgreSQL** pentru metadate, structură, permisiuni și audit
- Content store pe sistemul de fișiere (`alf_data/contentstore`)

**Operare**
- Proxy invers în fața aplicațiilor web, monitorizare prin JMX și log-uri Log4j2
- Copii de siguranță corelate: baza de date PostgreSQL + `alf_data`, realizate în aceeași fereastră de timp

---

## 10. Integrări

| Sistem | Interfață | Scop | Autentificare |
|--------|-----------|------|----------------|
| **Aplicația de Registratură Electronică** | REST API v1 (`/nodes`, `/search`, aspecte, permisiuni) | Încărcarea documentelor, sincronizarea metadatelor, link-uri de partajare, previzualizare | cont de serviciu Alfresco (Basic sau ticket) |
| **Active Directory / LDAP** | LDAP / LDAPS | Autentificarea și sincronizarea utilizatorilor și grupurilor | bind cu cont de serviciu |
| **Server SMTP / IMAP** | SMTP, IMAP | Notificări pe email; ingestia documentelor primite pe email | cont dedicat de email |
| **Alfresco Search Services (Solr)** | HTTP, port 8983 | Indexarea și interogarea conținutului | secret partajat (`solr.sharedSecret`) |
| **ActiveMQ** | protocol OpenWire / AMQP | Transformări asincrone și evenimente de repository | cont de broker |
| **Transform Service (T-Engines)** | HTTP + Shared File Store | Generarea de previzualizări, thumbnail-uri și extragerea textului | intern, în rețeaua serviciilor |
| **Alte aplicații interne** | REST v1, **CMIS**, `gs/versions/1` | Ingestia și consultarea documentelor și înregistrărilor | cont de serviciu (Basic / ticket) |
| **Arhivă externă / autoritate de arhivare** | export de transfer RM | Transferul și accessionul înregistrărilor la expirarea retenției | procedură controlată, cu confirmare de transfer |

---

## Anexă — parametri specifici instalării

Valorile de mai jos se completează din configurația mediului de producție și se actualizează la fiecare modificare de infrastructură.

| Parametru | Valoare |
|-----------|---------|
| Adresa publică a platformei (Share / Digital Workspace) | |
| Adresa internă a repository-ului (API) | |
| Server și instanță PostgreSQL, nume bază de date | |
| Cale content store (`dir.root` / `alf_data`) | |
| Adresa serverului Solr și portul | |
| Adresa brokerului ActiveMQ | |
| Subsistemele de autentificare active și ordinea lor | |
| Server LDAP / AD, base DN, cont de bind | |
| Server SMTP / cont IMAP de ingestie | |
| Module și add-on-uri instalate (versiuni) | |
| Conturi de serviciu și aplicațiile care le folosesc | |
| Scheme de retenție configurate în file plan | |
| Procedura și frecvența copiilor de siguranță | |
| Modul de implementare (containere sau instalare pe server dedicat) | |
