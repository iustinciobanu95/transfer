module StsCustomizari
  # Două niveluri de vizibilitate în plus pentru roluri, ca în Redmine 3.4.2 STS:
  #   own_watch             – issue-uri create de, asignate sau urmărite (watch) de utilizator
  #   own_watch_contributed – ca mai sus + issue-uri la care utilizatorul a scris în istoric
  #
  # Pentru celelalte valori (all, default, own) se folosește codul din Redmine 7 (super).
  module IssueVisibilityPatch
    EXTRA = %w(own_watch own_watch_contributed).freeze

    module ClassMethods
      def visible_condition(user, options={})
        return super unless user.id && user.logged?

        # Rolurile STS sunt tratate aici; restul trec prin codul din core.
        # Pentru rolurile own_watch / own_watch_contributed, în ramura rolului rămâne doar
        # „creat de / asignat lui”; partea „urmărit / comentat” se adaugă o singură dată, mai jos.
        tracker_sql = lambda do |role, sql|
          return sql if role.permissions_all_trackers?(:view_issues)

          tracker_ids = role.permissions_tracker_ids(:view_issues)
          tracker_ids.any? ? "(#{sql} AND #{table_name}.tracker_id IN (#{tracker_ids.join(',')}))" : '1=0'
        end

        condition = Project.allowed_to_condition(user, :view_issues, options) do |role, usr|
          if EXTRA.include?(role.issues_visibility)
            tracker_sql.call(role, StsCustomizari::IssueVisibilityPatch.own_sql(usr, table_name))
          else
            StsCustomizari::IssueVisibilityPatch.core_role_sql(role, usr, table_name, connection)
          end
        end

        # „Urmărit” (own_watch și own_watch_contributed) și „comentat” (own_watch_contributed):
        # lista de id-uri apare o singură dată în SQL, împreună cu proiectele / trackerele rolurilor
        # respective (aceeași construcție Redmine, cu restul rolurilor pe „1=0”).
        # v2 punea lista în fiecare ramură de rol (de 4 ori, ~1 MB de SQL); v3 folosea EXISTS,
        # verificat pentru fiecare rând - lent pe căutările care parcurg mult din tabel.
        extra = []
        { 'watched' => EXTRA, 'contributed' => %w(own_watch_contributed) }.each do |kind, visibilities|
          next unless StsCustomizari::IssueVisibilityPatch.user_has_visibility?(user, visibilities)

          ids = StsCustomizari::IssueVisibilityPatch.cached_ids(kind.to_sym, user)
          next if ids.empty?

          roles_condition = Project.allowed_to_condition(user, :view_issues, options) do |role, _usr|
            visibilities.include?(role.issues_visibility) ? tracker_sql.call(role, '1=1') : '1=0'
          end
          extra << "(#{StsCustomizari::IssueVisibilityPatch.ids_condition(table_name, ids)} AND #{roles_condition})"
        end
        condition = "(#{([condition] + extra).join(' OR ')})" if extra.any?

        # Filtru în plus, care nu schimbă rezultatul: dacă TOATE rolurile prin care utilizatorul vede
        # issue-uri sunt own / own_watch / own_watch_contributed, orice issue vizibil e creat de el,
        # asignat lui (sau grupului lui), urmărit sau comentat de el. Condiția aceasta, pusă în față
        # cu AND, poate folosi indecșii (author_id, assigned_to_id, id), așa că MySQL citește doar
        # issue-urile utilizatorului, nu tot tabelul (~1,1 milioane de rânduri) la fiecare listă.
        prefilter = StsCustomizari::IssueVisibilityPatch.prefilter_sql(user, table_name)
        prefilter ? "((#{prefilter}) AND #{condition})" : condition
      end
    end

    def visible?(usr=nil)
      (usr || User.current).allowed_to?(:view_issues, project) do |role, user|
        visible =
          if user.logged?
            case role.issues_visibility
            when 'all'
              true
            when 'default'
              !is_private? || (author == user || user.is_or_belongs_to?(assigned_to))
            when 'own'
              author == user || user.is_or_belongs_to?(assigned_to)
            when 'own_watch'
              author == user || user.is_or_belongs_to?(assigned_to) || watched_by?(user)
            when 'own_watch_contributed'
              author == user || user.is_or_belongs_to?(assigned_to) || watched_by?(user) ||
                journals.where(user_id: user.id).exists?
            else
              false
            end
          else
            !is_private?
          end
        unless role.permissions_all_trackers?(:view_issues)
          visible &&= role.permissions_tracker_ids?(:view_issues, tracker_id)
        end
        visible
      end
    end

    # Id-urile issue-urilor urmărite / comentate de utilizator se citesc o singură dată pe cerere
    # (Current se golește automat la fiecare cerere HTTP) și se pun direct în SQL.
    # Înainte erau subinterogări „id IN (SELECT ... FROM watchers/journals)” legate prin OR,
    # pe care MySQL le evalua pentru fiecare issue: pentru un utilizator membru în toate
    # proiectele, adică pentru ~1,1 milioane de rânduri la fiecare listă (My page: peste 1 minut).
    class Current < ActiveSupport::CurrentAttributes
      attribute :ids_cache
    end

    def self.cached_ids(kind, user)
      Current.ids_cache ||= {}
      Current.ids_cache[[kind, user.id]] ||=
        case kind
        when :watched
          Watcher.where(user_id: user.id, watchable_type: 'Issue').distinct.pluck(:watchable_id)
        when :contributed
          Journal.where(user_id: user.id, journalized_type: 'Issue').distinct.pluck(:journalized_id)
        end
    end

    RESTRICTIVE = (%w(own) + EXTRA).freeze

    # Întoarce condiția-filtru sau nil, dacă vreun rol al utilizatorului permite mai mult
    # (all / default) sau utilizatorul e admin.
    def self.prefilter_sql(user, table)
      return nil if user.admin?

      Current.ids_cache ||= {}
      visibilities = Current.ids_cache[[:visibilities, user.id]] ||= begin
        roles = user.project_ids_by_role.keys.select { |r| r.allowed_to?(:view_issues) }
        builtin = user.builtin_role
        if builtin.allowed_to?(:view_issues)
          # rolul Non member contează doar dacă există proiecte publice în care nu e membru
          member_project_ids = Member.where(user_id: user.id).select(:project_id)
          if Project.where(is_public: true).where.not(id: member_project_ids).exists?
            roles << builtin
          end
        end
        roles.map(&:issues_visibility).uniq
      end
      return nil if visibilities.empty? || (visibilities - RESTRICTIVE).any?

      user_ids = ([user.id] + user.groups.pluck(:id)).compact
      parts = ["#{table}.author_id = #{user.id}", "#{table}.assigned_to_id IN (#{user_ids.join(',')})"]
      ids = []
      ids |= cached_ids(:watched, user) if (visibilities & EXTRA).any?
      ids |= cached_ids(:contributed, user) if visibilities.include?('own_watch_contributed')
      # Peste ~20.000 de valori, MySQL depășește range_optimizer_max_mem_size și renunță la
      # indecși pentru toată interogarea; atunci nu folosim filtrul (rezultatul e același).
      return nil if ids.size > PREFILTER_MAX_IDS

      parts << ids_condition(table, ids, sargable: true) if ids.any?
      parts.join(' OR ')
    end

    PREFILTER_MAX_IDS = 20_000

    # sargable: true  -> „issues.id IN (...)”: MySQL poate folosi cheia primară (doar în filtrul din față).
    # sargable: false -> „(issues.id + 0) IN (...)”: aceeași verificare, rând cu rând (căutare binară
    #   în listă), dar MySQL nu mai analizează lista ca interval de index. În condiția pe roluri, lista
    #   apare de mai multe ori (un rol = o ramură) și poate avea zeci de mii de valori; analizată ca
    #   index, depășea memoria optimizatorului și MySQL citea tot tabelul, ignorând și filtrele bune
    #   ale listei (ex. „asignat mie”).
    def self.ids_condition(table, ids, sargable: false)
      return '1=0' if ids.empty?

      column = sargable ? "#{table}.id" : "(#{table}.id + 0)"
      "#{column} IN (#{ids.map(&:to_i).join(',')})"
    end

    # Condiția pe rol (în fiecare ramură a rolurilor): EXISTS corelat pe watchers / journals.
    # v1-v2 puneau aici lista de id-uri (la unii utilizatori 35.000-40.000 de numere, repetată
    # pentru fiecare rol): fiecare interogare avea peste 1 MB de SQL, construit în Ruby și citit
    # de MySQL de zeci de ori pe My page. EXISTS e scurt și, pentru fiecare issue verificat,
    # caută direct în indecșii (watchable_id, watchable_type, user_id) / (journalized_id, ...).
    # „Creat de utilizator sau asignat lui / grupurilor lui” (partea comună a rolurilor STS)
    def self.own_sql(user, table)
      user_ids = ([user.id] + user.groups.pluck(:id)).compact
      "(#{table}.author_id = #{user.id} OR #{table}.assigned_to_id IN (#{user_ids.join(',')}))"
    end

    # Are utilizatorul vreun rol (cu view_issues) cu una dintre vizibilitățile date?
    def self.user_has_visibility?(user, visibilities)
      Current.ids_cache ||= {}
      roles = Current.ids_cache[[:roles, user.id]] ||= begin
        list = user.project_ids_by_role.keys.select { |r| r.allowed_to?(:view_issues) }
        list << user.builtin_role if user.builtin_role.allowed_to?(:view_issues) # Non member
        list.map(&:issues_visibility).uniq
      end
      (roles & visibilities).any?
    end

    def self.sts_visibility_sql(visibility, user, table)
      user_ids = ([user.id] + user.groups.pluck(:id)).compact
      parts = [
        "#{table}.author_id = #{user.id}",
        "#{table}.assigned_to_id IN (#{user_ids.join(',')})",
        "EXISTS (SELECT 1 FROM #{Watcher.table_name} sts_w WHERE sts_w.watchable_id = #{table}.id " \
          "AND sts_w.watchable_type = 'Issue' AND sts_w.user_id = #{user.id})"
      ]
      if visibility == 'own_watch_contributed'
        parts << "EXISTS (SELECT 1 FROM #{Journal.table_name} sts_j WHERE sts_j.journalized_id = #{table}.id " \
                 "AND sts_j.journalized_type = 'Issue' AND sts_j.user_id = #{user.id})"
      end
      "(#{parts.join(' OR ')})"
    end

    # Copie a logicii din Issue.visible_condition (Redmine 7.0) pentru all / default / own,
    # folosită doar pentru rolurile care nu au o valoare STS.
    def self.core_role_sql(role, user, table, connection)
      sql =
        case role.issues_visibility
        when 'all'
          '1=1'
        when 'default'
          user_ids = [user.id] + user.groups.pluck(:id).compact
          "(#{table}.is_private = #{connection.quoted_false} " \
            "OR #{table}.author_id = #{user.id} " \
            "OR #{table}.assigned_to_id IN (#{user_ids.join(',')}))"
        when 'own'
          user_ids = [user.id] + user.groups.pluck(:id).compact
          "(#{table}.author_id = #{user.id} OR " \
            "#{table}.assigned_to_id IN (#{user_ids.join(',')}))"
        else
          '1=0'
        end
      unless role.permissions_all_trackers?(:view_issues)
        tracker_ids = role.permissions_tracker_ids(:view_issues)
        sql = tracker_ids.any? ? "(#{sql} AND #{table}.tracker_id IN (#{tracker_ids.join(',')}))" : '1=0'
      end
      sql
    end
  end
end
