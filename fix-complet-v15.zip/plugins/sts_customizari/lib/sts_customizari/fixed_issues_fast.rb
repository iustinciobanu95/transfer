module StsCustomizari
  # Roadmap / pagina versiunii: bara de progres a fiecărei versiuni (FixedIssuesExtension din
  # app/models/version.rb). În Redmine 7, procentul se calculează în Ruby: încarcă TOATE issue-urile
  # versiunii (de 3 ori) și, pentru fiecare issue-părinte, face o interogare separată
  # (total_estimated_hours = suma pe subtask-uri, cu vizibilitate). La STS aproape toate issue-urile
  # au copii, deci mii de interogări pe versiune => Roadmap-ul depășea timpul proxy-ului.
  #
  # Aici același calcul se face în SQL, cu 2 interogări pe versiune:
  #   - media orelor estimate (> 0) ale issue-urilor versiunii (1 dacă nu are niciuna);
  #   - pe deschise / închise: suma ponderilor (ore estimate sau media) x 100 / x % realizat.
  # Diferență față de Redmine: pentru un issue-părinte se ia estimated_hours al lui, nu suma
  # recalculată pe subtask-uri. Dacă orele estimate nu se folosesc (cazul obișnuit la STS),
  # rezultatul e identic. Numărul de issue-uri al versiunii se calculează o singură dată.
  module FixedIssuesFast
    # Rezultatul e ținut minte doar pe obiectul care l-a calculat. O relație derivată
    # (ex. .group(:status)) e o copie (clone) care moștenește variabilele, de aceea
    # verificăm și object_id - altfel copia ar întoarce numărul în loc de rezultatul ei.
    def count(*args, **kwargs, &block)
      return super if !args.empty? || !kwargs.empty? || block
      return @sts_count if @sts_count_owner == object_id

      result = super
      @sts_count_owner = object_id
      @sts_count = result
    end

    private

    def estimated_average
      sts_progress_stats[:avg]
    end

    def issues_progress(open)
      @issues_progress ||= {}
      @issues_progress[open] ||= begin
        issues_count = open_count + closed_count
        if issues_count > 0
          stats = sts_progress_stats
          done = open ? stats[:done_open] : stats[:done_closed]
          done / (stats[:avg] * issues_count)
        else
          0
        end
      end
    end

    def sts_progress_stats
      @sts_progress_stats = nil unless @sts_progress_owner == object_id
      @sts_progress_owner = object_id
      @sts_progress_stats ||= begin
        issues = Issue.table_name
        statuses = IssueStatus.table_name
        est = "#{issues}.estimated_hours"

        avg = unscope(:order).where("#{est} > 0").pick(Arel.sql("AVG(#{est})")).to_f
        avg = 1.0 unless avg > 0

        weight = "(CASE WHEN #{est} > 0 THEN #{est} ELSE #{avg} END)"
        rows = unscope(:order).joins(:status).group("#{statuses}.is_closed").
          pluck(Arel.sql("#{statuses}.is_closed"),
                Arel.sql("SUM(#{weight} * 100)"),
                Arel.sql("SUM(#{weight} * COALESCE(#{issues}.done_ratio, 0))"))

        done_open = 0.0
        done_closed = 0.0
        rows.each do |is_closed, weighted_full, weighted_done|
          if [true, 1, '1', 't'].include?(is_closed)
            done_closed += weighted_full.to_f
          else
            done_open += weighted_done.to_f
          end
        end
        {:avg => avg, :done_open => done_open, :done_closed => done_closed}
      end
    end
  end
end
