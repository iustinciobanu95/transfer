module StsCustomizari
  # Roadmap (versions#index): după ce Redmine a ales versiunile, calculăm dintr-o singură
  # interogare (grupată pe versiune și deschis/închis) tot ce afișează bara de progres a
  # fiecărei versiuni: număr de issue-uri, deschise, închise, procent închis / realizat.
  # Fără asta, fiecare versiune făcea 4 interogări cu verificarea de vizibilitate
  # (la un utilizator ca manuela: ~200 de interogări, ~26 s).
  # Valorile se pun pe relația version.visible_fixed_issues, pe care o folosește view-ul,
  # deci pagina arată exact la fel. Formulele sunt cele din FixedIssuesFast.
  module RoadmapPreload
    # Numărul de issue-uri deschise pe versiune (pentru „versiune terminată?”, Version#completed?),
    # calculat pentru toate versiunile dintr-o singură interogare, înainte ca Redmine să le parcurgă.
    class Current < ActiveSupport::CurrentAttributes
      attribute :open_counts
    end

    # Prepend pe Version: folosește numărul calculat mai sus, dacă există.
    module VersionOpenCount
      def open_issues_count
        counts = StsCustomizari::RoadmapPreload::Current.open_counts
        return counts[id] if counts && counts.key?(id)

        super
      end
    end

    def index
      if request.format.html? && @project
        StsCustomizari::RoadmapPreload.preload_open_counts(@project)
      end
      super
      if request.format.html? && @versions.present?
        StsCustomizari::RoadmapPreload.preload(@versions)
      end
    end

    CLOSED = [true, 1, '1', 't'].freeze

    def self.preload_open_counts(project)
      ids = project.shared_versions.pluck(:id) | project.rolled_up_versions.pluck(:id)
      return if ids.empty?

      counts = Issue.open.where(:fixed_version_id => ids).group(:fixed_version_id).count
      Current.open_counts = ids.index_with { |id| counts[id].to_i }
    end

    def self.preload(versions)
      issues = Issue.table_name
      statuses = IssueStatus.table_name
      est = "#{issues}.estimated_hours"
      done = "COALESCE(#{issues}.done_ratio, 0)"

      rows = Issue.visible.where(:fixed_version_id => versions.map(&:id)).joins(:status).
        group("#{issues}.fixed_version_id", "#{statuses}.is_closed").
        pluck(Arel.sql("#{issues}.fixed_version_id"),
              Arel.sql("#{statuses}.is_closed"),
              Arel.sql("COUNT(*)"),
              Arel.sql("SUM(CASE WHEN #{est} > 0 THEN 1 ELSE 0 END)"),
              Arel.sql("SUM(CASE WHEN #{est} > 0 THEN #{est} ELSE 0 END)"),
              Arel.sql("SUM(CASE WHEN #{est} > 0 THEN #{est} * #{done} ELSE 0 END)"),
              Arel.sql("SUM(CASE WHEN #{est} > 0 THEN 0 ELSE #{done} END)"))

      data = {}
      rows.each do |version_id, is_closed, count, n_est, sum_est, est_done, done_no_est|
        d = data[version_id] ||= {:open => 0, :closed => 0, :n_est => 0, :sum_est => 0.0,
                                  :est_closed => 0.0, :no_est_closed => 0,
                                  :est_done_open => 0.0, :done_no_est_open => 0.0}
        count = count.to_i
        d[:n_est] += n_est.to_i
        d[:sum_est] += sum_est.to_f
        if CLOSED.include?(is_closed)
          d[:closed] += count
          d[:est_closed] += sum_est.to_f
          d[:no_est_closed] += count - n_est.to_i
        else
          d[:open] += count
          d[:est_done_open] += est_done.to_f
          d[:done_no_est_open] += done_no_est.to_f
        end
      end

      versions.each do |version|
        d = data[version.id] || {:open => 0, :closed => 0, :n_est => 0, :sum_est => 0.0,
                                 :est_closed => 0.0, :no_est_closed => 0,
                                 :est_done_open => 0.0, :done_no_est_open => 0.0}
        avg = d[:n_est] > 0 ? d[:sum_est] / d[:n_est] : 1.0
        stats = {
          :avg => avg,
          :done_closed => (d[:est_closed] + avg * d[:no_est_closed]) * 100,
          :done_open => d[:est_done_open] + avg * d[:done_no_est_open]
        }

        rel = version.visible_fixed_issues
        rel.instance_variable_set(:@sts_count_owner, rel.object_id)
        rel.instance_variable_set(:@sts_count, d[:open] + d[:closed])
        rel.instance_variable_set(:@open_count, d[:open])
        rel.instance_variable_set(:@closed_count, d[:closed])
        rel.instance_variable_set(:@sts_progress_owner, rel.object_id)
        rel.instance_variable_set(:@sts_progress_stats, stats)
      end
    end
  end
end
