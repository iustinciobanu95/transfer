module StsCustomizari
  # Aplică modificările care în 3.4.2 erau făcute direct în fișierele din core.
  module Patches
    VISIBILITY_OPTIONS = [
      ['own_watch', :label_issues_visibility_own_watch],
      ['own_watch_contributed', :label_issues_visibility_own_watch_contributed]
    ].freeze

    SUBJECT_MAX_LENGTH = 512 # issues.subject este varchar(512) în baza STS

    def self.apply
      patch_role_visibility_options
      patch_issue_visibility
      patch_issue_subject_length
      patch_my_page
      patch_users_api
      patch_api_ok_status
      patch_my_page_lazy
      patch_project_overview
      patch_fixed_issues
      patch_roadmap
    end

    # app/controllers/versions_controller.rb: Roadmap - progresul tuturor versiunilor dintr-o interogare
    def self.patch_roadmap
      unless Version.ancestors.include?(RoadmapPreload::VersionOpenCount)
        Version.prepend RoadmapPreload::VersionOpenCount
      end
      return if VersionsController.ancestors.include?(RoadmapPreload)

      VersionsController.prepend RoadmapPreload
    end

    # app/models/version.rb: progresul versiunilor (Roadmap) calculat în SQL, nu issue cu issue
    def self.patch_fixed_issues
      ::Version # FixedIssuesExtension e definit în app/models/version.rb; îl încărcăm întâi
      return if FixedIssuesExtension.ancestors.include?(FixedIssuesFast)

      FixedIssuesExtension.prepend FixedIssuesFast
    end

    # app/controllers/projects_controller.rb: Overview proiect cu o singură interogare + cache 10 minute
    def self.patch_project_overview
      return if ProjectsController.ancestors.include?(ProjectOverviewPatch)

      ProjectsController.prepend ProjectOverviewPatch
    end

    # app/helpers/my_helper.rb: blocurile de pe My page se încarcă la cerere (vezi MyPageLazy)
    def self.patch_my_page_lazy
      return if MyHelper.ancestors.include?(MyPageLazy)

      MyHelper.prepend MyPageLazy
    end

    # app/controllers/application_controller.rb: PUT/DELETE/POST prin API răspund 200 cu corp gol,
    # ca în 3.4.2, nu 204 ca în Redmine 7. JavaScript-ul STS are după multe PUT-uri cod de forma
    # .done(function (data) { ... data.issue.id ... }): cu 200 gol jQuery apela .fail și codul nu rula;
    # cu 204 jQuery apelează .done, data e undefined și scriptul se oprește cu eroare
    # (ex. „Aproba issue” rămânea la „Loading...” fără să creeze subtask-urile).
    module ApiOkStatus
      private

      def render_api_ok
        render_api_head :ok
      end
    end

    def self.patch_api_ok_status
      return if ApplicationController.ancestors.include?(ApiOkStatus)

      ApplicationController.prepend ApiOkStatus
    end

    # app/controllers/users_controller.rb: /users/:id.json fără numărătorile de issue-uri (vezi UsersControllerPatch)
    def self.patch_users_api
      return if UsersController.ancestors.include?(UsersControllerPatch)

      UsersController.prepend UsersControllerPatch
    end

    # app/models/role.rb: două opțiuni noi la „Issues visibility”
    def self.patch_role_visibility_options
      VISIBILITY_OPTIONS.each do |option|
        unless Role::ISSUES_VISIBILITY_OPTIONS.any? { |o| o.first == option.first }
          Role::ISSUES_VISIBILITY_OPTIONS << option
        end
      end

      # validates_inclusion_of din Role a fost creat cu lista inițială; îi adăugăm valorile noi
      Role.validators_on(:issues_visibility).each do |validator|
        next unless validator.is_a?(ActiveModel::Validations::InclusionValidator)

        list = validator.options[:in]
        next unless list.is_a?(Array)

        VISIBILITY_OPTIONS.each { |option| list << option.first unless list.include?(option.first) }
      end
    end

    # app/models/issue.rb: vizibilitatea pentru own_watch / own_watch_contributed
    def self.patch_issue_visibility
      return if Issue.included_modules.include?(IssueVisibilityPatch)

      Issue.prepend IssueVisibilityPatch
      Issue.singleton_class.prepend IssueVisibilityPatch::ClassMethods
    end

    # app/models/issue.rb: subiect de maxim 512 caractere în loc de 255
    def self.patch_issue_subject_length
      validators = Issue.validators_on(:subject).grep(ActiveModel::Validations::LengthValidator)
      return if validators.any? { |v| v.options[:maximum] == SUBJECT_MAX_LENGTH }

      validators.each do |validator|
        Issue.skip_callback(:validate, :before, validator, raise: false)
        Issue._validators[:subject].delete(validator)
      end
      Issue.validates_length_of :subject, maximum: SUBJECT_MAX_LENGTH
    end

    # lib/redmine/my_page.rb: până la 10 blocuri „Issues” pe My page (în loc de 3)
    def self.patch_my_page
      block = Redmine::MyPage::CORE_BLOCKS['issuequery']
      block[:max_occurs] = 10 if block && !block.frozen?
    end
  end
end
