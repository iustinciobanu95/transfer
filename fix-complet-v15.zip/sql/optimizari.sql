-- Optimizări pentru baza Redmine STS după migrarea la 7.0 (MySQL 8).
-- Instalarea nouă: ./scripts/optimizeaza.sh (migreaza.sh îl rulează singur după migrare).
-- Direct pe serverul MySQL: mysql --force -u root -p <baza> < sql/optimizari.sql
-- (--force: continuă peste indecșii care există deja, „Duplicate key name”). Se poate rula din nou oricând.
-- Indecșii se creează online (ALGORITHM=INPLACE, LOCK=NONE); pe 1,1 milioane de issue-uri durează câteva minute.

-- 1. Statistici actualizate pentru optimizator (după migrare se schimbă mult structura)
ANALYZE TABLE issues, journals, journal_details, projects, enabled_modules, members, member_roles,
              watchers, custom_values, attachments, issue_statuses, users, tokens, settings;

-- 2. Verificarea „modulul issue_tracking e activ în proiect” (EXISTS din orice listă de issue-uri)
CREATE INDEX idx_sts_enabled_modules_project_name ON enabled_modules (project_id, name) ALGORITHM=INPLACE LOCK=NONE;

-- 3. Numărătorile pe utilizator (issue-uri asignate / raportate, deschise sau nu)
CREATE INDEX idx_sts_issues_author_status   ON issues (author_id, status_id)      ALGORITHM=INPLACE LOCK=NONE;
CREATE INDEX idx_sts_issues_assigned_status ON issues (assigned_to_id, status_id) ALGORITHM=INPLACE LOCK=NONE;

-- 4. Listele de issue-uri pe proiect filtrate după status (cea mai folosită combinație)
CREATE INDEX idx_sts_issues_project_status  ON issues (project_id, status_id)     ALGORITHM=INPLACE LOCK=NONE;

-- 5. (v2) Indecși „acoperitori”: numărătorile și listele filtrate după autor / asignat / tracker
--    se calculează direct din index, fără să citească rândurile din issues
--    (din jurnalul de interogări lente: COUNT(*) pe autor 2-4 s, Overview proiect ~2 s).
CREATE INDEX idx_sts_issues_author_cover    ON issues (author_id, status_id, tracker_id, project_id)      ALGORITHM=INPLACE LOCK=NONE;
CREATE INDEX idx_sts_issues_assigned_cover  ON issues (assigned_to_id, status_id, tracker_id, project_id) ALGORITHM=INPLACE LOCK=NONE;
CREATE INDEX idx_sts_issues_project_tracker ON issues (project_id, tracker_id, status_id)                 ALGORITHM=INPLACE LOCK=NONE;

-- 6. (v3) Vizibilitatea own_watch / own_watch_contributed verifică pentru fiecare issue dacă
--    utilizatorul îl urmărește sau l-a comentat; cu acești indecși verificarea se face doar din index.
CREATE INDEX idx_sts_watchers_issue_user ON watchers (watchable_id, watchable_type, user_id)       ALGORITHM=INPLACE LOCK=NONE;
CREATE INDEX idx_sts_journals_issue_user ON journals (journalized_id, journalized_type, user_id) ALGORITHM=INPLACE LOCK=NONE;

-- 7. (v15) Roadmap: numărul de issue-uri deschise / închise pe fiecare versiune, direct din index.
CREATE INDEX idx_sts_issues_version_status ON issues (fixed_version_id, status_id) ALGORITHM=INPLACE LOCK=NONE;
