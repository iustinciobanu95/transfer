# Fișă tehnică — Aplicație Management Proiecte / Tichete (Redmine)

## 1. Prezentare generală a sistemului

### Ce este
**Redmine** este o aplicație **open-source** (licență **GPL v2**) pentru managementul proiectelor și urmărirea tichetelor (issue tracking), cu module de pontaj, planificare, documentație wiki și integrare cu repository-uri de cod. Arhitectural este o **aplicație monolitică Ruby on Rails**, cu interfață randată pe server (HTML + jQuery), fără aplicație SPA separată; datele stau într-o bază de date relațională, iar atașamentele pe sistemul de fișiere al serverului.

### Versiunea analizată
Documentul descrie **Redmine 3.4.2**, lansată în **iulie 2017**, rulând pe **Ruby on Rails 4.2** și **Ruby 1.9.3 – 2.4**, cu bază de date **MySQL / PostgreSQL / SQL Server / SQLite3**. Detalii complete despre stiva tehnologică sunt în secțiunea 9, iar observațiile privind suportul și actualizarea versiunii în secțiunea 7.

### Scop
Gestionarea centralizată a **proiectelor, sarcinilor și solicitărilor** (tichete / issues): înregistrare, atribuire, urmărire pe fluxuri de lucru (workflow), estimare și pontare timp, documentare (wiki, documente, fișiere) și raportare.

### Rol în ecosistem
- **Sistem de ticketing / helpdesk intern** și de urmărire a activităților pe proiecte.
- **Punct de integrare** cu alte aplicații interne prin **API REST** (ex.: aplicația Registratură Electronică / Alfresco, care șterge issue-uri asociate documentelor prin `X-Redmine-API-Key`).
- **Bază de cunoștințe** (wiki pe proiect) și arhivă de discuții (forumuri, știri).

### Notă privind datele specifice instalării
Câmpurile marcate în document cu `<de completat>` (adrese de servere, conturi, SGBD, plugin-uri instalate) depind de instalarea locală și trebuie verificate pe mediul de producție înainte de folosirea fișei ca document oficial.

---

## 2. Funcționalități principale

| Zonă | Funcționalitate |
|------|-----------------|
| **Proiecte** | Proiecte și subproiecte (ierarhie), module activabile per proiect, membri și roluri per proiect, proiecte publice/private, arhivare/închidere proiect |
| **Tichete (issues)** | Creare/editare, trackere (Bug, Feature, Support etc.), stări, priorități, categorii, versiuni țintă, subtichete (părinte-copil), relații între tichete (blochează, precede, duplicat, legat), observatori (watchers), note private |
| **Workflow** | Tranziții de stare configurabile per rol × tracker; câmpuri obligatorii / read-only per stare |
| **Pontaj (time tracking)** | Înregistrare ore pe proiect/tichet, activități, rapoarte de timp agregate |
| **Planificare** | Versiuni / milestone-uri, roadmap, diagramă **Gantt**, calendar |
| **Wiki** | Wiki per proiect cu istoric de versiuni, diff, export; formatare Textile / Markdown |
| **Documente & fișiere** | Modul Documente (categorii), modul Fișiere (release-uri), atașamente la tichete/wiki/știri |
| **Colaborare** | Forumuri (boards/messages), știri (news), notificări email, fluxuri **Atom** |
| **Repository cod** | Integrare SCM (Git, Subversion, Mercurial, CVS, Bazaar, Darcs, Filesystem): navigare cod, revizii, legare commit ↔ tichet prin cuvinte cheie (`refs #123`, `fixes #123`) |
| **Câmpuri personalizate** | Custom fields pe tichete, proiecte, utilizatori, grupuri, pontaj, versiuni, documente (text, listă, dată, utilizator, versiune etc.) |
| **Interogări / rapoarte** | Filtre salvate (queries) publice/private, export **CSV / PDF / Atom**, rezumate pe proiect |
| **Email** | Notificări SMTP; creare/actualizare tichete din email (IMAP/POP3 sau endpoint `mail_handler`) |
| **Administrare** | Utilizatori, grupuri, roluri & permisiuni, trackere, stări, enumerări, surse de autentificare LDAP, setări globale, plugin-uri |

---

## 3. Utilizatori (roluri)

Autorizarea se face pe baza **rolurilor pe proiect** (un utilizator poate avea roluri diferite în proiecte diferite), cu permisiuni granulare configurabile.

- **Administrator** (`users.admin = true`) — acces complet la toate proiectele și la configurarea aplicației.
- **Manager** (rol implicit) — administrează proiectul: membri, versiuni, categorii, module.
- **Developer / Dezvoltator** (rol implicit) — lucrează pe tichete, pontează timp, accesează repository-ul.
- **Reporter** (rol implicit) — raportează tichete, comentează.
- **Non-member** (rol predefinit) — utilizator autentificat care nu e membru al proiectului (pentru proiecte publice).
- **Anonymous** (rol predefinit) — vizitator neautentificat (poate fi dezactivat prin setarea „Autentificare obligatorie”).
- **Grupuri** — utilizatorii pot fi grupați; grupurile primesc roluri pe proiecte.
- **Conturi tehnice / de integrare** — utilizatori Redmine cu **cheie API** folosiți de aplicații externe (ex.: aplicația Registratură/Alfresco). `<de completat: nume cont>`

---

## 4. Date prelucrate

Persistate într-o **bază de date relațională** (MySQL / PostgreSQL / SQL Server / SQLite) + atașamente în directorul `files/` pe server.

### Entități principale (schema DB)
- **users** — `login, firstname, lastname, hashed_password, salt, admin, status, last_login_on, language, auth_source_id, type (User/Group/AnonymousUser)`
- **email_addresses** — `user_id, address, is_default, notify`
- **projects** — `name, identifier, description, homepage, is_public, parent_id, lft, rgt, status, inherit_members`
- **members / member_roles / roles** — apartenența utilizatorilor/grupurilor la proiecte și permisiunile (serializate în `roles.permissions`)
- **issues** (entitatea centrală) — `project_id, tracker_id, subject, description, status_id, priority_id, assigned_to_id, author_id, category_id, fixed_version_id, parent_id, root_id, start_date, due_date, estimated_hours, done_ratio, is_private, closed_on`
- **journals / journal_details** — istoricul complet al modificărilor pe tichete (cine, când, câmp, valoare veche → nouă, note)
- **issue_relations**, **watchers**, **trackers**, **issue_statuses**, **issue_categories**, **workflows**, **enumerations** (priorități, activități, categorii documente)
- **time_entries** — `project_id, issue_id, user_id, hours, activity_id, spent_on, comments`
- **versions** — `project_id, name, effective_date, status, sharing`
- **attachments** — `container_type, container_id, filename, disk_filename, disk_directory, filesize, content_type, digest (SHA256), author_id`
- **wikis / wiki_pages / wiki_contents / wiki_content_versions** — conținut wiki cu versiuni
- **documents, news, comments, boards, messages** — documente, știri, forumuri
- **repositories / changesets / changes / changesets_issues** — integrare SCM
- **custom_fields / custom_values / custom_fields_projects / custom_fields_roles / custom_fields_trackers**
- **queries** — filtre salvate
- **tokens** — `user_id, action (api, feeds, session, autologin, recovery, register), value` (chei API, sesiuni, resetare parolă)
- **auth_sources** — surse de autentificare externe (LDAP): `host, port, account, account_password, base_dn, attr_login, tls`
- **settings** — configurări globale (cheie/valoare)
- **user_preferences**, **groups_users**, **enabled_modules**, **schema_migrations**

### Date sensibile
- **Date cu caracter personal**: nume, prenume, email, login, istoric activitate, pontaj (ore lucrate per persoană).
- **Conținutul tichetelor, wiki-ului și atașamentelor** — poate conține informații interne/sensibile (inclusiv referințe la documente din registratură).
- **Credențiale**: hash-uri de parolă locale, chei API, parola contului de bind LDAP (stocată în `auth_sources`), setări SMTP.

---

## 5. Fluxuri de date și interconectări

### 5.1 Schema de arhitectură și interconectări

![Diagramă](docs/diagrams/arhitectura.png)

- **Browser ↔ Redmine:** aplicație Rails randată pe server (HTML + jQuery/jQuery UI), sesiune pe cookie.
- **Redmine ↔ Bază de date:** ActiveRecord (adapter `mysql2` / `pg` / `sqlserver` / `sqlite3`).
- **Redmine ↔ Active Directory:** autentificare prin sursa LDAP (`net-ldap`), cu opțiune de creare automată a utilizatorilor la prima autentificare (on-the-fly).
- **Redmine ↔ Email:** notificări trimise prin SMTP (`config/configuration.yml`); recepție email prin task-uri rake (`redmine:email:receive_imap` / `receive_pop3`) sau prin endpoint-ul `/mail_handler` protejat cu cheie WS.
- **Redmine ↔ SCM:** citire locală a repository-urilor; actualizarea changeset-urilor prin cron, hook de post-commit sau endpoint `/sys/fetch_changesets` (protejat cu cheie WS).
- **Aplicații externe → Redmine:** API REST (JSON/XML) autentificat cu cheie API.

### 5.2 Flux — creare și rezolvare tichet

![Diagramă](docs/diagrams/flux-tichet.png)

### 5.3 Flux — autentificare

![Diagramă](docs/diagrams/flux-autentificare.png)

### 5.4 Flux — integrare prin API REST

![Diagramă](docs/diagrams/flux-api-rest.png)

---

## 6. Autentificare

- **Autentificare locală:** login + parolă, stocată ca hash **SHA1 cu salt** (`users.hashed_password`, `users.salt`). Politică configurabilă: lungime minimă parolă, expirare parolă, autentificare obligatorie, înregistrare self-service (dezactivată / activare manuală / activare prin email).
- **LDAP / Active Directory:** surse de autentificare configurate în *Administrare → Autentificare LDAP* (`auth_sources`): host, port, LDAPS/TLS, cont de bind, base DN, filtru, mapare atribute (login, prenume, nume, email). Creare utilizatori on-the-fly opțională. `<de completat: server AD, domeniu, dacă se folosește domeniul sts.nest>`
- **OpenID:** suportat opțional (gem `ruby-openid`), de regulă dezactivat.
- **Sesiune web:** cookie de sesiune + token de sesiune în tabela `tokens` (action `session`), cu setări de expirare/timeout pentru inactivitate; opțiune „Ține-mă minte” (token `autologin`).
- **API REST:** activat din *Administrare → Setări → API*. Autentificare prin:
  - header **`X-Redmine-API-Key`** (recomandat),
  - parametru `key` în URL (nerecomandat — apare în loguri),
  - HTTP Basic (login + parolă sau cheie API ca username).
  - Impersonare: header `X-Redmine-Switch-User` (doar pentru chei API de administrator).
- **Chei WS:** chei separate pentru `/mail_handler` (email entrant) și `/sys/*` (servicii repository).
- **Autentificare cu doi factori (2FA):** **nu este disponibilă** în versiunea 3.4.x (a apărut în Redmine 4.2).
- **Resetare parolă:** prin email, cu token de tip `recovery`.

---

## 7. Managementul modificărilor (change management)

- **Schema DB:** migrări Rails versionate în `db/migrate/` (tabela `schema_migrations`); aplicare cu `bundle exec rake db:migrate RAILS_ENV=production`.
- **Plugin-uri:** instalate în directorul `plugins/`, cu migrări proprii (`rake redmine:plugins:migrate`). `<de completat: lista plugin-urilor instalate>`
- **Actualizare versiune:** procedura oficială (backup DB + `files/` + `config/`, înlocuire cod, `bundle install`, migrări, `tmp:cache:clear`, restart).
- **Trasabilitate date:**
  - tichete — istoric complet în `journals` / `journal_details` (autor, dată, câmp, valoare veche/nouă);
  - wiki — versiuni integrale în `wiki_content_versions`, cu diff și revenire la versiuni anterioare;
  - atașamente — sumă de control (`digest`), autor, dată;
  - `created_on` / `updated_on` pe majoritatea entităților;
  - legătura cod ↔ tichet prin `changesets_issues`.
- **Configurare:** `config/database.yml`, `config/configuration.yml` (email, SCM, cale atașamente), `config/secrets.yml` / `secret_token` (generat cu `rake generate_secret_token`), setări din UI în tabela `settings`.
- **Stare versiune:** Redmine **3.4.2** (iulie 2017). Ramura 3.4 **nu mai este întreținută**, iar ulterior au fost publicate numeroase corecții de securitate. Ruby on Rails 4.2 și versiunile de Ruby compatibile au ajuns de asemenea la sfârșitul suportului. **Recomandare:** plan de actualizare la o versiune Redmine întreținută (cu verificarea compatibilității plugin-urilor și a integrărilor API).

---

## 8. API-uri (endpoint-uri expuse de aplicație)

API REST în format **JSON** (`.json`) sau **XML** (`.xml`), activat din setări. Paginare cu `offset` / `limit` (max. 100). Selecție reprezentativă:

**Tichete**
- `GET /issues.json` (filtre: `project_id`, `status_id`, `assigned_to_id`, `tracker_id`, custom fields etc.), `GET /issues/{id}.json?include=journals,attachments,relations,children,watchers,changesets`
- `POST /issues.json`, `PUT /issues/{id}.json`, `DELETE /issues/{id}.json`
- `POST/DELETE /issues/{id}/watchers.json`
- `GET/POST /issues/{id}/relations.json`, `GET/DELETE /relations/{id}.json`

**Proiecte & membri**
- `GET/POST /projects.json`, `GET/PUT/DELETE /projects/{id}.json`
- `GET/POST /projects/{id}/memberships.json`, `GET/PUT/DELETE /memberships/{id}.json`
- `GET/POST /projects/{id}/versions.json`, `GET/PUT/DELETE /versions/{id}.json`
- `GET/POST /projects/{id}/issue_categories.json`

**Utilizatori & grupuri** (majoritatea doar admin)
- `GET/POST /users.json`, `GET/PUT/DELETE /users/{id}.json`, `GET /users/current.json`
- `GET/POST /groups.json`, `GET/PUT/DELETE /groups/{id}.json`, `POST/DELETE /groups/{id}/users.json`

**Pontaj**
- `GET/POST /time_entries.json`, `GET/PUT/DELETE /time_entries/{id}.json`

**Wiki, știri, fișiere, atașamente**
- `GET /projects/{id}/wiki/index.json`, `GET/PUT/DELETE /projects/{id}/wiki/{titlu}.json`
- `GET /news.json`, `GET /projects/{id}/news.json`
- `GET/POST /projects/{id}/files.json`
- `POST /uploads.json` (upload binar → token folosit la atașare), `GET /attachments/{id}.json`

**Nomenclatoare & diverse**
- `GET /trackers.json`, `/issue_statuses.json`, `/enumerations/issue_priorities.json`, `/enumerations/time_entry_activities.json`, `/roles.json`, `/custom_fields.json` (admin), `/queries.json`, `/search.json`

**Alte interfețe**
- Fluxuri **Atom** (autentificate cu cheie `feeds`)
- `POST /mail_handler` — primire email (cheie WS)
- `GET /sys/projects`, `/sys/fetch_changesets` — servicii repository (cheie WS)

---

## 9. Tehnologii folosite

**Backend**
- **Ruby** (versiunile 1.9.3 – 2.4 suportate de Redmine 3.4) `<de completat: versiunea instalată>`
- **Ruby on Rails 4.2**
- **Bundler** pentru gestionarea dependențelor (`Gemfile`)
- Gem-uri principale: `net-ldap` (LDAP/AD), `rbpdf` (export PDF), `nokogiri`, `roadie-rails` (email HTML), `mimemagic`, `request_store`, `protected_attributes`, `actionpack-xml_parser`, `rack-openid` / `ruby-openid`, `redcarpet` (Markdown), `coderay` (evidențiere sintaxă), `rmagick` (opțional — imagini Gantt PNG)

**Frontend**
- HTML randat server-side (ERB), **jQuery 1.11** + **jQuery UI**, CSS cu teme (implicit „Default”, „Alternate”, „Classic”)

**Infrastructură / date**
- Bază de date: **MySQL 5.0–5.7** / **PostgreSQL** / **SQL Server 2008+** / **SQLite3** `<de completat: SGBD folosit>`
- Server aplicație: **Phusion Passenger**, **Puma** sau **Unicorn**, în spatele **Apache / Nginx** `<de completat>`
- Stocare atașamente: sistem de fișiere local (`files/`)
- Clienți SCM (git, svn etc.) instalați pe server, dacă se folosește modulul Repository
- Server SMTP pentru notificări

**Testare / dev**
- Minitest (teste unitare, funcționale, de integrare), `mocha`, `capybara`, `selenium-webdriver`, `simplecov`, `yard`

---

## 10. API-uri către aplicații externe (integrări)

| Sistem extern | Adresă / API | Scop | Autentificare |
|---------------|--------------|------|----------------|
| **Active Directory** | `<de completat: host LDAP>` (LDAP/LDAPS) | Autentificare utilizatori, creare conturi on-the-fly | bind LDAP cu cont de serviciu (în `auth_sources`) |
| **Server SMTP** | `<de completat>` (`config/configuration.yml`) | Notificări email | user/parolă SMTP (opțional) |
| **Server IMAP/POP3** (opțional) | `<de completat>` | Creare/actualizare tichete din email | user/parolă cutie poștală |
| **Repository-uri SCM** (opțional) | `<de completat>` (Git/SVN local sau remote) | Afișare cod, legare commit ↔ tichet | acces fișier / credențiale SCM |
| **Registratură Electronică (Alfresco)** (client → API-ul Redmine) | `DELETE /issues/{id}.json` | Ștergere issue asociat unui document din registratură | header `X-Redmine-API-Key` |
| **Alte aplicații interne** (client → API-ul Redmine) | `/issues.json`, `/projects.json` etc. | `<de completat>` | cheie API (`X-Redmine-API-Key`) |
